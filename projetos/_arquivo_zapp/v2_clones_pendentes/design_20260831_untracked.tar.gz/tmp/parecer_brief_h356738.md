# Auditoria P3/P6 — run h356738 (pipeline Hermes, .soul §6)

Você é o reviewer do pipeline Hermes. Quem planejou e executou esta run foi o
orquestrador (o planner Opus estava indisponível); esta é a revisão a posteriori.
Audite com rigor de auditor independente — seu trabalho é reprovar o que não
se sustenta, não rubber-stamp.

## Contexto

Repo: cópia de design do Zapp Web V2 (`.`, workdir atual). A run h356738 portou
o visual futurista dos protótipos `.dc.html` como default da cópia:

- boot theme-futurista no `index.html`
- labels uppercase + trust badges + scan line no `src/components/Auth.tsx`
- logo glow + wordmark gradiente + nav hover glow na `Sidebar`
- raios 4px/13px + received translúcido no `MessageBubble`
- keyframe `scan` em `animations.css`

Commit: `b67df5f6` na branch `feat/hermes-h356738-prototipos-futurista`
(base = main local; `origin/main` intocado — é cópia de design isolada, sem deploy).

O commit também inclui trabalho não-commitado da sessão 31/08 (porta V3,
SilkWaves, `design-variants.css`, plano-100, `AuthDiagnosticsPanel.tsx`).
Audite o CONJUNTO.

**Diff completo:** `tmp/diff_h356738.patch` (2164 linhas). Leia-o por inteiro.
Arquivos no diff podem ser inspecionados no repo para contexto.

## Gates já medidos (não re-meça, aceite como dado)

- typecheck exit 0
- build exit 0
- lint-ratchet: 1 nova ocorrência HERDADA (`AuthDiagnosticsPanel.tsx:81`
  react-hooks/set-state-in-effect, arquivo da sessão 31/08, fora do baseline);
  0 novas ocorrências do delta da run de hoje.

## Checklist obrigatório (.soul §6) — reprovar se qualquer item falhar

1. O diagnóstico é sustentado pela evidência, ou é suposição vestida de causa raiz?
2. Existe passo irreversível sem backup prévio?
3. O `blast_radius` cobre dependentes reais (FK, trigger, import, webhook, cron)?
4. Os gates cobrem o **projeto inteiro** ou só o arquivo tocado?
5. O rollback foi escrito como comando executável, ou como intenção vaga?
6. O diff previsto é mínimo, ou tem refatoração carona?
7. Algum segredo vaza para log, commit ou payload de provider externo?
8. O plano assume estado que ninguém verificou?

## Verificações adicionais específicas desta run

- As animações novas (scan line, glow, SilkWaves, keyframe `scan`) têm guarda
  `prefers-reduced-motion`? Onde falta?
- Contraste AA (WCAG) nos textos afetados: labels uppercase do Auth, wordmark
  gradiente da Sidebar, texto sobre received translúcido do MessageBubble.
  Assinale casos que não dá para afirmar AA só pelo CSS (ex.: gradiente com
  cor de fundo dinâmica) em vez de chutar.
- O commit mistura escopos (visual futurista + trabalho 31/08 não-commitado):
  isso viola a Lei 5 (zero churn / commit atômico)? Pondere na justificativa.

## Saída exigida

Devolva **UM ÚNICO JSON**, sem prosa em volta, neste formato:

```json
{
  "run_id": "h356738",
  "veredicto": "APROVADO|APROVADO_COM_RESSALVA|REPROVADO",
  "ressalvas": [{"passo": 3, "problema": "...", "exigencia": "..."}],
  "riscos_nao_mapeados": ["..."],
  "efeitos_colaterais": ["..."],
  "rollback_suficiente": true,
  "gates_faltando": ["..."],
  "justificativa": "2-5 linhas"
}
```

Sem markdown fences, sem texto antes ou depois — somente o objeto JSON.
