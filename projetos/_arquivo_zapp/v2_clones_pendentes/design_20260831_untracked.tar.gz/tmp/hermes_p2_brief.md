# P2 — PLANNER BRIEFING (pipeline Hermes, .soul §5)

Você é o PLANNER (estágio P2) do pipeline Hermes. Produza UM JSON de plano (contrato abaixo), sem prosa em volta. Idioma: pt-BR.

## Pedido do usuário
"A nível de teste — não altere nada no projeto original — ajuste o projeto Zapp Web V2 para o novo design criado pelo Claude Code."

Significado: portar a linguagem visual dos 3 protótipos `.dc.html` (feitos no Claude Code) para a CÓPIA de design do app real (sandbox), como visual DEFAULT. É porta de design, não de funcionalidade.

## Caminhos (WSL)
- Protótipos (SOMENTE LEITURA — nunca escrever neles):
  - /home/joaquim_ataides/projetos/Zapp Web V2 - Redesign/ZAPP Auth.dc.html (270 linhas — login)
  - /home/joaquim_ataides/projetos/Zapp Web V2 - Redesign/ZAPP App v2.dc.html (3486 linhas — shell: sidebar+inbox+chat+contato)
  - /home/joaquim_ataides/projetos/Zapp Web V2 - Redesign/Inbox Futurista v2.dc.html (1445 linhas — inbox alternativo c/ command palette)
- Sandbox (onde TUDO é escrito): /home/joaquim_ataides/projetos/Zapp_Web_V2_design_20260831/
  Stack: Vite + React + TS + Tailwind (tokens HSL em src/styles/tokens.css), shadcn, framer-motion via wrapper '@/components/ui/motion', bun. Dev server já roda em :5199 (HMR). Git branch main com mudanças não commitadas da sessão anterior (design-port V3) — não reverter nem commitar sem ser desta run.

## Linguagem visual dos protótipos (valores exatos extraídos por grep)
- Paleta: bg #04050a / #04070d; painéis rgba(8,10,18,.97) / #0a0c14; texto #e8eaf2; ciano #22d3ee e #6ee7ff; violeta #8b5cf6 / #a78bfa; verde #34d399; âmbar #fbbf24; vermelho #f87171; índigo #6366f1.
- Fontes: Space Grotesk (display/números/labels uppercase letter-spacing .06em) + Outfit (corpo). JÁ carregadas no index.html do sandbox; --font-numeric já usa Space Grotesk.
- Efeitos: aurora (2 blobs radiais blur animados), grid 52px c/ máscara radial, scan line, border-flow (focus c/ gradiente 90deg ciano→violeta animado — sandbox JÁ TEM .chat-input-flow + @keyframes border-flow), glow shadows 0 0 24-36px, gradientes 135deg #22d3ee→#8b5cf6 em botões/logo (bg-clip-text).
- Keyframes dos protótipos: aurora1/2, float-y, fade-in, border-flow, strength-fill, badge-pop, scan, msg-in, typing-dot, waveform, shimmer, sla-pulse, pulse-ring, confetti-burst, count-up, xp-fill, highlight-pulse, kanban-in, notif-slide, pop-in, slide-in, glow-pulse, story-ring, sparkline-draw, nba-pulse, cmd-in, rx-pop, toast-in/out, call-ring, slide-screen/slide-right, wave.

## Estado atual do sandbox (AUDITADO — NÃO re-portar o que existe)
- src/styles/design-variants.css: .theme-aurora/.theme-emerald/.theme-violet/.theme-futurista (~25 tokens HSL). Futurista = exatamente a paleta dos protótipos (--primary 190 84% 51% = #22d3ee, --secondary 258 90% 66% = #8b5cf6, --background 228 55% 3% ≈ #04050a). Ativação: classe no <html> via seletor flutuante no index.html (localStorage 'zapp-design-variant'); DEFAULT hoje = sem classe (azul original).
- index.html: seletor flutuante "DESIGN PREVIEW ONLY" (linhas ~150-189): array de classes removidas + boot `if (saved) apply(saved)` — sem saved, fica no original.
- Keyframes JÁ existentes (src/styles/animations.css): border-flow, border-glow, count-up, fade-in/out, float, glow-pulse, gradient-shift, level-up, msg-in, pop, pulse-*, ripple, scale-in, shake, shimmer, skeleton-*, slide-*, streak-fire, typing, wiggle, xp-shimmer, underline-expand, coin-shine, bounce-in.
- src/pages/Auth.tsx (394 lin): porta V3 (HeroBenefits, SocialProof, ZappLogo, SilkWaves, lockStatus, useAuthForm V2), card max-w-[358px]. NÃO tem: labels uppercase Space Grotesk, headline com palavra em gradiente, trust badges (SSL/LGPD/uptime), medidor visual de força de senha, scan line.
- src/components/layout/Sidebar.tsx (175 lin): compacta/expandível com Tooltip; SEM XP bar, SEM workspace profiles, SEM glow.
- src/components/inbox/ConversationList.tsx (336 lin): tabs funcionais; SEM stories, SEM sentiment filter, SEM AI-sort.
- src/components/inbox/chat/MessageBubble.tsx (280 lin): componente ATIVO (ChatMessageBubble.tsx é legado não importado). Plano-100 já aplicou msg-in + reaction bar.
- Plano-100 (sessão anterior, aplicado): reaction bar nativa, KPI count-up rAF, --font-numeric, .chat-input-flow.
- Gates: bun run typecheck | lint | build | test.

## Escopo P0 desta run (delta visual default)
1. theme-futurista DEFAULT no boot (sem flash), mantendo seletor com botão Original (rollback 1 clique).
2. Auth.tsx: portar elementos visuais faltantes (labels uppercase, headline com gradiente, trust badges, força de senha visual, scan line sutil) SEM trocar hooks/lógica. Manter SilkWaves (aprovado) + ZappLogo (pixel-perfect, sagrada).
3. Sidebar.tsx: restyle futurista (logo c/ glow, hover glow nos itens, XP bar E11 do protótipo SE houver fonte de dados real de gamificação — sem dados, omitir; NÃO maquetar). Workspace profiles idem.
4. ConversationList.tsx: restyle futurista (presence dot, badges SLA com sla-pulse, pin com glow) — sem features novas de dados.
5. MessageBubble.tsx: validar raios exatos no .dc.html (esperado sent 18px 6px 18px 18px / received 6px 18px 18px 18px — CONFERIR no arquivo) e ajustar se divergente; cores via tokens.
6. CSS novo concentrado (design-variants.css ou 1 arquivo novo src/styles/futurista.css importado pelo index.css); overrides por classe/token, diff mínimo por arquivo.

## Restrições duras
- Escrever SOMENTE no sandbox; protótipos/original = leitura.
- Diff mínimo, zero churn, um passo por patch, typecheck a cada passo, build+lint no fim.
- Toda animação nova com prefers-reduced-motion.
- Contraste AA (ciano sobre #04050a = 9.8:1 ok).
- Zero feature nova de backend/dados; maquete visual = declarar ou omitir.
- Rollback por passo: git checkout -- <arquivo> OU remover classe default OU apagar arquivo novo.

## Saída (JSON único, sem prosa)
{
 "run_id": "h<epoch7>",
 "pedido": "...",
 "diagnostico": "...",
 "evidencia": ["arquivo:linha ou fato lido"],
 "risco": "baixo|medio|alto",
 "alvos": ["arquivos exatos"],
 "passos": [ {"n":1,"acao":"...","ferramenta":"shell","precondicao":"...","efeito_esperado":"...","verificacao":"comando","reversivel":true} ],
 "simulacao": "como dry-run cada passo",
 "gates": ["typecheck","lint","build"],
 "rollback": "comando a comando",
 "blast_radius": "...",
 "nao_faz_parte": ["stories","sentiment filter","AI sort","command palette","dados fake", ...]
}

Máximo 12 passos. Leia os arquivos que precisar (só leitura) antes de emitir o JSON.
