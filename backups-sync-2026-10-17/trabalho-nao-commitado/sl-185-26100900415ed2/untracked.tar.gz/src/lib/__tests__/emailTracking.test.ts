import { describe, expect, it } from 'vitest';
import {
  EMAIL_TRACKING_PATHS,
  buildClickRedirectUrl,
  buildOpenPixelHtml,
  buildOpenPixelUrl,
  injectOpenPixel,
  isOpaqueTrackingToken,
  isTrackableLink,
  isTrackingUrl,
} from '../emailTracking';

// Item 082 do plano 100 etapas: "abertura registrada uma vez por destinatário;
// link redireciona em < 100 ms; sem PII na URL (token opaco -> email_messages.id)".
// Estas asserções são exatamente as regras do aceite, sem tocar em rede nem em banco.

const BASE = 'https://track.promobrindes.com.br';
const TOKEN = 'b7f1c0d2e3a4958675a4b3c2d1e0f9a8';

describe('emailTracking — token opaco (sem PII)', () => {
  it('aceita base64url/hex com 16+ caracteres', () => {
    expect(isOpaqueTrackingToken(TOKEN)).toBe(true);
    expect(isOpaqueTrackingToken('0123456789abcdef')).toBe(true);
  });

  it('recusa endereço de e-mail, curto demais e com caractere estranho', () => {
    expect(isOpaqueTrackingToken('cliente@promobrindes.com.br')).toBe(false);
    expect(isOpaqueTrackingToken('+5511999998888')).toBe(false);
    expect(isOpaqueTrackingToken('curto')).toBe(false);
    expect(isOpaqueTrackingToken('')).toBe(false);
    expect(isOpaqueTrackingToken(null)).toBe(false);
    expect(isOpaqueTrackingToken(undefined)).toBe(false);
  });
});

describe('emailTracking — URL do pixel e do redirect', () => {
  it('monta a URL do pixel sem nenhum dado do destinatário', () => {
    const url = buildOpenPixelUrl(BASE, TOKEN);
    expect(url).toBe(`${BASE}${EMAIL_TRACKING_PATHS.open}?t=${TOKEN}`);
    expect(url).not.toContain('@');
  });

  it('monta o redirect com o alvo codificado e sem PII', () => {
    const url = buildClickRedirectUrl(BASE, TOKEN, 'https://loja.exemplo.com/oferta?a=1&b=2');
    expect(url).toBe(
      `${BASE}${EMAIL_TRACKING_PATHS.click}?t=${TOKEN}&u=${encodeURIComponent('https://loja.exemplo.com/oferta?a=1&b=2')}`,
    );
    expect(url).not.toContain('@');
  });

  it('aceita base com prefixo e normaliza a barra final', () => {
    expect(buildOpenPixelUrl(`${BASE}/zapp/`, TOKEN)).toBe(`${BASE}/zapp${EMAIL_TRACKING_PATHS.open}?t=${TOKEN}`);
  });

  it('recusa base insegura, com credenciais, query ou hash', () => {
    expect(buildOpenPixelUrl('ftp://track.promobrindes.com.br', TOKEN)).toBeNull();
    expect(buildOpenPixelUrl('https://user:senha@track.promobrindes.com.br', TOKEN)).toBeNull();
    expect(buildOpenPixelUrl('https://track.promobrindes.com.br/?x=1', TOKEN)).toBeNull();
    expect(buildOpenPixelUrl('nao-e-url', TOKEN)).toBeNull();
  });

  it('recusa alvo que não pode ser rastreado (evita 2ª passagem pelo rastreador)', () => {
    expect(buildClickRedirectUrl(BASE, TOKEN, 'mailto:cliente@exemplo.com')).toBeNull();
    expect(buildClickRedirectUrl(BASE, TOKEN, '/pagina-relativa')).toBeNull();
    expect(buildClickRedirectUrl(BASE, TOKEN, `${BASE}${EMAIL_TRACKING_PATHS.click}?t=outro`)).toBeNull();
  });
});

describe('emailTracking — quais links podem ser rastreados', () => {
  it('aceita http e https absolutos', () => {
    expect(isTrackableLink('https://loja.exemplo.com/oferta')).toBe(true);
    expect(isTrackableLink('http://intranet.local/aviso')).toBe(true);
  });

  it('recusa esquemas que quebrariam o e-mail (mailto/tel/cid/data/javascript)', () => {
    for (const href of ['mailto:a@b.com', 'tel:+5511999998888', 'cid:logo', 'data:image/gif;base64,AAA', 'javascript:alert(1)']) {
      expect(isTrackableLink(href)).toBe(false);
    }
  });

  it('recusa âncora, relativo, vazio e quebra de linha', () => {
    expect(isTrackableLink('#topo')).toBe(false);
    expect(isTrackableLink('/caminho')).toBe(false);
    expect(isTrackableLink('')).toBe(false);
    expect(isTrackableLink('   ')).toBe(false);
    expect(isTrackableLink('https://loja.exemplo.com/\r\nX-Injected: 1')).toBe(false);
    expect(isTrackableLink(null)).toBe(false);
  });

  it('não rastreia o próprio rastreador (o clique não passa duas vezes por nós)', () => {
    expect(isTrackableLink(`${BASE}${EMAIL_TRACKING_PATHS.click}?t=${TOKEN}`)).toBe(false);
    expect(isTrackingUrl(`${BASE}${EMAIL_TRACKING_PATHS.open}?t=${TOKEN}`)).toBe(true);
    expect(isTrackingUrl('https://loja.exemplo.com/oferta')).toBe(false);
  });
});

describe('emailTracking — pixel no HTML', () => {
  it('monta um pixel 1x1 invisível e sem carregamento preguiçoso', () => {
    const pixelUrl = buildOpenPixelUrl(BASE, TOKEN)!;
    const html = buildOpenPixelHtml(pixelUrl)!;
    expect(html).toContain(`src="${pixelUrl}"`);
    expect(html).toContain('width="1"');
    expect(html).toContain('height="1"');
    expect(html).toContain('role="presentation"');
    expect(html).toContain('alt=""');
    expect(html).not.toContain('loading="lazy"');
  });

  it('recusa URL de pixel que não é http(s)', () => {
    expect(buildOpenPixelHtml('cid:pixel')).toBeNull();
    expect(buildOpenPixelHtml('nao-e-url')).toBeNull();
  });

  it('injeta o pixel uma única vez, antes do fecho do body', () => {
    const pixelUrl = buildOpenPixelUrl(BASE, TOKEN)!;
    const primeiro = injectOpenPixel('<html><body><p>Olá</p></body></html>', pixelUrl)!;
    expect(primeiro.indexOf(EMAIL_TRACKING_PATHS.open)).toBeLessThan(primeiro.indexOf('</body>'));

    const segundo = injectOpenPixel(primeiro, pixelUrl)!;
    expect(segundo).toBe(primeiro);
    expect(segundo.split(EMAIL_TRACKING_PATHS.open).length - 1).toBe(1);
  });

  it('injeta no fim quando o HTML não tem body', () => {
    const pixelUrl = buildOpenPixelUrl(BASE, TOKEN)!;
    const html = injectOpenPixel('<p>Olá</p>', pixelUrl)!;
    expect(html.endsWith('/>')).toBe(true);
    expect(html.split(EMAIL_TRACKING_PATHS.open).length - 1).toBe(1);
  });

  it('não injeta pixel inválido', () => {
    expect(injectOpenPixel('<p>Olá</p>', 'cid:pixel')).toBeNull();
  });
});
