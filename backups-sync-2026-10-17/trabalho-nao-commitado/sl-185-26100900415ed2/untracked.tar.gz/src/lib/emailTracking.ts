/**
 * Rastreio de e-mail — metade CLIENTE do item 082 ("Tracking de e-mail: pixel + link").
 *
 * Aqui só há decisão e montagem: nenhuma função fala com a rede, lê estado, guarda
 * segredo ou conhece o banco. A base pública (o host que serve o pixel e o redirect)
 * entra por parâmetro, porque quem serve é a Edge Function — que ainda não existe
 * (ver .tmp/relato.md). As colunas `opened_at`/`clicked_at` da thread também
 * dependem de migration e ficaram fora.
 *
 * Regras do aceite do item, viradas em código:
 * - **sem PII na URL**: a única coisa que viaja é o token opaco, que o servidor
 *   liga a `email_messages.id`. Endereço de e-mail, telefone ou id legível não
 *   passam por `isOpaqueTrackingToken` e, por isso, nenhuma URL montada aqui
 *   contém "@";
 * - **abertura registrada uma vez por destinatário**: `injectOpenPixel` é
 *   idempotente — um HTML que já carrega o pixel do rastreador volta intacto;
 * - **link redireciona em < 100 ms**: um destino que já é URL do rastreador não é
 *   rastreável, então o clique nunca passa duas vezes por nós (nem trava em laço);
 * - links que quebrariam a mensagem (mailto/tel/cid/data/javascript) e âncoras ou
 *   relativos nunca são reescritos.
 */

/** Caminhos das duas Edge Functions públicas do item 082. */
export const EMAIL_TRACKING_PATHS = {
  open: '/email-track-pixel',
  click: '/email-track-link',
} as const;

/** Host de exemplo só para resolver URL relativa ao classificar (`isTrackingUrl`). */
const URL_RESOLVER = 'https://rastreador.invalido';

/** Token opaco: base64url/hex, 16 a 512 caracteres. Nada de "@", espaço ou pontuação livre. */
export function isOpaqueTrackingToken(token: string | null | undefined): boolean {
  if (typeof token !== 'string') return false;
  const value = token.trim();
  if (value.length < 16 || value.length > 512) return false;
  return /^[A-Za-z0-9_-]+$/.test(value);
}

/** A URL aponta para um dos dois caminhos de rastreio (absoluta ou relativa)? */
export function isTrackingUrl(url: string | null | undefined): boolean {
  if (typeof url !== 'string') return false;
  const value = url.trim();
  if (!value) return false;
  const paths: string[] = [EMAIL_TRACKING_PATHS.open, EMAIL_TRACKING_PATHS.click];
  try {
    const parsed = new URL(value, URL_RESOLVER);
    return paths.includes(parsed.pathname.replace(/\/+$/, ''));
  } catch {
    return false;
  }
}

/** Um link do corpo do e-mail pode ser reescrito para rastreio de clique? */
export function isTrackableLink(href: string | null | undefined): boolean {
  if (typeof href !== 'string') return false;
  // CR/LF em href é injeção de cabeçalho/atributo, não link.
  if (/[\r\n]/.test(href)) return false;
  const value = href.trim();
  // Só http(s) absoluto: barra mailto, tel, cid, data, javascript, âncora e relativo.
  if (!/^https?:\/\/[^\s]+$/i.test(value)) return false;
  // Nunca rastrear o rastreador (laço de redirect / clique contado duas vezes).
  return !isTrackingUrl(value);
}

/** Base do rastreador: http(s), sem credenciais, query ou hash. */
function parseTrackingBase(baseUrl: string): URL | null {
  try {
    const parsed = new URL(baseUrl.trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
    if (parsed.username || parsed.password) return null;
    if (parsed.search || parsed.hash) return null;
    return parsed;
  } catch {
    return null;
  }
}

/** Raiz da base sem a barra final (preserva prefixo de subpasta, se houver). */
function trackingRoot(base: URL): string {
  return `${base.origin}${base.pathname.replace(/\/+$/, '')}`;
}

/** URL do pixel de abertura. `null` = token/base inválidos (não há URL sem PII a montar). */
export function buildOpenPixelUrl(baseUrl: string, token: string): string | null {
  if (!isOpaqueTrackingToken(token)) return null;
  const root = trackingRoot(baseUrl);
  if (!root) return null;
  return `${root}${EMAIL_TRACKING_PATHS.open}?t=${token}`;
}

/** URL do redirect de clique. `null` = token/base/alvo inválidos. */
export function buildClickRedirectUrl(baseUrl: string, token: string, targetUrl: string): string | null {
  if (!isTrackableLink(targetUrl)) return null;
  if (!isOpaqueTrackingToken(token)) return null;
  const root = trackingRoot(baseUrl);
  if (!root) return null;
  return `${root}${EMAIL_TRACKING_PATHS.click}?t=${token}&u=${encodeURIComponent(targetUrl.trim())}`;
}

function escapeAttribute(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
}

/**
 * HTML do pixel: 1x1, invisível, fora da árvore de acessibilidade e **sem**
 * `loading="lazy"` — pixel preguiçoso não é buscado, e a abertura se perde.
 */
export function buildOpenPixelHtml(pixelUrl: string): string | null {
  if (typeof pixelUrl !== 'string') return null;
  const value = pixelUrl.trim();
  if (!/^https?:\/\//i.test(value)) return null;
  try {
    const parsed = new URL(value);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
  } catch {
    return null;
  }
  return `<img src="${escapeAttribute(value)}" width="1" height="1" alt="" role="presentation" style="border:0;outline:none;text-decoration:none" referrerpolicy="no-referrer" />`;
}

/**
 * Injeta o pixel antes do fecho do `<body>` (ou no fim, quando não há body).
 * Idempotente: um HTML que já tem o pixel do rastreador volta sem alteração — é o
 * que garante "abertura registrada uma vez por destinatário".
 */
export function injectOpenPixel(html: string, pixelUrl: string): string | null {
  if (typeof html !== 'string') return null;
  const pixel = buildOpenPixelHtml(pixelUrl);
  if (!pixel) return null;
  if (html.includes(EMAIL_TRACKING_PATHS.open)) return html;
  const bodyClose = html.toLowerCase().lastIndexOf('</body>');
  if (bodyClose === -1) return `${html}${pixel}`;
  return `${html.slice(0, bodyClose)}${pixel}${html.slice(bodyClose)}`;
}
