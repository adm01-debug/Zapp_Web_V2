/**
 * TL-028 (inventario F50) — a ESTIMATIVA do disparo, visivel para o operador.
 *
 * O F50 vive na edge (`multiplix-dispatch/actions/inspect.ts`): a acao `estimate`
 * devolve os TRES numeros de dado real — mensagens (aptos x blocos), versoes de
 * roteiro (DISTINCT dos roteiros FINAIS) e consumo de voz. O que faltava era a
 * parte de TELAS: nenhuma tela pedia a estimativa, entao os tres numeros existiam
 * no servidor e nao chegavam a quem decide.
 *
 * Este teste NAO mocka tela nem hook: renderiza o `MultiplixMonitor` REAL, com os
 * hooks REAIS, mockando so a rede (o cliente Supabase). O que ele trava:
 *   1. a tela PEDE a estimativa do disparo (acao `estimate` + `dispatch_id`);
 *   2. mostra os numeros que o SERVIDOR devolveu — a tela nao tem blocos nem
 *      roteiros, entao nao ha o que recalcular no navegador;
 *   3. leitura que falhou NAO vira "0 mensagens" (nada de estimativa inventada);
 *   4. disparo ja encerrado nao exibe estimativa do que "vai" sair.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const authGetSession = vi.fn();
const functionsInvoke = vi.fn();

const h = vi.hoisted(() => ({
  /** Resposta da acao `estimate` (a edge devolve `{ data: <resultado> }`). */
  estimate: { data: { data: {} }, error: null } as { data: unknown; error: unknown },
  dispatchStatus: 'sending',
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    auth: { getSession: (...args: unknown[]) => authGetSession(...args) },
    functions: { invoke: (...args: unknown[]) => functionsInvoke(...args) },
    // O monitor abre um canal realtime; o encadeamento e o mesmo do componente.
    channel: () => ({ on: () => ({ on: () => ({ subscribe: () => ({}) }) }) }),
    removeChannel: () => {},
  },
}));

vi.mock('sonner', () => ({ toast: { error: vi.fn(), success: vi.fn() } }));

import { MultiplixMonitor } from '@/components/multiplix/MultiplixMonitor';
import type { MultiplixDispatch, MultiplixRecipientRow } from '@/hooks/integrations/useMultiplixDispatches';

function dispatchFixture(): MultiplixDispatch {
  return {
    id: 'd1',
    name: 'Disparo TL-028',
    message_template: 'Olá {{empresa}}!',
    status: h.dispatchStatus as MultiplixDispatch['status'],
    total_recipients: 5,
    sent_count: 2,
    failed_count: 0,
    delivered_count: 1,
    outcome_unknown_count: 0,
    started_at: null,
    paused_at: null,
    pause_reason: null,
    completed_at: h.dispatchStatus === 'completed' ? '2026-10-09T00:10:00Z' : null,
    created_at: '2026-10-09T00:00:00Z',
  };
}

interface InvokeOptions {
  body?: { action?: string; payload?: Record<string, unknown> };
}

beforeEach(() => {
  vi.clearAllMocks();
  h.dispatchStatus = 'sending';
  // Numeros que a TELA nao teria como deduzir (nao ha blocos/roteiros no front):
  // se aparecem, vieram da edge.
  h.estimate = {
    data: { data: { messages: 20, script_versions: 6, voice: { characters: 1234, renderings: 6 }, eligible_recipients: 5, blocks: 4 } },
    error: null,
  };
  authGetSession.mockResolvedValue({ data: { session: { access_token: 'tok-123' } } });
  functionsInvoke.mockImplementation((_fn: string, options: InvokeOptions) => {
    const action = options?.body?.action;
    if (action === 'dispatch.list') {
      return Promise.resolve({ data: { data: { dispatches: [dispatchFixture()], total: 1 } }, error: null });
    }
    if (action === 'recipients.list') {
      const rows: MultiplixRecipientRow[] = [];
      return Promise.resolve({ data: { data: { recipients: rows, total: 0 } }, error: null });
    }
    if (action === 'estimate') return Promise.resolve(h.estimate);
    return Promise.resolve({ data: { data: null }, error: null });
  });
});

function renderMonitor() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  return render(
    <QueryClientProvider client={qc}>
      <MultiplixMonitor dispatchId="d1" onBack={vi.fn()} />
    </QueryClientProvider>,
  );
}

describe('MultiplixMonitor — estimativa do disparo (TL-028/F50)', () => {
  it('pede a estimativa do disparo e mostra os TRES numeros que a edge devolveu', async () => {
    renderMonitor();

    const linha = await screen.findByTestId('multiplix-estimate');

    expect(functionsInvoke).toHaveBeenCalledWith('multiplix-dispatch', {
      body: { action: 'estimate', payload: { dispatch_id: 'd1' } },
      headers: { Authorization: 'Bearer tok-123' },
    });
    const texto = linha.textContent ?? '';
    expect(texto).toContain('20 mensagens');
    expect(texto).toContain('5 aptos × 4 blocos');
    expect(texto).toContain('6 versões de roteiro');
    expect(texto).toContain('1.234 caracteres de voz (6 áudios)');
  });

  it('leitura que falhou NAO vira "0 mensagens" (nada de estimativa inventada)', async () => {
    h.estimate = { data: null, error: { message: 'Edge Function returned a non-2xx status code' } };

    renderMonitor();

    expect(await screen.findByTestId('multiplix-estimate-erro')).toBeInTheDocument();
    expect(screen.queryByTestId('multiplix-estimate')).toBeNull();
    expect(screen.queryByText(/mensagens/)).toBeNull();
  });

  it('nao mostra estimativa de disparo ja encerrado', async () => {
    h.dispatchStatus = 'completed';

    renderMonitor();

    // A tela carregou de verdade (o disparo aparece) e a linha nao.
    await screen.findByText('Disparo TL-028');
    expect(screen.queryByTestId('multiplix-estimate')).toBeNull();
    expect(screen.queryByTestId('multiplix-estimate-erro')).toBeNull();
  });
});
