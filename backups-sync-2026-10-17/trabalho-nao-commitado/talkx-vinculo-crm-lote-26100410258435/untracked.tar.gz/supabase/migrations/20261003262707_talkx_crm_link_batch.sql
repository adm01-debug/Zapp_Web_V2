-- x036-talkx-crm-link-batch
-- versão 20261003262707 reservada para hermes-talkx-vinculo-crm-lote-26100410258435 (hermes-db-migrar --nova)
--
-- X036 (Fase 4 - Tela dados - banco + edge + cron). Fecha CAP-092, dados:vinculo_crm.
--
-- HOJE: crm_contact_links tem 0 linhas. A unica escrita e
-- public.upsert_crm_contact_link_guarded (link_source fixo 'sync_result') chamada por
-- processRows ao encerrar conversa. O CHECK de link_source so aceita
-- phone_lookup|manual|sync_result. Nao existe registro de execucao nem fila de jobs da
-- trilha de dados.
--
-- FAZER (esta migration):
--   (1) public.talkx_data_jobs      - registro de jobs da trilha (intervalo, ultimo inicio,
--       habilitado) + alvo do disparo (function_name/action).
--   (2) public.talkx_data_sync_runs - uma linha por execucao (lidos/alterados/ignorados/
--       falhas/error_code/cursor), compartilhada por todos os jobs da trilha.
--   (3) public.talkx_crm_link_issues - divergencias (ambiguous|external_taken|
--       identity_mismatch) com candidatos e resolucao (quem/quando).
--   (4) CHECK de crm_contact_links.link_source ampliado com bulk_phone e import.
--   (5) RPCs so service_role:
--         talkx_crm_link_candidates(p_after, p_limit)  - contatos elegiveis sem vinculo e
--             sem divergencia aberta (keyset por id).
--         talkx_crm_link_apply_batch(p_run, p_links)   - grava o vinculo; 23505 vira linha
--             em talkx_crm_link_issues, nunca excecao para o lote.
--   (6) talkx_run_data_jobs() + job pg_cron 'talkx-data-jobs' (a cada 5 min, x-cron-secret
--       proprio lido do Vault, timeout_milliseconds).
--
-- ELEGIVEL (mesmo criterio de M:20260930450000/talkx_audience_rpc): deleted_at IS NULL,
-- is_lid_legacy = false e phone ~ '^[0-9]{10,15}$'. O job roda como service_role (sem
-- usuario), entao "visivel" aqui e o criterio de catalogo de Contatos, nao a visibilidade
-- por dono/equipe (is_contact_visible_to_user exige auth.uid()).
--
-- CONTADORES: scanned = changed + skipped + failed por construcao (cada entrada processada
-- entra em exatamente um balde). 'ambiguous', 'not_found', vinculo idempotente e conflito
-- de unicidade contam em skipped; so erro inesperado/malformado conta em failed.
--
-- Classe: contrato (CREATE OR REPLACE FUNCTION + ALTER TABLE ... DROP/ADD CONSTRAINT +
-- REVOKE). Nada destrutivo: as tres tabelas sao novas, a unica tabela viva tocada e
-- crm_contact_links e apenas no CHECK (superset do atual, nenhum valor aceito e removido).
-- Idempotente: CREATE TABLE IF NOT EXISTS / CREATE INDEX IF NOT EXISTS / CREATE OR REPLACE.

-- rollback: DROP ROUTINE IF EXISTS public.talkx_run_data_jobs(); DROP ROUTINE IF EXISTS public.get_talkx_data_cron_secret(); DROP ROUTINE IF EXISTS public.talkx_crm_link_apply_batch(uuid, jsonb); DROP ROUTINE IF EXISTS public.talkx_crm_link_candidates(uuid, integer); SELECT cron.unschedule('talkx-data-jobs') WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'talkx-data-jobs'); remover as tres tabelas novas (public.talkx_crm_link_issues, public.talkx_data_sync_runs, public.talkx_data_jobs); ALTER TABLE public.crm_contact_links DROP CONSTRAINT IF EXISTS crm_contact_links_link_source_check; ALTER TABLE public.crm_contact_links ADD CONSTRAINT crm_contact_links_link_source_check CHECK (link_source IN ('phone_lookup','manual','sync_result')); DELETE FROM vault.secrets WHERE name = 'talkx_data_cron_secret';

-- ============================================================================
-- (1) Registro dos jobs da trilha de dados
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.talkx_data_jobs (
  job              text PRIMARY KEY,
  interval_minutes integer NOT NULL DEFAULT 60
                     CONSTRAINT talkx_data_jobs_interval_range
                     CHECK (interval_minutes BETWEEN 1 AND 10080),
  last_started_at  timestamptz,
  enabled          boolean NOT NULL DEFAULT true,
  function_name    text,                 -- edge a disparar (NULL = job so de banco, tratado pelo dono)
  action           text,                 -- acao da edge (ex.: 'linkBatch')
  payload          jsonb NOT NULL DEFAULT '{}'::jsonb
                     CONSTRAINT talkx_data_jobs_payload_object
                     CHECK (jsonb_typeof(payload) = 'object'),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.talkx_data_jobs IS
  'X036: registro dos jobs da trilha de dados. talkx_run_data_jobs() dispara os vencidos.';

ALTER TABLE public.talkx_data_jobs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.talkx_data_jobs FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.talkx_data_jobs TO authenticated;
GRANT ALL ON TABLE public.talkx_data_jobs TO service_role;
CREATE POLICY "Admins read data jobs"
  ON public.talkx_data_jobs FOR SELECT TO authenticated
  USING (public.is_admin_or_supervisor(auth.uid()));

-- ============================================================================
-- (2) Trilha de execucao (uma linha por rodada de qualquer job da trilha)
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.talkx_data_sync_runs (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job            text NOT NULL,
  trigger_source text NOT NULL DEFAULT 'cron'
                   CONSTRAINT talkx_data_sync_runs_trigger_check
                   CHECK (trigger_source IN ('cron', 'manual', 'backfill')),
  started_at     timestamptz NOT NULL DEFAULT now(),
  finished_at    timestamptz,
  scanned        integer NOT NULL DEFAULT 0 CONSTRAINT talkx_data_sync_runs_scanned_nonneg CHECK (scanned >= 0),
  changed        integer NOT NULL DEFAULT 0 CONSTRAINT talkx_data_sync_runs_changed_nonneg CHECK (changed >= 0),
  skipped        integer NOT NULL DEFAULT 0 CONSTRAINT talkx_data_sync_runs_skipped_nonneg CHECK (skipped >= 0),
  failed         integer NOT NULL DEFAULT 0 CONSTRAINT talkx_data_sync_runs_failed_nonneg CHECK (failed >= 0),
  error_code     text,
  cursor         text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.talkx_data_sync_runs IS
  'X036: trilha de execucao dos jobs de dados. Inscricao: scanned = changed + skipped + failed.';

ALTER TABLE public.talkx_data_sync_runs ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.talkx_data_sync_runs FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.talkx_data_sync_runs TO authenticated;
GRANT ALL ON TABLE public.talkx_data_sync_runs TO service_role;
CREATE POLICY "Admins read data sync runs"
  ON public.talkx_data_sync_runs FOR SELECT TO authenticated
  USING (public.is_admin_or_supervisor(auth.uid()));

CREATE INDEX IF NOT EXISTS idx_talkx_data_sync_runs_job_started
  ON public.talkx_data_sync_runs (job, started_at DESC);

-- ============================================================================
-- (3) Divergencias de vinculo em lote
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.talkx_crm_link_issues (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id uuid NOT NULL REFERENCES public.contacts(id) ON DELETE CASCADE,
  issue_type text NOT NULL
               CONSTRAINT talkx_crm_link_issues_type_check
               CHECK (issue_type IN ('ambiguous', 'external_taken', 'identity_mismatch')),
  candidates jsonb NOT NULL DEFAULT '[]'::jsonb
               CONSTRAINT talkx_crm_link_issues_candidates_array
               CHECK (jsonb_typeof(candidates) = 'array'),
  resolution text,
  resolved_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  resolved_at timestamptz,
  run_id     uuid REFERENCES public.talkx_data_sync_runs(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.talkx_crm_link_issues IS
  'X036: divergencias do vinculo em lote. Aberta = resolved_at IS NULL; no maximo uma aberta por contato.';

ALTER TABLE public.talkx_crm_link_issues ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.talkx_crm_link_issues FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.talkx_crm_link_issues TO authenticated;
GRANT ALL ON TABLE public.talkx_crm_link_issues TO service_role;
CREATE POLICY "Admins read crm link issues"
  ON public.talkx_crm_link_issues FOR SELECT TO authenticated
  USING (public.is_admin_or_supervisor(auth.uid()));

-- Uma unica divergencia ABERTA por contato: a proxima rodada atualiza os candidatos em vez
-- de empilhar linhas. Resolvida (resolved_at IS NOT NULL) sai do indice e libera nova aberta.
CREATE UNIQUE INDEX IF NOT EXISTS idx_talkx_crm_link_issues_open_contact
  ON public.talkx_crm_link_issues (contact_id)
  WHERE resolved_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_talkx_crm_link_issues_type_created
  ON public.talkx_crm_link_issues (issue_type, created_at DESC);

-- ============================================================================
-- (4) link_source: amplia o CHECK com bulk_phone e import
-- ============================================================================
-- Definicao VIVA lida no catalogo: CHECK (link_source = ANY (ARRAY['phone_lookup',
-- 'manual','sync_result'])). Superset estrito: nenhum valor hoje aceito deixa de ser.

ALTER TABLE public.crm_contact_links
  DROP CONSTRAINT IF EXISTS crm_contact_links_link_source_check;
ALTER TABLE public.crm_contact_links
  ADD CONSTRAINT crm_contact_links_link_source_check
  CHECK (link_source IN ('phone_lookup', 'manual', 'sync_result', 'bulk_phone', 'import'));

-- ============================================================================
-- (5a) talkx_crm_link_candidates - contatos elegiveis sem vinculo e sem divergencia aberta
-- ============================================================================

CREATE OR REPLACE FUNCTION public.talkx_crm_link_candidates(
  p_after uuid DEFAULT NULL,
  p_limit integer DEFAULT 100
) RETURNS TABLE (id uuid, phone text, name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
  SELECT c.id, c.phone, c.name
    FROM public.contacts AS c
   WHERE c.deleted_at IS NULL
     AND c.is_lid_legacy = false
     AND c.phone ~ '^[0-9]{10,15}$'
     AND (p_after IS NULL OR c.id > p_after)
     AND NOT EXISTS (
       SELECT 1 FROM public.crm_contact_links AS l WHERE l.zapp_contact_id = c.id
     )
     AND NOT EXISTS (
       SELECT 1 FROM public.talkx_crm_link_issues AS i
        WHERE i.contact_id = c.id AND i.resolved_at IS NULL
     )
   ORDER BY c.id
   LIMIT LEAST(GREATEST(COALESCE(p_limit, 100), 1), 100);
$function$;

COMMENT ON FUNCTION public.talkx_crm_link_candidates(uuid, integer) IS
  'X036: pagina (keyset por id) contatos elegiveis para vinculo em lote: deleted_at IS NULL, is_lid_legacy=false, phone ^[0-9]{10,15}$, sem vinculo e sem divergencia aberta. So service_role.';

REVOKE ALL ON FUNCTION public.talkx_crm_link_candidates(uuid, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.talkx_crm_link_candidates(uuid, integer) TO service_role;

-- ============================================================================
-- (5b) talkx_crm_link_apply_batch - grava vinculos e converte conflito em divergencia
-- ============================================================================
-- p_links: array de objetos com {contact_id, outcome: linked|ambiguous|not_found, ...}.
--   linked    -> {external_contact_id, external_company_id, normalized_phone, link_source
--                 ('bulk_phone'|'import', default bulk_phone), candidates[]}
--   ambiguous -> {candidates:[{external_contact_id, company_id}]}
--   not_found -> {}
-- Nao lanca por conflito de unicidade: a linha vira talkx_crm_link_issues.

CREATE OR REPLACE FUNCTION public.talkx_crm_link_apply_batch(
  p_run uuid,
  p_links jsonb
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
DECLARE
  v_entry        jsonb;
  v_contact      uuid;
  v_outcome      text;
  v_ext          text;
  v_company      text;
  v_phone        text;
  v_source       text;
  v_candidates   jsonb;
  v_existing     text;
  v_issue_type   text;
  v_scanned      integer := 0;
  v_changed      integer := 0;
  v_skipped      integer := 0;
  v_failed       integer := 0;
  v_issues       integer := 0;
BEGIN
  IF COALESCE(auth.role(), '') <> 'service_role' THEN
    RAISE EXCEPTION 'insufficient_privilege' USING ERRCODE = '42501';
  END IF;
  IF p_links IS NULL OR jsonb_typeof(p_links) <> 'array' THEN
    RAISE EXCEPTION 'invalid_talkx_crm_link_batch' USING ERRCODE = '22023';
  END IF;
  IF p_run IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.talkx_data_sync_runs WHERE id = p_run) THEN
    RAISE EXCEPTION 'talkx_crm_link_run_not_found' USING ERRCODE = 'P0002';
  END IF;

  FOR v_entry IN SELECT e.value FROM jsonb_array_elements(p_links) AS e(value) LOOP
    v_scanned := v_scanned + 1;
    v_contact := NULL;
    v_issue_type := NULL;
    v_candidates := COALESCE(v_entry -> 'candidates', '[]'::jsonb);

    BEGIN
      v_contact := NULLIF(v_entry ->> 'contact_id', '')::uuid;
      v_outcome := v_entry ->> 'outcome';

      IF v_contact IS NULL
         OR v_outcome IS NULL
         OR v_outcome NOT IN ('linked', 'ambiguous', 'not_found') THEN
        RAISE EXCEPTION 'invalid_talkx_crm_link_entry' USING ERRCODE = '22023';
      END IF;

      IF v_outcome = 'not_found' THEN
        v_skipped := v_skipped + 1;

      ELSIF v_outcome = 'ambiguous' THEN
        v_issue_type := 'ambiguous';
        v_skipped := v_skipped + 1;

      ELSE
        v_ext := NULLIF(btrim(COALESCE(v_entry ->> 'external_contact_id', '')), '');
        v_company := NULLIF(btrim(COALESCE(v_entry ->> 'external_company_id', '')), '');
        v_phone := regexp_replace(COALESCE(v_entry ->> 'normalized_phone', ''), '\D', '', 'g');
        v_source := COALESCE(NULLIF(btrim(COALESCE(v_entry ->> 'link_source', '')), ''), 'bulk_phone');
        IF v_source NOT IN ('bulk_phone', 'import') THEN
          v_source := 'bulk_phone';
        END IF;

        IF v_ext IS NULL OR length(v_ext) NOT BETWEEN 1 AND 200
           OR (v_company IS NOT NULL AND length(v_company) NOT BETWEEN 1 AND 200)
           OR v_phone !~ '^[0-9]{8,15}$' THEN
          RAISE EXCEPTION 'invalid_talkx_crm_link_entry' USING ERRCODE = '22023';
        END IF;

        SELECT l.external_contact_id INTO v_existing
          FROM public.crm_contact_links AS l
         WHERE l.zapp_contact_id = v_contact
         FOR UPDATE;

        IF FOUND THEN
          IF v_existing = v_ext THEN
            -- Idempotente: segunda execucao do mesmo vinculo nao cria linha nem divergencia.
            v_skipped := v_skipped + 1;
          ELSE
            v_issue_type := 'identity_mismatch';
            v_skipped := v_skipped + 1;
          END IF;
        ELSE
          BEGIN
            INSERT INTO public.crm_contact_links (
              zapp_contact_id, external_contact_id, external_company_id,
              normalized_phone, link_source, verified_at
            ) VALUES (v_contact, v_ext, v_company, v_phone, v_source, now());
            v_changed := v_changed + 1;
          EXCEPTION WHEN unique_violation THEN
            -- external_contact_id ja pertence a outro contato do ZAPP.
            v_issue_type := 'external_taken';
            v_skipped := v_skipped + 1;
          END;
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      -- Entrada malformada/erro inesperado: conta em failed sem abortar o lote.
      v_issue_type := NULL;
      v_failed := v_failed + 1;
    END;

    IF v_issue_type IS NOT NULL AND v_contact IS NOT NULL THEN
      BEGIN
        INSERT INTO public.talkx_crm_link_issues (contact_id, issue_type, candidates, run_id)
        VALUES (v_contact, v_issue_type, v_candidates, p_run)
        ON CONFLICT (contact_id) WHERE resolved_at IS NULL
        DO UPDATE SET issue_type = EXCLUDED.issue_type,
                      candidates = EXCLUDED.candidates,
                      run_id = EXCLUDED.run_id,
                      updated_at = now();
        v_issues := v_issues + 1;
      EXCEPTION WHEN OTHERS THEN
        -- Falha ao registrar a divergencia nao derruba o lote nem infla contadores.
        v_issues := v_issues;
      END;
    END IF;
  END LOOP;

  IF p_run IS NOT NULL THEN
    UPDATE public.talkx_data_sync_runs
       SET scanned = scanned + v_scanned,
           changed = changed + v_changed,
           skipped = skipped + v_skipped,
           failed  = failed + v_failed,
           error_code = CASE
             WHEN v_failed > 0 THEN COALESCE(error_code, 'invalid_batch_entry')
             ELSE error_code
           END
     WHERE id = p_run;
  END IF;

  RETURN jsonb_build_object(
    'run_id', p_run,
    'scanned', v_scanned,
    'changed', v_changed,
    'skipped', v_skipped,
    'failed', v_failed,
    'issues', v_issues
  );
END;
$function$;

COMMENT ON FUNCTION public.talkx_crm_link_apply_batch(uuid, jsonb) IS
  'X036: grava vinculos em lote (link_source bulk_phone/import) e converte conflito de unicidade em talkx_crm_link_issues (ambiguous|external_taken|identity_mismatch). scanned = changed + skipped + failed. So service_role.';

REVOKE ALL ON FUNCTION public.talkx_crm_link_apply_batch(uuid, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.talkx_crm_link_apply_batch(uuid, jsonb) TO service_role;

-- ============================================================================
-- (6) Credencial dedicada + talkx_run_data_jobs() + job pg_cron talkx-data-jobs
-- ============================================================================

-- Segredo dedicado do cron, criado no banco (so se nao existir) e tolerante a ausencia do
-- Vault em PostgreSQL descartavel. Nao e uma chave literal: nasce e morre no Postgres.
DO $$
BEGIN
  IF to_regclass('vault.secrets') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM vault.secrets WHERE name = 'talkx_data_cron_secret') THEN
      PERFORM vault.create_secret(
        encode(extensions.gen_random_bytes(32), 'hex'),
        'talkx_data_cron_secret',
        'Credencial de maquina do cron talkx-data-jobs (pg_cron -> edge crm-integration). NUNCA logar.'
      );
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'talkx_data_cron_secret_seed_skipped: %', sqlerrm;
END;
$$;

-- Leitura pela edge (client service_role): SECURITY DEFINER + EXECUTE so para service_role.
CREATE OR REPLACE FUNCTION public.get_talkx_data_cron_secret()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $function$
  SELECT decrypted_secret
    FROM vault.decrypted_secrets
   WHERE name = 'talkx_data_cron_secret'
   LIMIT 1;
$function$;

REVOKE ALL ON FUNCTION public.get_talkx_data_cron_secret() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_talkx_data_cron_secret() TO service_role;

-- Tick: dispara os jobs vencidos de talkx_data_jobs. Um unico job no pg_cron para a trilha
-- (o pg_cron ja falha com 'job startup timeout'; nao somar jobs). Fire-and-forget (pg_net).
CREATE OR REPLACE FUNCTION public.talkx_run_data_jobs()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
DECLARE
  v_anon_key    text;
  v_cron_secret text;
  v_job         public.talkx_data_jobs%ROWTYPE;
  v_fired       jsonb := '[]'::jsonb;
BEGIN
  -- pg_cron roda como o dono do job (sem JWT): declara o papel localmente, como
  -- trigger_talkx_engine_tick / trigger_ai_jobs_tick.
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);

  IF COALESCE(auth.role(), '') <> 'service_role' THEN
    RAISE EXCEPTION 'service_role_required' USING ERRCODE = '42501';
  END IF;

  SELECT decrypted_secret INTO v_anon_key
    FROM vault.decrypted_secrets WHERE name = 'zapp_anon_key' LIMIT 1;
  SELECT decrypted_secret INTO v_cron_secret
    FROM vault.decrypted_secrets WHERE name = 'talkx_data_cron_secret' LIMIT 1;

  FOR v_job IN
    SELECT * FROM public.talkx_data_jobs AS j
     WHERE j.enabled
       AND j.function_name IS NOT NULL
       AND (j.last_started_at IS NULL
            OR j.last_started_at <= now() - make_interval(mins => j.interval_minutes))
     ORDER BY j.job
     FOR UPDATE SKIP LOCKED
  LOOP
    UPDATE public.talkx_data_jobs
       SET last_started_at = now(), updated_at = now()
     WHERE job = v_job.job;

    IF v_anon_key IS NULL OR v_cron_secret IS NULL THEN
      CONTINUE;  -- sem credencial configurada nao ha como invocar a edge
    END IF;

    PERFORM net.http_post(
      url := 'https://tnnnlkbymytvtqngbbqh.supabase.co/functions/v1/' || v_job.function_name,
      body := jsonb_build_object('action', COALESCE(v_job.action, 'health'), 'job', v_job.job)
              || COALESCE(v_job.payload, '{}'::jsonb),
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'apikey', v_anon_key,
        'Authorization', 'Bearer ' || v_anon_key,
        'x-cron-secret', v_cron_secret
      ),
      timeout_milliseconds := 25000
    );

    v_fired := v_fired || to_jsonb(v_job.job);
  END LOOP;

  RETURN jsonb_build_object('fired', v_fired);
END;
$function$;

REVOKE ALL ON FUNCTION public.talkx_run_data_jobs() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.talkx_run_data_jobs() TO service_role;

-- Seed idempotente do unico job da trilha nesta etapa.
INSERT INTO public.talkx_data_jobs (job, interval_minutes, enabled, function_name, action)
VALUES ('crm_link_batch', 5, true, 'crm-integration', 'linkBatch')
ON CONFLICT (job) DO NOTHING;

-- Agendamento idempotente: so cria se pg_cron existir e o job ainda nao existir. Offset
-- '4-59/5' para nao somar concorrencia no minuto 0 (gmail-incremental-sync/avatars-refresh).
DO $$
BEGIN
  IF to_regclass('cron.job') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'talkx-data-jobs') THEN
      PERFORM cron.schedule('talkx-data-jobs', '4-59/5 * * * *', 'SELECT public.talkx_run_data_jobs()');
    END IF;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE WARNING 'talkx_data_jobs_cron_schedule_skipped: %', sqlerrm;
END;
$$;

-- ============================================================================
-- Fail-closed: se qualquer objeto novo nao colar, aborta em vez de deixar contrato pela metade.
-- ============================================================================
DO $$
DECLARE
  v_missing text;
BEGIN
  SELECT string_agg(esperado.assinatura, ', ') INTO v_missing
    FROM (
      VALUES
        ('public.talkx_crm_link_candidates(uuid,integer)'),
        ('public.talkx_crm_link_apply_batch(uuid,jsonb)'),
        ('public.get_talkx_data_cron_secret()'),
        ('public.talkx_run_data_jobs()')
    ) AS esperado(assinatura)
   WHERE to_regprocedure(assinatura) IS NULL;

  IF v_missing IS NOT NULL THEN
    RAISE EXCEPTION 'x036_objetos_ausentes: %', v_missing;
  END IF;

  IF to_regclass('public.talkx_data_jobs') IS NULL
     OR to_regclass('public.talkx_data_sync_runs') IS NULL
     OR to_regclass('public.talkx_crm_link_issues') IS NULL THEN
    RAISE EXCEPTION 'x036_tabelas_ausentes';
  END IF;

  IF NOT EXISTS (
       SELECT 1 FROM pg_constraint
        WHERE conrelid = 'public.crm_contact_links'::regclass
          AND conname = 'crm_contact_links_link_source_check'
          AND pg_get_constraintdef(oid) LIKE '%bulk_phone%'
          AND pg_get_constraintdef(oid) LIKE '%import%'
     ) THEN
    RAISE EXCEPTION 'x036_link_source_check_nao_ampliado';
  END IF;
END;
$$;
