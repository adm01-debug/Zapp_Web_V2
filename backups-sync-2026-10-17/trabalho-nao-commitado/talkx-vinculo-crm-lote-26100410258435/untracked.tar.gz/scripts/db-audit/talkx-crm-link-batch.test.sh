#!/usr/bin/env bash
# X036 — vinculo em lote de contatos do ZAPP ao CRM por telefone (talkx_data_jobs,
# talkx_data_sync_runs, talkx_crm_link_issues, RPCs de candidatos/aplicacao, CHECK de
# link_source ampliado e job pg_cron talkx-data-jobs).
#
# Roda em PostgreSQL 17 descartavel. A migration nova e localizada por MARCADOR interno, nao
# por nome de arquivo: o hermes-db-migrar --nova renomeia/versiona o arquivo e o nome fixo
# quebraria. Enquanto a versao nao foi reservada, o fallback e .tmp/x036.sql.
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
postgres_image="${TALKX_CRM_LINK_TEST_POSTGRES_IMAGE:-postgres:17-alpine}"
container_name="talkx-crm-link-test-$RANDOM-$$"
test_password="talkx_crm_link_test_only"

cleanup() { docker rm -f "$container_name" >/dev/null 2>&1 || true; }
trap cleanup EXIT

docker run --rm -d --name "$container_name" -e POSTGRES_PASSWORD="$test_password" "$postgres_image" >/dev/null
postgres_ready=false
for _ in $(seq 1 90); do
  # O servidor de bootstrap do image oficial expoe um Postgres temporario antes do definitivo:
  # exigir o SEGUNDO marcador de readiness e uma consulta viva evita a corrida do shutdown.
  ready_markers="$(docker logs "$container_name" 2>&1 \
    | grep -c 'database system is ready to accept connections' || true)"
  if [[ "$ready_markers" -ge 2 ]] \
    && docker exec "$container_name" psql -X -U postgres -d postgres -Atqc 'SELECT 1' \
      >/dev/null 2>&1; then
    postgres_ready=true
    break
  fi
  sleep 1
done

if [[ "$postgres_ready" != true ]]; then
  echo "PostgreSQL test container did not reach final readiness." >&2
  docker logs --tail 100 "$container_name" >&2 || true
  exit 1
fi

psql_test() { docker exec -i "$container_name" psql -X -v ON_ERROR_STOP=1 -U postgres -d postgres "$@"; }

# Localiza a migration por marcador interno (imune ao rename do hermes-db-migrar).
migration="$(grep -rlF 'x036-talkx-crm-link-batch' "$repo_root/supabase/migrations" 2>/dev/null \
  | grep -v '/_superseded/' | sort | tail -1 || true)"
if [[ -z "$migration" ]]; then
  migration="$repo_root/.tmp/x036.sql"
fi
if [[ ! -f "$migration" ]]; then
  echo "migration do X036 nao encontrada (marcador x036-talkx-crm-link-batch)" >&2
  exit 1
fi

# ── stubs: roles, auth, helpers, contacts, vault e cron ─────────────────────────────────────
psql_test >/dev/null <<'SQL'
CREATE SCHEMA IF NOT EXISTS extensions;
CREATE EXTENSION IF NOT EXISTS pgcrypto SCHEMA extensions;  -- gen_random_bytes em extensions
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN;
CREATE SCHEMA IF NOT EXISTS auth;
CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
  SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
$$;
CREATE FUNCTION auth.role() RETURNS text LANGUAGE sql STABLE AS $$
  SELECT nullif(current_setting('request.jwt.claim.role', true), '')
$$;
CREATE TABLE public.profiles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL UNIQUE);
CREATE FUNCTION public.is_admin_or_supervisor(uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT COALESCE(current_setting('test.is_admin', true), 'false') = 'true' AND $1 IS NOT NULL
$$;
CREATE FUNCTION public.is_contact_visible_to_user(uuid, uuid) RETURNS boolean LANGUAGE sql STABLE AS $$ SELECT true $$;
CREATE TABLE public.contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  is_lid_legacy boolean NOT NULL DEFAULT false,
  deleted_at timestamptz,
  channel_type text,
  ai_sentiment text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.conversation_closures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id uuid NOT NULL REFERENCES public.contacts(id),
  close_reason text NOT NULL DEFAULT 'done',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Vault minimo (a migration le/grava segredo dedicado).
CREATE SCHEMA IF NOT EXISTS vault;
CREATE TABLE vault.secrets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE, secret text, description text
);
CREATE VIEW vault.decrypted_secrets AS
  SELECT id, name, secret AS decrypted_secret, description FROM vault.secrets;
CREATE FUNCTION vault.create_secret(p_secret text, p_name text, p_description text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO vault.secrets(name, secret, description) VALUES (p_name, p_secret, p_description)
  ON CONFLICT (name) DO NOTHING RETURNING id INTO v_id;
  RETURN v_id;
END $$;

-- pg_cron minimo (a migration agenda talkx-data-jobs de forma idempotente).
CREATE SCHEMA IF NOT EXISTS cron;
CREATE TABLE cron.job (
  jobid bigserial PRIMARY KEY, jobname text, schedule text, command text,
  nodename text DEFAULT 'localhost', nodeport integer DEFAULT 5432, database text DEFAULT 'postgres',
  username text DEFAULT current_user, active boolean DEFAULT true
);
CREATE FUNCTION cron.schedule(p_jobname text, p_schedule text, p_command text)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE v_id bigint;
BEGIN
  INSERT INTO cron.job(jobname, schedule, command) VALUES (p_jobname, p_schedule, p_command)
  RETURNING jobid INTO v_id;
  RETURN v_id;
END $$;
CREATE FUNCTION cron.unschedule(p_jobname text) RETURNS boolean LANGUAGE plpgsql AS $$
BEGIN DELETE FROM cron.job WHERE jobname = p_jobname; RETURN true; END $$;
CREATE FUNCTION cron.unschedule(p_jobid bigint) RETURNS boolean LANGUAGE plpgsql AS $$
BEGIN DELETE FROM cron.job WHERE jobid = p_jobid; RETURN true; END $$;
SQL

# Base viva do vinculo CRM (cria crm_contact_links com o CHECK ORIGINAL de link_source).
psql_test < "$repo_root/supabase/migrations/20260908180000_crm_contact_links_and_sync_outbox.sql" >/dev/null

# Estado anterior a ampliacao: so phone_lookup|manual|sync_result.
psql_test >/dev/null <<'SQL'
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conrelid = 'public.crm_contact_links'::regclass
       AND conname = 'crm_contact_links_link_source_check'
       AND pg_get_constraintdef(oid) LIKE '%bulk_phone%'
  ) THEN
    RAISE EXCEPTION 'estado inicial ja continha bulk_phone';
  END IF;
END $$;
SQL

# A migration sob teste.
psql_test < "$migration" >/dev/null

output="$(psql_test -At <<'SQL'
SELECT set_config('request.jwt.claim.role', 'service_role', false);

INSERT INTO contacts(id,name,phone) VALUES
  ('00000000-0000-0000-0000-000000000001','E1','11999990001'),
  ('00000000-0000-0000-0000-000000000002','E2','5511999990002'),
  ('00000000-0000-0000-0000-000000000003','E3','1199999003'),
  ('00000000-0000-0000-0000-000000000004','Deleted','11999990004'),
  ('00000000-0000-0000-0000-000000000005','Lid','11999990005'),
  ('00000000-0000-0000-0000-000000000006','InvalidPhone','123'),
  ('00000000-0000-0000-0000-000000000007','Linked','11999990007'),
  ('00000000-0000-0000-0000-000000000008','OpenIssue','11999990008');
UPDATE contacts SET deleted_at = now() WHERE id = '00000000-0000-0000-0000-000000000004';
UPDATE contacts SET is_lid_legacy = true WHERE id = '00000000-0000-0000-0000-000000000005';
INSERT INTO crm_contact_links(zapp_contact_id, external_contact_id, normalized_phone, link_source)
VALUES ('00000000-0000-0000-0000-000000000007','ext-linked','11999990007','sync_result');
INSERT INTO talkx_crm_link_issues(contact_id, issue_type, candidates)
VALUES ('00000000-0000-0000-0000-000000000008','ambiguous','[]'::jsonb);

-- (1) candidatos elegiveis: so 001/002/003 (nao deleted/lid/invalido/vinculado/com divergencia)
SELECT 'candidates_eligible=' || CASE WHEN (
  SELECT string_agg(id::text, ',' ORDER BY id) FROM talkx_crm_link_candidates(NULL, 100)
) = '00000000-0000-0000-0000-000000000001,00000000-0000-0000-0000-000000000002,00000000-0000-0000-0000-000000000003'
THEN 'ok' ELSE 'fail' END;

-- keyset: 2 por pagina e a proxima comeca depois do ultimo id visto
SELECT 'keyset_first=' || CASE WHEN (
  SELECT array_agg(id::text ORDER BY id) FROM talkx_crm_link_candidates(NULL, 2)
) = ARRAY['00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002'] THEN 'ok' ELSE 'fail' END;
SELECT 'keyset_next=' || CASE WHEN (
  SELECT id FROM talkx_crm_link_candidates('00000000-0000-0000-0000-000000000002', 2)
) = '00000000-0000-0000-0000-000000000003' THEN 'ok' ELSE 'fail' END;

-- (2) aplicacao: 1 vinculo (bulk_phone), 1 divergencia (ambiguous), 1 inexistente
CREATE TEMP TABLE run1 AS
  WITH ins AS (
    INSERT INTO talkx_data_sync_runs(job, trigger_source) VALUES ('crm_link_batch','cron') RETURNING id
  ) SELECT id FROM ins;
SELECT talkx_crm_link_apply_batch(
  (SELECT id FROM run1),
  jsonb_build_array(
    jsonb_build_object(
      'contact_id','00000000-0000-0000-0000-000000000001','outcome','linked',
      'external_contact_id','ext-1','external_company_id','cmp-1','normalized_phone','11999990001',
      'candidates', jsonb_build_array(jsonb_build_object('external_contact_id','ext-1','company_id','cmp-1'))),
    jsonb_build_object(
      'contact_id','00000000-0000-0000-0000-000000000002','outcome','ambiguous',
      'candidates', jsonb_build_array(
        jsonb_build_object('external_contact_id','ext-2a','company_id',NULL),
        jsonb_build_object('external_contact_id','ext-2b','company_id',NULL))),
    jsonb_build_object('contact_id','00000000-0000-0000-0000-000000000003','outcome','not_found')
  )
);
SELECT 'batch_link=' || CASE WHEN (
  SELECT link_source FROM crm_contact_links WHERE zapp_contact_id='00000000-0000-0000-0000-000000000001'
) = 'bulk_phone' THEN 'ok' ELSE 'fail' END;
SELECT 'batch_issue=' || CASE WHEN (
  SELECT count(*) FROM talkx_crm_link_issues
   WHERE contact_id='00000000-0000-0000-0000-000000000002' AND issue_type='ambiguous'
     AND resolved_at IS NULL AND jsonb_array_length(candidates) = 2
) = 1 THEN 'ok' ELSE 'fail' END;
SELECT 'batch_counters=' || CASE WHEN (
  SELECT scanned = 3 AND changed = 1 AND skipped = 2 AND failed = 0
  FROM talkx_data_sync_runs WHERE id = (SELECT id FROM run1)
) THEN 'ok' ELSE 'fail' END;
SELECT 'batch_invariant=' || CASE WHEN (
  SELECT changed + skipped + failed = scanned FROM talkx_data_sync_runs WHERE id = (SELECT id FROM run1)
) THEN 'ok' ELSE 'fail' END;

-- (3) segunda execucao: ja vinculado sai da lista e revinculo do mesmo id nao altera nada
SELECT 'second_run_candidates=' || CASE WHEN (
  SELECT count(*) FROM talkx_crm_link_candidates(NULL, 100)
   WHERE id IN ('00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002')
) = 0 THEN 'ok' ELSE 'fail' END;
CREATE TEMP TABLE run2 AS
  WITH ins AS (
    INSERT INTO talkx_data_sync_runs(job, trigger_source) VALUES ('crm_link_batch','cron') RETURNING id
  ) SELECT id FROM ins;
SELECT talkx_crm_link_apply_batch(
  (SELECT id FROM run2),
  jsonb_build_array(jsonb_build_object(
    'contact_id','00000000-0000-0000-0000-000000000001','outcome','linked',
    'external_contact_id','ext-1','normalized_phone','11999990001'))
);
SELECT 'second_run_zero_changed=' || CASE WHEN (
  SELECT changed = 0 AND skipped = 1 AND scanned = 1 FROM talkx_data_sync_runs WHERE id = (SELECT id FROM run2)
) THEN 'ok' ELSE 'fail' END;

-- (4) conflito de unicidade (external_contact_id ja tomado) vira divergencia, nao excecao
INSERT INTO contacts(id,name,phone) VALUES
  ('00000000-0000-0000-0000-000000000009','Conflict','11999990009'),
  ('00000000-0000-0000-0000-000000000010','Bogus','11999990010');
CREATE TEMP TABLE run3 AS
  WITH ins AS (
    INSERT INTO talkx_data_sync_runs(job, trigger_source) VALUES ('crm_link_batch','cron') RETURNING id
  ) SELECT id FROM ins;
SELECT talkx_crm_link_apply_batch(
  (SELECT id FROM run3),
  jsonb_build_array(jsonb_build_object(
    'contact_id','00000000-0000-0000-0000-000000000009','outcome','linked',
    'external_contact_id','ext-1','normalized_phone','11999990009'))
);
SELECT 'conflict_external_taken=' || CASE WHEN (
  SELECT count(*) FROM talkx_crm_link_issues
   WHERE contact_id='00000000-0000-0000-0000-000000000009' AND issue_type='external_taken'
     AND resolved_at IS NULL
) = 1 THEN 'ok' ELSE 'fail' END;
SELECT 'conflict_run=' || CASE WHEN (
  SELECT changed = 0 AND skipped = 1 AND failed = 0 FROM talkx_data_sync_runs WHERE id = (SELECT id FROM run3)
) THEN 'ok' ELSE 'fail' END;

-- (5) CHECK ampliado: aceita import, recusa valor fora da lista
INSERT INTO crm_contact_links(zapp_contact_id, external_contact_id, normalized_phone, link_source)
VALUES ('00000000-0000-0000-0000-000000000003','ext-import','1199999003','import');
DO $$
BEGIN
  BEGIN
    INSERT INTO crm_contact_links(zapp_contact_id, external_contact_id, link_source)
    VALUES ('00000000-0000-0000-0000-000000000010','ext-bogus','bogus');
    RAISE EXCEPTION 'link_source fora da lista foi aceito';
  EXCEPTION WHEN check_violation THEN NULL;
  END;
END $$;
SELECT 'link_source_import=' || CASE WHEN EXISTS (
  SELECT 1 FROM crm_contact_links WHERE link_source = 'import'
) THEN 'ok' ELSE 'fail' END;
SELECT 'link_source_reject_bogus=ok';

-- (6) resolver a divergencia devolve o contato aos candidatos
UPDATE talkx_crm_link_issues SET resolved_at = now(), resolution = 'manual:test'
 WHERE contact_id='00000000-0000-0000-0000-000000000002';
SELECT 'resolved_reopens=' || CASE WHEN EXISTS (
  SELECT 1 FROM talkx_crm_link_candidates(NULL, 100) WHERE id='00000000-0000-0000-0000-000000000002'
) THEN 'ok' ELSE 'fail' END;

-- (7) ACL: RPCs so service_role
SELECT 'rpc_service_only=' || CASE WHEN
  NOT has_function_privilege('authenticated','public.talkx_crm_link_candidates(uuid,integer)','EXECUTE')
  AND has_function_privilege('service_role','public.talkx_crm_link_candidates(uuid,integer)','EXECUTE')
  AND NOT has_function_privilege('authenticated','public.talkx_crm_link_apply_batch(uuid,jsonb)','EXECUTE')
  AND has_function_privilege('service_role','public.talkx_crm_link_apply_batch(uuid,jsonb)','EXECUTE')
  AND NOT has_function_privilege('authenticated','public.get_talkx_data_cron_secret()','EXECUTE')
  AND NOT has_function_privilege('authenticated','public.talkx_run_data_jobs()','EXECUTE')
  AND has_function_privilege('service_role','public.talkx_run_data_jobs()','EXECUTE')
THEN 'ok' ELSE 'fail' END;

-- (8) RLS: leitura so admin/supervisor nas tres tabelas
SELECT 'anon_no_grant=' || CASE WHEN
  NOT has_table_privilege('anon','public.talkx_data_jobs','SELECT')
  AND NOT has_table_privilege('anon','public.talkx_data_sync_runs','SELECT')
  AND NOT has_table_privilege('anon','public.talkx_crm_link_issues','SELECT')
THEN 'ok' ELSE 'fail' END;
DO $$
DECLARE v_jobs integer; v_runs integer; v_issues integer;
BEGIN
  PERFORM set_config('request.jwt.claim.sub','11111111-1111-1111-1111-111111111111', true);
  PERFORM set_config('test.is_admin','false', true);
  SET LOCAL ROLE authenticated;
  SELECT count(*) INTO v_jobs FROM talkx_data_jobs;
  SELECT count(*) INTO v_runs FROM talkx_data_sync_runs;
  SELECT count(*) INTO v_issues FROM talkx_crm_link_issues;
  IF v_jobs <> 0 OR v_runs <> 0 OR v_issues <> 0 THEN
    RAISE EXCEPTION 'agente leu tabela admin-only (jobs=% runs=% issues=%)', v_jobs, v_runs, v_issues;
  END IF;
END $$;
SELECT 'rls_agent_hidden=ok';
DO $$
DECLARE v_jobs integer;
BEGIN
  PERFORM set_config('request.jwt.claim.sub','11111111-1111-1111-1111-111111111111', true);
  PERFORM set_config('test.is_admin','true', true);
  SET LOCAL ROLE authenticated;
  SELECT count(*) INTO v_jobs FROM talkx_data_jobs;
  IF v_jobs <> 1 THEN RAISE EXCEPTION 'admin nao leu talkx_data_jobs (%)', v_jobs; END IF;
END $$;
SELECT 'rls_admin_read=ok';

-- (9) segredo dedicado no Vault + job pg_cron
SELECT 'vault_secret=' || CASE WHEN EXISTS (
  SELECT 1 FROM vault.secrets WHERE name='talkx_data_cron_secret' AND length(secret)=64
) THEN 'ok' ELSE 'fail' END;
SELECT 'cron_job=' || CASE WHEN EXISTS (
  SELECT 1 FROM cron.job WHERE jobname='talkx-data-jobs' AND schedule='4-59/5 * * * *'
) THEN 'ok' ELSE 'fail' END;
DO $$
BEGIN
  BEGIN
    PERFORM set_config('request.jwt.claim.role','authenticated', true);
    SET LOCAL ROLE authenticated;
    PERFORM get_talkx_data_cron_secret();
    RAISE EXCEPTION 'authenticated leu o segredo do cron de dados';
  EXCEPTION WHEN insufficient_privilege THEN NULL;
  END;
END $$;
SELECT 'cron_secret_acl=ok';
SQL
)"

for proof in \
  candidates_eligible=ok keyset_first=ok keyset_next=ok \
  batch_link=ok batch_issue=ok batch_counters=ok batch_invariant=ok \
  second_run_candidates=ok second_run_zero_changed=ok \
  conflict_external_taken=ok conflict_run=ok \
  link_source_import=ok link_source_reject_bogus=ok resolved_reopens=ok \
  rpc_service_only=ok anon_no_grant=ok rls_agent_hidden=ok rls_admin_read=ok \
  vault_secret=ok cron_job=ok cron_secret_acl=ok; do
  grep -Fx "$proof" <<<"$output" >/dev/null || { echo "Missing proof: $proof" >&2; echo "$output" >&2; exit 1; }
done

echo "X036 CRM link batch PostgreSQL 17 behavioral contract: PASS"
