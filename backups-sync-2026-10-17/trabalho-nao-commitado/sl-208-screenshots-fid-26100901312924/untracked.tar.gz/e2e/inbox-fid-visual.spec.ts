/**
 * SL-208 (RES-QA · Inbox/Chat) — screenshots REAIS do Inbox/Chat: mobile 390×844 e light.
 *
 * Cartão t_110644be · item RES-QA do inventário ("Screenshots fid-*.png, mobile e light
 * reais (login de QA bloqueado)") · fonte docs/design/INBOX_FIDELIDADE_STATUS.md.
 *
 * Por que este spec existe: o ledger de fidelidade do Inbox declara que NENHUM screenshot
 * `fid-*.png` foi gerado e que a conferência de mobile e light foi feita só por leitura de
 * código, porque a automação travava na tela de login da conta de QA contra produção/prévia.
 * A regra R1 (05/10/2026) proíbe produção, sessão salva e `e2e/.auth/*`: a prova autenticada
 * passa a ser 100% LOCAL — banco do `zapp-db-local`, usuário sintético criado pelo seed local
 * (`e2e/fixtures/arquivos-local/seed.ts`) e rede externa bloqueada.
 *
 * Como rodar (dentro da cópia de trabalho):
 *   zapp-db-local up . <conjunto>
 *   zapp-db-local env . <conjunto> > .tmp/local-env.raw   # e exporte VITE_ZAPP_LOCAL_* / E2E_*
 *   set -a; . ./.tmp/local-env.sh; set +a
 *   bun e2e/fixtures/arquivos-local/seed.ts
 *   zapp-e2e-local . <conjunto> e2e/inbox-fid-visual.spec.ts --no-deps
 *
 * Saída: `.tmp/fid/fid-06-*.png` (sobrescreva o diretório com INBOX_FID_OUT=<dir>).
 *
 * O que a suíte mede (não é só "tirar foto"):
 *   - lista real do banco local passando por RLS (nada de mock de conversa);
 *   - mobile 390×844: `documentElement.scrollWidth <= innerWidth` (sem overflow horizontal),
 *     chips de status visíveis e a conversa abrindo com header + abas na tela;
 *   - light: superfície clara de fato aplicada e contraste numérico (WCAG) >= 4.5 no texto do
 *     item da lista, no preview e nos chips de status coloridos;
 *   - rede externa abortada: qualquer host fora de 127.0.0.1/localhost reprova no afterEach.
 */
import { test, expect, type Page } from '@playwright/test';
import { mkdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { E2E_ARQUIVOS } from './fixtures/arquivos-local/dados';
import { aplicarTema, contrasteNumerico, CONTRASTE_MINIMO } from './fixtures/arquivos-local/tema';

// Sem sessão salva: a suíte entra pela tela de login com o usuário sintético do seed local.
test.use({ storageState: { cookies: [], origins: [] } });
// Vite dev frio + login real + boot completo da SPA em host compartilhado.
test.setTimeout(180_000);

const HOSTS_PERMITIDOS = new Set(['127.0.0.1', 'localhost', '::1']);
const HOSTS_EXTERNOS_DECORATIVOS = new Set([
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'va.vercel-scripts.com',
]);
const NAV_TIMEOUT = 60_000;
const DESKTOP = { width: 1672, height: 941 };
const MOBILE = { width: 390, height: 844 };

const SAIDA = process.env.INBOX_FID_OUT ?? join('.tmp', 'fid');
const requisicoesExternas: string[] = [];

const itens = (page: Page) => page.locator('[data-testid="conversation-item"]');
const chips = (page: Page) => page.locator('[data-testid^="status-chip-"]');

function caminho(nome: string): string {
  return join(SAIDA, nome);
}

/** Login real pela UI (/auth → auth-login local → GoTrue local). */
async function entrarPelaUI(page: Page): Promise<void> {
  await page.goto('/auth');
  await page.locator('#login-email').fill(E2E_ARQUIVOS.usuario.email);
  await page.locator('#login-password').fill(E2E_ARQUIVOS.usuario.senha);
  await page.getByRole('button', { name: /^entrar$/i }).click();
  await expect(page.locator('#main-navigation')).toBeVisible({ timeout: NAV_TIMEOUT });
}

/** Volta à inbox como visita nova (reload completo) e seleciona o chip determinístico "Todas". */
async function irParaInbox(page: Page): Promise<void> {
  const nav = page.locator('#main-navigation');
  await page.goto('/?view=inbox');
  try {
    await nav.waitFor({ state: 'visible', timeout: 30_000 });
  } catch {
    await page.reload();
    await nav.waitFor({ state: 'visible', timeout: NAV_TIMEOUT });
  }
  // O chip padrão ("Em atendimento") depende do flag inbox.status-fsm e de assigned_to;
  // "Todas" não filtra por status — é o caminho determinístico (mesmo usado pelo e2e do inbox).
  const todas = page.getByTestId('status-chip-all');
  if (await todas.isVisible().catch(() => false)) await todas.click();
  await expect(itens(page).first()).toBeVisible({ timeout: NAV_TIMEOUT });
}

/** Abre a conversa do contato sintético pela busca (não depende de virtualização). */
async function abrirConversa(page: Page, nomeVisivel: string): Promise<void> {
  const busca = page.getByLabel('Buscar contato pelo nome');
  if (await busca.isVisible().catch(() => false)) await busca.fill(nomeVisivel);
  const item = itens(page).filter({ hasText: nomeVisivel }).first();
  await expect(item).toBeVisible({ timeout: NAV_TIMEOUT });
  await item.click();
}

/** Largura de rolagem do documento contra a viewport — o assert do plano (etapa 54). */
async function overflowHorizontal(page: Page): Promise<{ scroll: number; view: number }> {
  return page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    view: window.innerWidth,
  }));
}

async function foto(page: Page, nome: string): Promise<void> {
  const destino = caminho(nome);
  await page.screenshot({ path: destino, animations: 'disabled' });
  expect(statSync(destino).size, `screenshot vazio: ${destino}`).toBeGreaterThan(10_000);
}

const CONJUNTO_LOCAL = Boolean(
  process.env.VITE_ZAPP_LOCAL_SUPABASE_URL && process.env.VITE_ZAPP_LOCAL_SUPABASE_ANON_KEY,
);
test.skip(
  !CONJUNTO_LOCAL,
  'prova local-only: exige VITE_ZAPP_LOCAL_SUPABASE_URL/ANON_KEY do conjunto local (zapp-db-local)',
);

test.describe('Inbox/Chat — screenshots reais local-only (mobile e light)', () => {
  // Serial + contexto compartilhado: cada teste paga um login real e um boot completo da SPA.
  test.describe.configure({ mode: 'serial', retries: 1 });

  let page: Page;

  test.beforeAll(async ({ browser }) => {
    mkdirSync(SAIDA, { recursive: true });
    const contexto = await browser.newContext({
      storageState: { cookies: [], origins: [] },
      viewport: DESKTOP,
    });
    page = await contexto.newPage();
    await page.addInitScript(() => {
      (window as Window & { __BOOT_DEADLINE_MS?: number }).__BOOT_DEADLINE_MS = 60_000;
    });
    // Prova negativa de rede: nada fora do conjunto local é alcançado.
    await page.route('**/*', (route) => {
      const host = new URL(route.request().url()).hostname;
      if (HOSTS_PERMITIDOS.has(host)) return route.continue();
      requisicoesExternas.push(route.request().url());
      return route.abort();
    });
    await entrarPelaUI(page);
  });

  test.beforeEach(() => {
    requisicoesExternas.length = 0;
  });

  test.afterEach(async () => {
    const inesperadas = requisicoesExternas.filter(
      (url) => !HOSTS_EXTERNOS_DECORATIVOS.has(new URL(url).hostname),
    );
    expect(inesperadas, `rede externa fora da lista tolerada: ${inesperadas.join(', ')}`).toEqual([]);
  });

  test.afterAll(async () => {
    await page.context().close();
  });

  test('desktop 1672×941: lista real do banco e conversa aberta', async () => {
    await page.setViewportSize(DESKTOP);
    await irParaInbox(page);

    // Dados reais do seed local, lidos por RLS (nenhum mock de conversa).
    const nomes = await itens(page).allInnerTexts();
    expect(
      nomes.some((t) => t.includes(E2E_ARQUIVOS.contato.nomeVisivel)),
      `contato sintético ausente na lista (vistos: ${JSON.stringify(nomes)}). ` +
        'Rode o seed: bun e2e/fixtures/arquivos-local/seed.ts',
    ).toBe(true);
    await foto(page, 'fid-06-inbox.png');

    await abrirConversa(page, E2E_ARQUIVOS.contato.nomeVisivel);
    await expect(page.getByTestId('conversation-tab-files')).toBeVisible({ timeout: NAV_TIMEOUT });
    await foto(page, 'fid-06-chat.png');

    const { scroll, view } = await overflowHorizontal(page);
    expect(scroll, `overflow horizontal no desktop (scrollWidth ${scroll} > ${view})`).toBeLessThanOrEqual(view);
  });

  test('mobile 390×844: lista em tela cheia, sem overflow; chips visíveis; conversa abre', async () => {
    await page.setViewportSize(MOBILE);
    await irParaInbox(page);
    await expect(itens(page).first()).toBeVisible({ timeout: NAV_TIMEOUT });

    const lista = await overflowHorizontal(page);
    expect(
      lista.scroll,
      `overflow horizontal na lista mobile (scrollWidth ${lista.scroll} > ${lista.view})`,
    ).toBeLessThanOrEqual(lista.view);

    // Chips de status: precisam existir e caber/rolar sem empurrar o documento.
    const nChips = await chips(page).count();
    expect(nChips, 'nenhum chip de status renderizado no mobile').toBeGreaterThan(0);
    await expect(chips(page).first()).toBeVisible();
    await foto(page, 'fid-06-mobile.png');

    await abrirConversa(page, E2E_ARQUIVOS.contato.nomeVisivel);
    const abas = page.locator('[data-testid^="conversation-tab-"]');
    expect(await abas.count(), 'abas da conversa não renderizaram no mobile').toBeGreaterThanOrEqual(3);
    await expect(abas.first()).toBeVisible({ timeout: NAV_TIMEOUT });
    await foto(page, 'fid-06-mobile-chat.png');

    const chat = await overflowHorizontal(page);
    expect(
      chat.scroll,
      `overflow horizontal com a conversa aberta no mobile (scrollWidth ${chat.scroll} > ${chat.view})`,
    ).toBeLessThanOrEqual(chat.view);
  });

  test('light: superfície clara aplicada e contraste WCAG >= 4.5 no texto e nos chips', async () => {
    await page.setViewportSize(DESKTOP);
    await irParaInbox(page);
    await aplicarTema(page, 'claro');
    await page.reload();
    await expect(itens(page).first()).toBeVisible({ timeout: NAV_TIMEOUT });

    // A superfície clara tem de estar REALMENTE aplicada antes de medir contraste.
    const fundo = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const luminancia = (cor: string) => {
      const [r, g, b] = (cor.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number);
      const lin = (v: number) => {
        const c = v / 255;
        return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
      };
      return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
    };
    expect(luminancia(fundo), `tema claro não aplicado (fundo do body: ${fundo})`).toBeGreaterThan(0.5);

    await foto(page, 'fid-06-light.png');

    // Texto do item da lista (nome + preview) e chips de status coloridos.
    const alvos: Array<[string, import('@playwright/test').Locator]> = [
      ['item da lista', itens(page).first()],
    ];
    const nChips = await chips(page).count();
    for (let i = 0; i < nChips; i++) {
      alvos.push([`chip ${i}`, chips(page).nth(i)]);
    }
    const medidas = await Promise.all(alvos.map(([, alvo]) => contrasteNumerico(alvo)));
    const abaixo = alvos
      .map(([nome], i) => `${nome}=${medidas[i].toFixed(2)}`)
      .filter((_, i) => medidas[i] < CONTRASTE_MINIMO);
    expect(
      abaixo,
      `contraste < ${CONTRASTE_MINIMO}:1 no tema claro (valores: ${alvos
        .map(([nome], i) => `${nome}=${medidas[i].toFixed(2)}`)
        .join(', ')})`,
    ).toEqual([]);

    await abrirConversa(page, E2E_ARQUIVOS.contato.nomeVisivel);
    await expect(page.getByTestId('conversation-tab-files')).toBeVisible({ timeout: NAV_TIMEOUT });
    await foto(page, 'fid-06-light-chat.png');
  });
});
