import { memo } from 'react';
import { AlertCircle, Check, CheckCheck, Clock, RotateCcw, type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Message } from '@/types/chat';
import { formatMessageTime } from './messageUtils';

/**
 * SL-197 (item 029 do inventário) — métricas de retry e tentativas por mensagem.
 *
 * FONTE DE DADOS (o que o banco já guarda hoje, sem migration nenhuma): a linha de
 * `messages` traz `delivery_attempt_count`, incrementado pelo RPC
 * `claim_outbound_message` a cada tentativa de entrega (migration
 * 20260909220000), mais `delivery_claimed_at` (início da última tentativa),
 * `status`/`status_updated_at` (resultado atual) e `created_at` (entrada na fila).
 * O `select('*')` de `ChatService.fetchMessages` já devolve esses campos — o dado
 * chegava ao front e não tinha leitor nenhum.
 *
 * O que este painel NÃO é: a tabela `message_attempts` do V3 (uma linha por
 * tentativa, com `error_code` e resposta do provedor) é trilha de banco, fora do
 * escopo deste cartão. Aqui o histórico é montado só com o que existe: quantas
 * tentativas, quando foi a última e qual o resultado. Tentativa sem horário no
 * banco aparece sem horário — nada é inventado no lugar do dado ausente.
 *
 * Só o envio tem tentativa de entrega: mensagem recebida não renderiza nada.
 */
export const MAX_TENTATIVAS_VISIVEIS = 4;

type Tom = 'muted' | 'success' | 'warning' | 'destructive';

const TOM_CLASSE: Record<Tom, string> = {
  muted: 'text-muted-foreground',
  success: 'text-success',
  warning: 'text-warning',
  destructive: 'text-destructive',
};

/** Mesmos textos de estado usados pelo balão (`MessageStatus.tsx`). */
function rotuloDoStatus(status: string | null | undefined): string {
  switch (status) {
    case 'pending':
      return 'Enviando…';
    case 'sent':
      return 'Enviado';
    case 'delivered':
      return 'Entregue';
    case 'read':
      return 'Lido';
    case 'failed':
      return 'Falha no envio';
    default:
      return 'Sem status informado';
  }
}

/** Ícone do resultado atual. Componente de módulo (não criado a cada render). */
function IconeDoStatus({ status, className }: { status: string | null | undefined; className?: string }) {
  switch (status) {
    case 'sent':
      return <Check className={className} aria-hidden="true" />;
    case 'delivered':
    case 'read':
      return <CheckCheck className={className} aria-hidden="true" />;
    case 'failed':
      return <AlertCircle className={className} aria-hidden="true" />;
    default:
      return <Clock className={className} aria-hidden="true" />;
  }
}

function tomDoStatus(status: string | null | undefined): Tom {
  if (status === 'failed') return 'destructive';
  if (status === 'delivered' || status === 'read') return 'success';
  return 'muted';
}

/** `HH:mm` do valor vindo do banco, ou `null` quando está vazio/inválido. */
function horario(valor: string | null | undefined): string | null {
  if (!valor) return null;
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? null : formatMessageTime(data);
}

interface MessageAttemptsTimelineProps {
  message: Message;
  className?: string;
}

function MessageAttemptsTimelineBase({ message, className }: MessageAttemptsTimelineProps) {
  if (message.sender !== 'agent') return null;

  const tentativas = Math.max(0, message.delivery_attempt_count ?? 0);
  const horarioDaFila = horario(message.created_at);
  const horarioDaUltimaTentativa = horario(message.delivery_claimed_at);
  const horarioDoResultado = horario(message.status_updated_at);

  // Tentativas numeradas que a lista mostra: todas quando são poucas; a primeira e a
  // última (com o total das intermediárias entre elas) quando passam do teto.
  const numeros: Array<number | 'resumo'> = tentativas <= MAX_TENTATIVAS_VISIVEIS
    ? Array.from({ length: tentativas }, (_, indice) => indice + 1)
    : [1, 'resumo', tentativas];

  return (
    <div
      data-testid="message-attempts-timeline"
      className={cn('rounded-lg border border-border bg-muted/30 p-2.5', className)}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-foreground">Tentativas de entrega</span>
        <span
          className={cn(
            'text-2xs font-semibold tabular-nums',
            tentativas > 1 ? TOM_CLASSE.warning : TOM_CLASSE.muted,
          )}
        >
          {tentativas === 1 ? '1 tentativa' : `${tentativas} tentativas`}
        </span>
      </div>

      {tentativas === 0 ? (
        <p className="mt-2 text-2xs text-muted-foreground">Sem tentativas de entrega registradas.</p>
      ) : (
        <ol className="mt-2 space-y-1">
          <li
            data-testid="tentativa-fila"
            className="flex items-center justify-between gap-2 text-2xs text-muted-foreground"
          >
            <span className="flex items-center gap-1.5">
              <Clock className="h-3 w-3 shrink-0" aria-hidden="true" />
              Na fila de envio
            </span>
            {horarioDaFila ? <span className="tabular-nums">{horarioDaFila}</span> : null}
          </li>

          {numeros.map((numero) => (
            numero === 'resumo' ? (
              <li
                key="resumo"
                data-testid="tentativas-resumidas"
                className="flex items-center gap-1.5 text-2xs text-muted-foreground"
              >
                <RotateCcw className="h-3 w-3 shrink-0" aria-hidden="true" />
                mais {tentativas - 2} tentativas
              </li>
            ) : (
              <li
                key={numero}
                data-testid={`tentativa-${numero}`}
                className="flex items-center justify-between gap-2 text-2xs text-foreground"
              >
                <span className="flex items-center gap-1.5">
                  <RotateCcw className="h-3 w-3 shrink-0 text-muted-foreground" aria-hidden="true" />
                  Tentativa {numero}
                </span>
                {numero === tentativas && horarioDaUltimaTentativa ? (
                  <span className="tabular-nums text-muted-foreground">{horarioDaUltimaTentativa}</span>
                ) : null}
              </li>
            )
          ))}

          <li
            data-testid="tentativa-resultado"
            className={cn('flex items-center justify-between gap-2 text-2xs font-medium', TOM_CLASSE[tomDoStatus(message.status)])}
          >
            <span className="flex items-center gap-1.5">
              <IconeDoResultado className="h-3 w-3 shrink-0" aria-hidden="true" />
              {rotuloDoStatus(message.status)}
            </span>
            {horarioDoResultado ? <span className="tabular-nums">{horarioDoResultado}</span> : null}
          </li>
        </ol>
      )}
    </div>
  );
}

export const MessageAttemptsTimeline = memo(MessageAttemptsTimelineBase);
