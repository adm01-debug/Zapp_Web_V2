/**
 * SL-197 (item 029 do inventário) — métricas de retry e tentativas por mensagem.
 *
 * O teste renderiza o componente REAL (jsdom, sem mock de rede: o componente não
 * fala com o banco) e prova que o histórico de entrega sai de
 * `messages.delivery_attempt_count` + `delivery_claimed_at` + `status` +
 * `status_updated_at`, campos que o `select('*')` de `ChatService.fetchMessages`
 * já devolve hoje:
 *
 *  - quantas tentativas a mensagem teve (o RPC `claim_outbound_message`
 *    incrementa o contador a cada reivindicação);
 *  - a última tentativa marcada com o horário que o banco guarda;
 *  - tentativa sem horário registrado aparece SEM horário (nada é inventado);
 *  - mensagem sem tentativa alguma diz isso, em vez de exibir "0";
 *  - a lista é limitada: muitas tentativas resumem as intermediárias.
 *
 * Vermelho antes: `MessageAttemptsTimeline` não existia (o import do módulo
 * falhava) — o contador de tentativas do banco não tinha leitor nenhum no front.
 */
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { MAX_TENTATIVAS_VISIVEIS, MessageAttemptsTimeline } from '../MessageAttemptsTimeline';
import type { Message } from '@/types/chat';

/** Horários em hora LOCAL (sem `Z`) para o texto não depender do fuso do runner. */
function mensagem(over: Partial<Message> = {}): Message {
  return {
    id: 'm-1',
    content: 'Olá',
    sender: 'agent',
    type: 'text',
    timestamp: new Date('2026-10-08T11:58:00'),
    created_at: '2026-10-08T11:58:00',
    ...over,
  };
}

describe('MessageAttemptsTimeline — tentativas de entrega por mensagem', () => {
  it('não renderiza nada para mensagem recebida (tentativa de entrega é só do envio)', () => {
    const { container } = render(
      <MessageAttemptsTimeline message={mensagem({ sender: 'contact', delivery_attempt_count: 0 })} />,
    );

    expect(screen.queryByTestId('message-attempts-timeline')).toBeNull();
    expect(container.innerHTML).toBe('');
  });

  it('mensagem sem tentativa registrada diz isso, em vez de mostrar zero', () => {
    render(<MessageAttemptsTimeline message={mensagem({ delivery_attempt_count: 0, status: 'pending' })} />);

    expect(screen.getByTestId('message-attempts-timeline')).toHaveTextContent('Sem tentativas de entrega registradas');
    expect(screen.queryByTestId('tentativa-1')).toBeNull();
  });

  it('uma tentativa: linha da tentativa com o horário do banco + resultado com o horário do status', () => {
    render(
      <MessageAttemptsTimeline
        message={mensagem({
          delivery_attempt_count: 1,
          delivery_claimed_at: '2026-10-08T12:00:00',
          status: 'sent',
          status_updated_at: '2026-10-08T12:03:00',
        })}
      />,
    );

    expect(screen.getByTestId('message-attempts-timeline')).toHaveTextContent('1 tentativa');
    expect(screen.getByTestId('tentativa-fila')).toHaveTextContent('11:58');
    expect(screen.getByTestId('tentativa-1')).toHaveTextContent('Tentativa 1');
    expect(screen.getByTestId('tentativa-1')).toHaveTextContent('12:00');
    expect(screen.getByTestId('tentativa-resultado')).toHaveTextContent('Enviado');
    expect(screen.getByTestId('tentativa-resultado')).toHaveTextContent('12:03');
  });

  it('três tentativas com falha: lista as três, conta 3 e mostra o resultado real', () => {
    render(
      <MessageAttemptsTimeline
        message={mensagem({
          delivery_attempt_count: 3,
          delivery_claimed_at: '2026-10-08T12:00:00',
          status: 'failed',
          status_updated_at: '2026-10-08T12:03:00',
        })}
      />,
    );

    const linhas = screen.getAllByRole('listitem');
    expect(linhas[1]).toHaveTextContent('Tentativa 1');
    expect(linhas[2]).toHaveTextContent('Tentativa 2');
    expect(linhas[3]).toHaveTextContent('Tentativa 3');
    expect(screen.getByTestId('message-attempts-timeline')).toHaveTextContent('3 tentativas');
    expect(screen.getByTestId('tentativa-resultado')).toHaveTextContent('Falha no envio');
  });

  it('tentativa sem horário no banco aparece sem horário — nada é inventado', () => {
    render(
      <MessageAttemptsTimeline
        message={mensagem({
          delivery_attempt_count: 2,
          delivery_claimed_at: null,
          status: null,
          status_updated_at: null,
        })}
      />,
    );

    expect(screen.getByTestId('tentativa-2')).toHaveTextContent('Tentativa 2');
    expect(screen.getByTestId('tentativa-1').textContent ?? '').not.toMatch(/\d{1,2}:\d{2}/);
    expect(screen.getByTestId('tentativa-2').textContent ?? '').not.toMatch(/\d{1,2}:\d{2}/);
    expect(screen.getByTestId('tentativa-resultado')).toHaveTextContent('Sem status informado');
  });

  it('muitas tentativas: resume as intermediárias e mantém a primeira e a última', () => {
    const total = MAX_TENTATIVAS_VISIVEIS * 3;
    render(
      <MessageAttemptsTimeline
        message={mensagem({
          delivery_attempt_count: total,
          delivery_claimed_at: '2026-10-08T12:00:00',
          status: 'pending',
          status_updated_at: '2026-10-08T12:03:00',
        })}
      />,
    );

    expect(screen.getByTestId('tentativa-1')).toHaveTextContent('Tentativa 1');
    expect(screen.getByTestId(`tentativa-${total}`)).toHaveTextContent(`Tentativa ${total}`);
    expect(screen.getByTestId('tentativas-resumidas')).toHaveTextContent(`mais ${total - 2} tentativas`);
    expect(screen.queryByTestId('tentativa-2')).toBeNull();
    // A última tentativa é a que recebeu o horário do banco; a primeira não tem horário registrado.
    expect(screen.getByTestId(`tentativa-${total}`)).toHaveTextContent('12:00');
    expect(screen.getByTestId('tentativa-1').textContent ?? '').not.toMatch(/\d{1,2}:\d{2}/);
    expect(screen.getAllByRole('listitem')).toHaveLength(5);
  });
});
