/**
 * Prova E2E do módulo Multiplix (inventário F90 do
 * docs/multiplix/PLANO_FINALIZACAO_MULTIPLIX_100_ETAPAS_2026-09-29.md).
 *
 * O DEFEITO (F90): o módulo não tinha NENHUMA cobertura E2E — `e2e/multiplix.spec.ts`
 * não existia no baseline, então nem o fluxo, nem o escopo, nem a degradação
 * passavam por navegador nenhum. O caminho de integração pedido no item é o
 * `e2e-logado.yml`; este spec é coletado lá SEM editar o workflow, porque o
 * projeto `chromium-authenticated` (playwright.config.ts:104) é o catch-all dos
 * specs autenticados: ele coleta todo arquivo de `e2e/` que não esteja no
 * `testIgnore`. Prova: `npx playwright test --project=chromium-authenticated --list`
 * (o workflow não lista arquivos, lista PROJETOS — ver e2e/README.md).
 *
 * HERMÉTICO por construção (regra R1 da fábrica): sessão FALSA de
 * `installFakeSession` (e2e/fixtures/talkx-demo.ts), backend do app shell mockado
 * (`mockAppShell`) e TODO o backend do Multiplix respondido por `page.route` —
 * nenhuma credencial, nenhum secret, nenhum banco (nem local, nem de produção).
 * `bloquearRedeReal` barra qualquer requisição ao host do Supabase que escape dos
 * mocks (conferido no `afterEach`), e o WebSocket do Realtime — que NÃO passa por
 * `page.route` — é fechado na porta por `page.routeWebSocket`, senão o monitor
 * abriria um socket para o host real ao montar.
 *
 * O que este spec prova (e o que NÃO prova — medido, não suposto):
 * 1. seleção persistente: a seleção sobrevive ao "Carregar mais" (paginação) e é
 *    zerada por uma busca NOVA (MultiplixView.tsx:87 — comportamento deliberado
 *    do P1 fix do Codex; o protótipo de design pedia o contrário, divergência
 *    registrada no cartão);
 * 2. prévia/confirmação: os chips de placeholder entram no texto composto, o texto
 *    EXATO vai ao `create_draft` (idempotência por `client_request_id`), o botão
 *    "Salvar e iniciar agora" exige a confirmação explícita do AlertDialog e só
 *    então chama `multiplix-send`, e o monitor exibe o template aprovado;
 * 3. placeholder inválido: a autoridade do bloqueio é o SERVIDOR. O front não tem
 *    validação local (nenhum chamador de `validate`/`preview` da edge —
 *    actions/inspect.ts:416-417 não é usado por src/**); ele propaga o erro
 *    nomeado e NADA é criado nem enviado. `multiplix_unknown_placeholder` é o
 *    código real da edge (actions/inspect.ts:300);
 * 4. escopo ponta a ponta: os filtros (Público/Ramo/UF/busca) viajam inteiros no
 *    payload da edge e a lista/contagem vêm JÁ filtradas do servidor (o front não
 *    filtra localmente) — auditoria de escopo é do servidor, por desenho;
 * 5. degradação: com o Singu fora a tela mostra a mensagem que a edge devolve
 *    ("Singu request failed", multiplix-audience/index.ts:672) em vez de lista
 *    vazia silenciosa, e a busca volta a funcionar quando o backend responde —
 *    sem nenhuma escrita no banco em toda a sessão (o Chat fica intocado).
 */
import { test, expect, type Page } from '@playwright/test';

import { bloquearRedeReal, json, mockAppShell, type Registro } from './fixtures/mapa-mocks';
import { installFakeSession } from './fixtures/talkx-demo';

// Sessão FALSA (installFakeSession) — nada de `storageState` real. O
// `chromium-authenticated` declara `storageState: e2e/.auth/user.json`; aqui ele é
// neutralizado para o spec rodar sem login (e sem tocar produção) tanto no CI
// quanto local com `--no-deps`.
test.use({ storageState: { cookies: [], origins: [] } });

// O dev server frio compila o app inteiro na primeira navegação (bem acima dos 30s
// padrão do Playwright) — sem isto a prova reprova por tempo de build.
test.setTimeout(120_000);

const DISPATCH_ID = 'd15a0000-0000-4000-8000-00000000d15a';
const DISPATCH_ANTIGO_ID = 'a1700000-0000-4000-8000-0000000a1700';
const TEXTO_PLACEHOLDER_INVALIDO = 'Olá {{empresa}}, {{inexistente}}!';
const PAGE_SIZE = 50;
const TOTAL_EMPRESAS = 57;

interface Empresa {
  company_id: string;
  company_name: string;
  ramo_atividade: string;
  uf: string;
  is_customer: boolean;
  is_supplier: boolean;
  is_carrier: boolean;
  destino_e164: string | null;
  destino_origem: string;
  motivo_inclusao: string;
}

/** 57 empresas: 50 na 1ª página (PAGE_SIZE) e 7 na 2ª — a paginação é exercitada. */
const EMPRESAS: Empresa[] = Array.from({ length: TOTAL_EMPRESAS }, (_, i) => {
  const n = String(i + 1).padStart(2, '0');
  const papeis = i % 3 === 0 ? ['cliente'] : i % 3 === 1 ? ['fornecedor'] : ['transportadora'];
  return {
    company_id: `c0000000-0000-4000-8000-0000000000${n}`,
    company_name: `Empresa ${n}`,
    ramo_atividade: i % 2 === 0 ? 'Brindes' : 'Gráfica',
    uf: i % 2 === 0 ? 'SP' : 'MG',
    is_customer: papeis.includes('cliente'),
    is_supplier: papeis.includes('fornecedor'),
    is_carrier: papeis.includes('transportadora'),
    destino_e164: `+551190000${n}`,
    destino_origem: 'contato_pessoa',
    motivo_inclusao: 'papel: cliente',
  };
});

interface Estado {
  /** Singu fora do ar: a edge do público responde como em index.ts:672. */
  singuFora: boolean;
  /** O servidor recusa o create_draft por placeholder desconhecido. */
  recusaPlaceholder: boolean;
  /** Corpos recebidos na edge `multiplix-audience`. */
  audience: Array<{ action: string; params: Record<string, unknown> }>;
  /** Corpos recebidos na edge `multiplix-dispatch`. */
  dispatch: Array<{ action: string; payload: Record<string, unknown> }>;
  /** Corpos recebidos na edge `multiplix-send`. */
  send: Array<Record<string, unknown>>;
  /** Escritas (método != GET/HEAD) em /rest/v1/** — tem de ficar vazio. */
  escritasRest: string[];
  /** Leituras do módulo de Chat (messages) — tem de ficar vazio. */
  leiturasChat: string[];
  /** Sockets de Realtime que o guarda fechou (nunca chegam ao host real). */
  socketsFechados: number;
}

/** Papéis de uma empresa, como a edge devolve (PT do Singu). */
function papeisDe(e: Empresa): string[] {
  const papeis: string[] = [];
  if (e.is_customer) papeis.push('cliente');
  if (e.is_supplier) papeis.push('fornecedor');
  if (e.is_carrier) papeis.push('transportadora');
  return papeis;
}

/**
 * O recorte do filtro, do LADO DO SERVIDOR: o front não filtra localmente, então
 * é este filtro que dá sentido às asserções de escopo (a lista/contagem que o
 * app mostra é a resposta já recortada da edge).
 */
function filtrar(params: Record<string, unknown>): Empresa[] {
  const roles = (params.roles as string[] | undefined) ?? [];
  const ramo = params.ramo as string | undefined;
  const uf = params.uf as string | undefined;
  const termo = String(params.search ?? '').toLowerCase();
  return EMPRESAS.filter((e) => {
    if (roles.length > 0 && !roles.some((r) => papeisDe(e).includes(r))) return false;
    if (ramo && e.ramo_atividade !== ramo) return false;
    if (uf && e.uf !== uf) return false;
    if (termo && !e.company_name.toLowerCase().includes(termo)) return false;
    return true;
  });
}

function disparo(id: string, nome: string, template: string, status: string) {
  return {
    id,
    name: nome,
    message_template: template,
    status,
    total_recipients: 2,
    sent_count: 1,
    failed_count: 0,
    delivered_count: 1,
    outcome_unknown_count: 0,
    started_at: '2026-10-08T12:00:00.000Z',
    paused_at: null,
    pause_reason: null,
    completed_at: null,
    created_at: '2026-10-08T12:00:00.000Z',
  };
}

const DESTINATARIOS = [
  {
    id: '11111111-0000-4000-8000-000000000001',
    company_name_snapshot: 'Empresa 01',
    destino_e164: '+55119000001',
    status: 'sent',
    sent_at: '2026-10-08T12:00:05.000Z',
    error_message: null,
    personalized_message: 'Olá Empresa 01',
  },
];

/** Registra o backend inteiro do Multiplix (as 3 edges do módulo). */
async function montarBackend(page: Page, estado: Estado): Promise<void> {
  await page.route('**/functions/v1/multiplix-audience', (route) => {
    const corpo = (route.request().postDataJSON() ?? {}) as { action?: string; params?: Record<string, unknown> };
    const params = corpo.params ?? {};
    estado.audience.push({ action: String(corpo.action), params });

    // Singu fora: mesma resposta da edge quando a ponte falha (index.ts:672).
    if (estado.singuFora) return json(route, { error: 'Singu request failed' }, 502);

    switch (corpo.action) {
      case 'list_ramos':
        return json(route, {
          data: [
            { ramo_atividade: 'Brindes', total: 29 },
            { ramo_atividade: 'Gráfica', total: 28 },
          ],
        });
      case 'list_ufs':
        return json(route, {
          data: [
            { uf: 'SP', total: 29 },
            { uf: 'MG', total: 28 },
          ],
        });
      case 'search': {
        const linhas = filtrar(params);
        const tamanho = Number(params.page_size ?? PAGE_SIZE);
        const inicio = Number(params.page ?? 0) * tamanho;
        return json(route, { data: linhas.slice(inicio, inicio + tamanho) });
      }
      case 'count':
        return json(route, { data: filtrar(params).length });
      case 'resolve':
        return json(route, { data: [] });
      case 'create_draft': {
        // O servidor é a autoridade do bloqueio por placeholder (F48/validate).
        if (estado.recusaPlaceholder) {
          return json(route, { error: 'multiplix_unknown_placeholder' }, 400);
        }
        const ids = (params.company_ids as string[] | undefined) ?? [];
        return json(route, {
          data: { dispatch_id: DISPATCH_ID, recipient_count: ids.length, created: true },
        });
      }
      default:
        return json(route, { error: 'Action is not allowed' }, 400);
    }
  });

  await page.route('**/functions/v1/multiplix-dispatch', (route) => {
    const corpo = (route.request().postDataJSON() ?? {}) as {
      action?: string;
      payload?: Record<string, unknown>;
    };
    const payload = corpo.payload ?? {};
    estado.dispatch.push({ action: String(corpo.action), payload });

    if (corpo.action === 'dispatch.list') {
      const todos = [
        disparo(DISPATCH_ID, 'Convite feira 2026', '{{empresa}} {{saudacao}}', 'sending'),
        disparo(DISPATCH_ANTIGO_ID, '[E2E] Disparo antigo', 'Olá {{empresa}}', 'completed'),
      ];
      const linhas = payload.dispatch_id ? todos.filter((d) => d.id === payload.dispatch_id) : todos;
      return json(route, {
        data: linhas,
        meta: { limit: payload.limit, offset: payload.offset, total: linhas.length },
      });
    }
    if (corpo.action === 'recipients.list') {
      const linhas = payload.status === 'skipped' ? [] : DESTINATARIOS;
      return json(route, { data: linhas, meta: { total: linhas.length } });
    }
    return json(route, { data: [] });
  });

  await page.route('**/functions/v1/multiplix-send', (route) => {
    estado.send.push((route.request().postDataJSON() ?? {}) as Record<string, unknown>);
    return json(route, { ok: true });
  });
}

async function abrirMultiplix(page: Page): Promise<void> {
  await page.goto('/?view=multiplix');
  await expect(page.getByRole('heading', { name: 'Multiplix' })).toBeVisible({ timeout: 60_000 });
}

/** Busca o público e devolve quando a tabela (ou o erro) aparece. */
async function buscar(page: Page): Promise<void> {
  await page.getByRole('button', { name: 'Buscar' }).click();
  await expect(page.getByText(/empresa\(s\) no filtro atual|Empresa \d\d|Singu request failed/).first()).toBeVisible({
    timeout: 30_000,
  });
}

async function abrirComposer(page: Page): Promise<void> {
  await page.getByRole('button', { name: 'Criar disparo' }).click();
  await expect(page.getByRole('dialog', { name: 'Novo disparo Multiplix' })).toBeVisible();
}

async function preencher(page: Page, { nome, texto }: { nome: string; texto: string }): Promise<void> {
  await page.getByPlaceholder('Ex.: Convite feira 2026').fill(nome);
  await page.getByPlaceholder('Olá {{empresa}}, {{saudacao}}!').fill(texto);
}

test.describe('Multiplix — seleção persistente do público', () => {
  let registro: Registro;
  let estado: Estado;

  test.beforeEach(async ({ page }) => {
    await page.addInitScript(() => {
      (window as Window & { __BOOT_DEADLINE_MS?: number }).__BOOT_DEADLINE_MS = 60_000;
    });
    registro = { writesApp: [], mapbox: [], redeBarrada: [] };
    estado = {
      singuFora: false,
      recusaPlaceholder: false,
      audience: [],
      dispatch: [],
      send: [],
      escritasRest: [],
      leiturasChat: [],
      socketsFechados: 0,
    };
    // O guarda vai PRIMEIRO: o Playwright casa as rotas na ordem inversa, então
    // ele é o último a valer — só pega o que nenhum mock específico cobriu.
    await bloquearRedeReal(page, registro);
    // O WebSocket do Realtime NÃO passa por `page.route`: sem esta linha o
    // navegador abriria um socket para o host real do Supabase ao montar o monitor.
    await page.routeWebSocket(/supabase\.co/, (ws) => {
      estado.socketsFechados += 1;
      ws.close();
    });
    await mockAppShell(page, registro);
    await installFakeSession(page);
    await page.route(/\/rest\/v1\/contacts/, (route) => json(route, []));
    await page.route(/\/rest\/v1\/messages/, (route) => json(route, []));
    await montarBackend(page, estado);

    // Vigia do banco: nada é escrito em /rest/v1/** (o app não escreve direto no
    // PostgREST neste módulo) e o Chat não é lido durante o fluxo do Multiplix.
    page.on('request', (req) => {
      const url = req.url();
      if (!/\/rest\/v1\//.test(url)) return;
      const metodo = req.method();
      if (metodo !== 'GET' && metodo !== 'HEAD') {
        estado.escritasRest.push(`${metodo} ${url}`);
        return;
      }
      if (/\/rest\/v1\/messages/.test(url)) estado.leiturasChat.push(url);
    });
  });

  test.afterEach(() => {
    expect(registro.redeBarrada).toEqual([]);
  });

  test('a busca devolve a lista paginada e a contagem exata do servidor', async ({ page }) => {
    await abrirMultiplix(page);
    await buscar(page);

    // Linhas do servidor: 50 na 1ª página (PAGE_SIZE).
    await expect(page.getByRole('row', { name: /Empresa 01/ })).toBeVisible();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 50' })).toBeVisible();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 51' })).toHaveCount(0);
    // Contagem exata da RPC `count` (57 no total), com o quanto está na tela.
    await expect(page.getByText(/57 empresa\(s\) no filtro atual\. Mostrando 50\./)).toBeVisible();
    // "Carregar mais" com o restante calculado do lado do servidor.
    await expect(page.getByRole('button', { name: 'Carregar mais (7 restantes)' })).toBeVisible();
  });

  test('a seleção sobrevive ao Carregar mais e é zerada por uma busca nova', async ({ page }) => {
    await abrirMultiplix(page);
    await buscar(page);

    await page.getByRole('checkbox', { name: 'Selecionar Empresa 01' }).click();
    await page.getByRole('checkbox', { name: 'Selecionar Empresa 02' }).click();
    await expect(page.getByText(/2 empresa\(s\) selecionada\(s\)/)).toBeVisible();

    // Paginação: a 2ª página é ANEXADA e a seleção anterior continua marcada.
    await page.getByRole('button', { name: 'Carregar mais (7 restantes)' }).click();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 57' })).toBeVisible();
    await expect(page.getByText(/2 empresa\(s\) selecionada\(s\)/)).toBeVisible();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 01' })).toBeChecked();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 02' })).toBeChecked();

    await page.getByRole('checkbox', { name: 'Selecionar Empresa 57' }).click();
    await expect(page.getByText(/3 empresa\(s\) selecionada\(s\)/)).toBeVisible();

    // Busca NOVA zera a seleção (MultiplixView.tsx:87) — nenhum id da busca
    // anterior sobrevive para virar destinatário de um disparo novo.
    await page.getByRole('button', { name: 'Buscar' }).click();
    await expect(page.getByText(/empresa\(s\) selecionada\(s\)/)).toHaveCount(0);
    await expect(page.getByText(/57 empresa\(s\) no filtro atual/)).toBeVisible();
  });
});

test.describe('Multiplix — prévia do texto e confirmação do disparo', () => {
  let registro: Registro;
  let estado: Estado;

  test.beforeEach(async ({ page }) => {
    await page.addInitScript(() => {
      (window as Window & { __BOOT_DEADLINE_MS?: number }).__BOOT_DEADLINE_MS = 60_000;
    });
    registro = { writesApp: [], mapbox: [], redeBarrada: [] };
    estado = {
      singuFora: false,
      recusaPlaceholder: false,
      audience: [],
      dispatch: [],
      send: [],
      escritasRest: [],
      leiturasChat: [],
      socketsFechados: 0,
    };
    await bloquearRedeReal(page, registro);
    await page.routeWebSocket(/supabase\.co/, (ws) => {
      estado.socketsFechados += 1;
      ws.close();
    });
    await mockAppShell(page, registro);
    await installFakeSession(page);
    await page.route(/\/rest\/v1\/contacts/, (route) => json(route, []));
    await page.route(/\/rest\/v1\/messages/, (route) => json(route, []));
    await montarBackend(page, estado);

    page.on('request', (req) => {
      const url = req.url();
      if (!/\/rest\/v1\//.test(url)) return;
      const metodo = req.method();
      if (metodo !== 'GET' && metodo !== 'HEAD') {
        estado.escritasRest.push(`${metodo} ${url}`);
        return;
      }
      if (/\/rest\/v1\/messages/.test(url)) estado.leiturasChat.push(url);
    });
  });

  test.afterEach(() => {
    expect(registro.redeBarrada).toEqual([]);
  });

  test('os chips compõem a prévia e o texto exato vai ao create_draft', async ({ page }) => {
    await abrirMultiplix(page);
    await buscar(page);
    await page.getByRole('checkbox', { name: 'Selecionar Empresa 01' }).click();
    await abrirComposer(page);

    await expect(page.getByText('1 empresa(s) selecionada(s) da busca.')).toBeVisible();
    // Prévia por placeholder: o chip insere o token exato no corpo que será enviado.
    await page.getByRole('button', { name: '+ Empresa' }).click();
    await page.getByRole('button', { name: '+ Saudação' }).click();
    await expect(page.getByPlaceholder('Olá {{empresa}}, {{saudacao}}!')).toHaveValue('{{empresa}} {{saudacao}}');

    await preencher(page, { nome: 'Convite feira 2026', texto: '{{empresa}} {{saudacao}}' });
    await page.getByRole('button', { name: 'Salvar rascunho' }).click();

    // O payload REAL que o servidor recebe — não basta "algum POST saiu".
    await expect.poll(() => estado.audience.filter((c) => c.action === 'create_draft').length).toBe(1);
    const criacao = estado.audience.find((c) => c.action === 'create_draft')!.params;
    expect(criacao).toMatchObject({
      name: 'Convite feira 2026',
      message_template: '{{empresa}} {{saudacao}}',
      company_ids: ['c0000000-0000-4000-8000-000000000001'],
      scheduled_at: null,
      confirm_over_limit: false,
    });
    // Chave de idempotência: uuid do cliente (useMultiplixDispatches.ts:347).
    expect(String(criacao.client_request_id)).toMatch(/^[0-9a-f-]{36}$/);
    // Rascunho NÃO inicia o envio.
    expect(estado.send).toEqual([]);

    // O monitor abre no disparo criado e mostra o template aprovado (a prévia do
    // que foi confirmado), lido por dispatch_id — não da lista de recentes.
    await expect(page.getByRole('heading', { name: 'Convite feira 2026' })).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('{{empresa}} {{saudacao}}').first()).toBeVisible();
    expect(estado.dispatch.some((c) => c.action === 'dispatch.list' && c.payload.dispatch_id === DISPATCH_ID)).toBe(true);
    await expect(page.getByText(/1 de 2/)).toBeVisible();
  });

  test('iniciar agora só envia depois da confirmação explícita', async ({ page }) => {
    await abrirMultiplix(page);
    await buscar(page);
    await page.getByRole('checkbox', { name: 'Selecionar Empresa 01' }).click();
    await abrirComposer(page);
    await preencher(page, { nome: 'Convite feira 2026', texto: 'Olá {{empresa}}' });

    await page.getByRole('button', { name: 'Salvar e iniciar agora' }).click();
    const confirmacao = page.getByRole('alertdialog', { name: 'Iniciar disparo agora?' });
    await expect(confirmacao).toBeVisible();
    await expect(confirmacao).toContainText('envia mensagens reais no WhatsApp');
    // Antes de confirmar, NADA foi criado nem enviado.
    expect(estado.audience.some((c) => c.action === 'create_draft')).toBe(false);
    expect(estado.send).toEqual([]);

    await confirmacao.getByRole('button', { name: 'Iniciar agora' }).click();
    await expect.poll(() => estado.send.length).toBe(1);
    expect(estado.send[0]).toMatchObject({ dispatchId: DISPATCH_ID, action: 'start' });
    await expect(page.getByRole('heading', { name: 'Convite feira 2026' })).toBeVisible({ timeout: 20_000 });
  });

  test('placeholder inválido: o servidor recusa e nada é criado ou enviado', async ({ page }) => {
    estado.recusaPlaceholder = true;
    await abrirMultiplix(page);
    await buscar(page);
    await page.getByRole('checkbox', { name: 'Selecionar Empresa 01' }).click();
    await abrirComposer(page);
    await preencher(page, { nome: 'Convite feira 2026', texto: TEXTO_PLACEHOLDER_INVALIDO });

    await page.getByRole('button', { name: 'Salvar e iniciar agora' }).click();
    await page.getByRole('alertdialog', { name: 'Iniciar disparo agora?' })
      .getByRole('button', { name: 'Iniciar agora' })
      .click();

    // O erro nomeado da edge aparece para o operador (useMultiplixAudience.ts:42).
    await expect(page.getByText('multiplix_unknown_placeholder')).toBeVisible({ timeout: 20_000 });

    // Confirmação BLOQUEADA: o composer continua aberto, nenhum disparo existe e
    // nenhum envio saiu — o texto inválido não virou mensagem no WhatsApp.
    await expect(page.getByRole('dialog', { name: 'Novo disparo Multiplix' })).toBeVisible();
    await expect(page.getByPlaceholder('Olá {{empresa}}, {{saudacao}}!')).toHaveValue(TEXTO_PLACEHOLDER_INVALIDO);
    expect(estado.send).toEqual([]);
    expect(estado.dispatch.some((c) => c.payload.dispatch_id === DISPATCH_ID)).toBe(false);
    await expect(page.getByRole('heading', { name: 'Convite feira 2026' })).toHaveCount(0);
  });
});

test.describe('Multiplix — escopo no servidor e degradação do Singu', () => {
  let registro: Registro;
  let estado: Estado;

  test.beforeEach(async ({ page }) => {
    await page.addInitScript(() => {
      (window as Window & { __BOOT_DEADLINE_MS?: number }).__BOOT_DEADLINE_MS = 60_000;
    });
    registro = { writesApp: [], mapbox: [], redeBarrada: [] };
    estado = {
      singuFora: false,
      recusaPlaceholder: false,
      audience: [],
      dispatch: [],
      send: [],
      escritasRest: [],
      leiturasChat: [],
      socketsFechados: 0,
    };
    await bloquearRedeReal(page, registro);
    await page.routeWebSocket(/supabase\.co/, (ws) => {
      estado.socketsFechados += 1;
      ws.close();
    });
    await mockAppShell(page, registro);
    await installFakeSession(page);
    await page.route(/\/rest\/v1\/contacts/, (route) => json(route, []));
    await page.route(/\/rest\/v1\/messages/, (route) => json(route, []));
    await montarBackend(page, estado);

    page.on('request', (req) => {
      const url = req.url();
      if (!/\/rest\/v1\//.test(url)) return;
      const metodo = req.method();
      if (metodo !== 'GET' && metodo !== 'HEAD') {
        estado.escritasRest.push(`${metodo} ${url}`);
        return;
      }
      if (/\/rest\/v1\/messages/.test(url)) estado.leiturasChat.push(url);
    });
  });

  test.afterEach(() => {
    expect(registro.redeBarrada).toEqual([]);
    // Nada foi escrito no banco em nenhuma altura do fluxo.
    expect(estado.escritasRest).toEqual([]);
  });

  test('o filtro viaja inteiro para a edge e a lista volta já recortada pelo servidor', async ({ page }) => {
    await abrirMultiplix(page);

    await page.getByRole('combobox', { name: 'Público' }).click();
    await page.getByRole('option', { name: 'Fornecedor' }).click();
    await page.getByRole('combobox', { name: 'Ramo' }).click();
    await page.getByRole('option', { name: /Brindes/ }).click();
    await page.getByRole('combobox', { name: 'UF' }).click();
    await page.getByRole('option', { name: /^SP/ }).click();
    await page.getByPlaceholder('Nome da empresa...').fill('Empresa 04');
    await page.getByRole('button', { name: 'Buscar' }).click();

    await expect.poll(() => estado.audience.filter((c) => c.action === 'count').length).toBe(1);
    const busca = estado.audience.find((c) => c.action === 'search')!.params;
    const contagem = estado.audience.find((c) => c.action === 'count')!.params;

    // Os quatro filtros vão no payload — o servidor é quem aplica o escopo.
    for (const params of [busca, contagem]) {
      expect(params).toMatchObject({ roles: ['fornecedor'], ramo: 'Brindes', uf: 'SP', search: 'Empresa 04' });
    }
    expect(busca).toMatchObject({ page: 0, page_size: PAGE_SIZE });

    // A resposta recortada do servidor é o que a tela mostra: Empresa 04 é
    // fornecedor? não (i=3 → transportadora) — a lista fica vazia e o aviso da
    // tabela aparece, provando que o recorte veio da edge e não de um filtro local.
    await expect(page.getByText('0 empresa(s) no filtro atual.')).toBeVisible();
    await expect(page.getByText('Nenhuma empresa encontrada para este filtro.')).toBeVisible();

    // Agora um recorte com resultado: UF=SP e sem termo → as 29 empresas de SP.
    await page.getByRole('combobox', { name: 'Público' }).click();
    await page.getByRole('option', { name: 'Todos' }).click();
    await page.getByPlaceholder('Nome da empresa...').fill('');
    await page.getByRole('button', { name: 'Buscar' }).click();
    await expect(page.getByText(/29 empresa\(s\) no filtro atual/)).toBeVisible();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 01' })).toBeVisible();
  });

  test('Singu fora: erro claro na tela, recuperação e nenhum efeito no resto do app', async ({ page }) => {
    estado.singuFora = true;
    await abrirMultiplix(page);
    await page.getByRole('button', { name: 'Buscar' }).click();

    // Erro CLARO: a mensagem da edge aparece na tela em vez de uma lista vazia
    // silenciosa (MultiplixView.tsx:333) e nenhuma linha de público é mostrada.
    await expect(page.getByText('Singu request failed')).toBeVisible({ timeout: 30_000 });
    await expect(page.getByRole('checkbox', { name: /^Selecionar Empresa/ })).toHaveCount(0);
    await expect(page.getByRole('heading', { name: 'Multiplix' })).toBeVisible();

    // O Singu volta: a mesma tela recupera sem recarregar a página.
    estado.singuFora = false;
    await page.getByRole('button', { name: 'Buscar' }).click();
    await expect(page.getByRole('checkbox', { name: 'Selecionar Empresa 01' })).toBeVisible({ timeout: 30_000 });
    await expect(page.getByText('Singu request failed')).toHaveCount(0);

    // Chat INTOCADO: nenhuma leitura do módulo de conversas em toda a sessão.
    expect(estado.leiturasChat).toEqual([]);
    // Nenhuma requisição escapou dos mocks para o host real do Supabase.
    expect(registro.redeBarrada).toEqual([]);
  });
});
