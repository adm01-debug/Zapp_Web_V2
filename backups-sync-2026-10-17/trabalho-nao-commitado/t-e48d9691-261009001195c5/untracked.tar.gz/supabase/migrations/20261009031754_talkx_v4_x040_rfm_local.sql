-- talkx_v4_x040_rfm_local
-- Rollback:
--   DROP FUNCTION IF EXISTS public.talkx_recompute_purchase_metrics(integer);
--   DELETE FROM public.talkx_data_jobs   WHERE job = 'recompute_purchase_metrics';
--   DELETE FROM public.talkx_settings    WHERE key = 'rfm_bands';
--   -- As colunas/objetos de talkx_contact_attributes e talkx_data_jobs ficam: são
--   -- aditivos e nullable, e as donas do desenho completo são a X037 e a X036.
--   -- Derrubá-las seria mudança destrutiva (perderia dados de compra já calculados),
--   -- fora do escopo de um rollback aditivo.
--
-- X040 · Talk X / F04 (docs/talkx/v4/etapas/F04-dados-comerciais-e-vinculo-com-o-crm.md)
-- "Calcular recência, frequência, valor e segmento RFM a partir das compras locais".
--
-- O que esta migration entrega:
--   1. public.talkx_contact_attributes — as colunas de compra/RFM que a X040 escreve.
--      Traz o MÍNIMO que o job precisa; a X037 é a dona do desenho completo da projeção
--      e acrescenta as demais colunas com ADD COLUMN IF NOT EXISTS.
--   2. public.talkx_data_jobs — registro dos jobs da trilha de dados (job, intervalo,
--      último início, habilitado). O runner talkx_run_data_jobs() e o job pg_cron
--      `talkx-data-jobs` são da X036; aqui entra só a LINHA do job desta etapa
--      (1×/dia = 1440 min), por ON CONFLICT (job) DO NOTHING (não sobrescreve o que o
--      operador já desabilitou).
--   3. public.talkx_settings.rfm_bands — faixas configuráveis das notas R/F/M.
--   4. public.talkx_recompute_purchase_metrics(p_limit) — recalcula, para cada contato
--      COM compra: last_purchase_at, orders_count, total_spent, avg_ticket,
--      rfm_recency_days, rfm_frequency, rfm_monetary (notas 1..5) e rfm_segment.
--      Contato sem compra continua com os campos NULOS — não vira "Hibernando".
--
-- Classe: aditiva (tabela/coluna nullable novas, função nova, seed idempotente).
-- Idempotente: reaplicar não duplica tabela, policy, função, índice nem linha de seed.
-- Fuso do cálculo: America/Sao_Paulo (dia de referência para os dias de recência).

-- =====================================================================================
-- 1. Projeção de atributos comerciais — colunas de compra/RFM (recorte da X040)
-- =====================================================================================
CREATE TABLE IF NOT EXISTS public.talkx_contact_attributes (
  contact_id uuid PRIMARY KEY REFERENCES public.contacts(id) ON DELETE CASCADE
);

ALTER TABLE public.talkx_contact_attributes
  ADD COLUMN IF NOT EXISTS last_purchase_at    timestamptz,
  ADD COLUMN IF NOT EXISTS orders_count        integer,
  ADD COLUMN IF NOT EXISTS total_spent         numeric(14,2),
  ADD COLUMN IF NOT EXISTS avg_ticket          numeric(14,2),
  ADD COLUMN IF NOT EXISTS rfm_recency_days    integer,
  ADD COLUMN IF NOT EXISTS rfm_frequency       smallint,
  ADD COLUMN IF NOT EXISTS rfm_monetary        smallint,
  ADD COLUMN IF NOT EXISTS rfm_segment         text,
  ADD COLUMN IF NOT EXISTS purchases_synced_at timestamptz,
  ADD COLUMN IF NOT EXISTS updated_at          timestamptz NOT NULL DEFAULT now();

-- Faixa das notas R/F/M (1..5) e do segmento — o job grava, o banco garante o domínio.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.talkx_contact_attributes'::regclass
      AND conname  = 'talkx_contact_attributes_rfm_notes_check'
  ) THEN
    ALTER TABLE public.talkx_contact_attributes
      ADD CONSTRAINT talkx_contact_attributes_rfm_notes_check CHECK (
        (rfm_frequency  IS NULL OR rfm_frequency  BETWEEN 1 AND 5) AND
        (rfm_monetary   IS NULL OR rfm_monetary   BETWEEN 1 AND 5) AND
        (rfm_recency_days IS NULL OR rfm_recency_days >= 0)
      );
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_talkx_contact_attributes_rfm_segment
  ON public.talkx_contact_attributes (rfm_segment);
CREATE INDEX IF NOT EXISTS idx_talkx_contact_attributes_last_purchase
  ON public.talkx_contact_attributes (last_purchase_at DESC);

ALTER TABLE public.talkx_contact_attributes ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.talkx_contact_attributes FROM PUBLIC;
REVOKE ALL ON public.talkx_contact_attributes FROM anon;
GRANT SELECT ON public.talkx_contact_attributes TO authenticated;
GRANT ALL    ON public.talkx_contact_attributes TO service_role;

-- Leitura: admin/supervisor ou quem enxerga o contato (mesma regra da X037).
-- Nenhum INSERT/UPDATE/DELETE para authenticated: quem escreve é o job (service_role).
DROP POLICY IF EXISTS "talkx_contact_attributes_read_scope" ON public.talkx_contact_attributes;
CREATE POLICY "talkx_contact_attributes_read_scope"
  ON public.talkx_contact_attributes
  FOR SELECT TO authenticated
  USING (
    public.is_admin_or_supervisor(auth.uid())
    OR public.is_contact_visible_to_user(contact_id, auth.uid())
  );

-- =====================================================================================
-- 2. Registro dos jobs da trilha de dados (recorte da X036) + a linha desta etapa
-- =====================================================================================
CREATE TABLE IF NOT EXISTS public.talkx_data_jobs (
  job           text PRIMARY KEY,
  interval_minutes integer NOT NULL DEFAULT 1440,
  last_started_at  timestamptz,
  enabled          boolean NOT NULL DEFAULT true,
  updated_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.talkx_data_jobs ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.talkx_data_jobs FROM PUBLIC;
REVOKE ALL ON public.talkx_data_jobs FROM anon;
GRANT SELECT ON public.talkx_data_jobs TO authenticated;
GRANT ALL    ON public.talkx_data_jobs TO service_role;

DROP POLICY IF EXISTS "talkx_data_jobs_admin_read" ON public.talkx_data_jobs;
CREATE POLICY "talkx_data_jobs_admin_read"
  ON public.talkx_data_jobs
  FOR SELECT TO authenticated
  USING (public.is_admin_or_supervisor(auth.uid()));

-- Linha do job desta etapa: 1×/dia. DO NOTHING preserva eventual decisão do operador.
INSERT INTO public.talkx_data_jobs (job, interval_minutes, enabled)
VALUES ('recompute_purchase_metrics', 1440, true)
ON CONFLICT (job) DO NOTHING;

-- =====================================================================================
-- 3. Faixas das notas R/F/M (configurável em talkx_settings.rfm_bands)
--    recência: 30/90/180/365 dias · frequência: 1, 2, 3–4, 5–9, 10+
--    valor: faixas por ticket acumulado; com 100+ compradores, por quintis.
-- =====================================================================================
INSERT INTO public.talkx_settings (key, value, description)
VALUES (
  'rfm_bands',
  '{
     "version": 1,
     "recency_days": {"5": 30, "4": 90, "3": 180, "2": 365},
     "frequency_counts": {"1": 1, "2": 2, "3": 4, "4": 9},
     "monetary_bands": {"1": 100, "2": 500, "3": 2000, "4": 5000},
     "monetary_min_buyers_for_quintiles": 100
   }'::jsonb,
  'Faixas das notas R/F/M (1..5) do job talkx_recompute_purchase_metrics'
)
ON CONFLICT (key) DO NOTHING;

-- =====================================================================================
-- 4. talkx_recompute_purchase_metrics(p_limit)
-- =====================================================================================
CREATE OR REPLACE FUNCTION public.talkx_recompute_purchase_metrics(p_limit integer DEFAULT 1000)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $fn$
DECLARE
  -- Tabela de decisão do segmento, versão 1 (mesma ordem do documento da F04):
  --   1 Campeões    R>=4 e F>=4 e M>=4
  --   2 Leais       R>=3 e F>=3
  --   3 Novos       F=1 e R>=4
  --   4 Em potencial R>=3 e F<=2
  --   5 Em risco    R<=2 e F>=3
  --   6 Hibernando  R=2 e F<=2
  --   7 Perdidos    R<=2 (e F<=2)
  -- Primeira regra que casa vence; todo par (R,F) cai em exatamente um segmento.
  v_bands      jsonb;
  v_ref_date   date := (now() AT TIME ZONE 'America/Sao_Paulo')::date;
  v_buyers     integer := 0;
  v_quintiles  boolean := false;
  v_processed  integer := 0;
  v_changed    integer := 0;
  v_rows       integer := 0;
  r            record;
  v_r          integer;
  v_f          integer;
  v_m          integer;
  v_segment    text;
BEGIN
  IF p_limit IS NULL OR p_limit < 1 THEN
    RAISE EXCEPTION 'talkx_rfm_invalid_limit' USING ERRCODE = '22023';
  END IF;

  SELECT value INTO v_bands FROM public.talkx_settings WHERE key = 'rfm_bands';
  IF v_bands IS NULL THEN
    -- Sem a chave, o job usa o MESMO padrão que o seed (não deixa contato sem cálculo).
    v_bands := '{"version":1,
      "recency_days":{"5":30,"4":90,"3":180,"2":365},
      "frequency_counts":{"1":1,"2":2,"3":4,"4":9},
      "monetary_bands":{"1":100,"2":500,"3":2000,"4":5000},
      "monetary_min_buyers_for_quintiles":100}'::jsonb;
  END IF;

  -- Com 100 ou mais compradores, a nota de valor sai por quintis do total comprado.
  SELECT count(DISTINCT p.contact_id) INTO v_buyers
  FROM public.contact_purchases p
  WHERE p.purchased_at IS NOT NULL;
  v_quintiles := v_buyers >= COALESCE((v_bands ->> 'monetary_min_buyers_for_quintiles')::integer, 100);

  FOR r IN
    WITH agg AS (
      SELECT p.contact_id,
             max(p.purchased_at)                                 AS last_purchase_at,
             count(*)::integer                                   AS orders_count,
             coalesce(sum(coalesce(p.amount, 0)), 0)::numeric(14,2) AS total_spent
      FROM public.contact_purchases p
      WHERE p.purchased_at IS NOT NULL
      GROUP BY p.contact_id
    ), scored AS (
      SELECT a.contact_id,
             a.last_purchase_at,
             a.orders_count,
             a.total_spent,
             (a.total_spent / a.orders_count)::numeric(14,2) AS avg_ticket,
             (v_ref_date - (a.last_purchase_at AT TIME ZONE 'America/Sao_Paulo')::date)::integer AS recency_days,
             CASE WHEN v_quintiles
                  THEN ntile(5) OVER (ORDER BY a.total_spent, a.contact_id)
                  ELSE NULL END AS quintil
      FROM agg a
    )
    SELECT * FROM scored ORDER BY contact_id LIMIT p_limit
  LOOP
    v_r := CASE WHEN r.recency_days <= (v_bands #>> '{recency_days,5}')::integer THEN 5
                WHEN r.recency_days <= (v_bands #>> '{recency_days,4}')::integer THEN 4
                WHEN r.recency_days <= (v_bands #>> '{recency_days,3}')::integer THEN 3
                WHEN r.recency_days <= (v_bands #>> '{recency_days,2}')::integer THEN 2
                ELSE 1 END;

    v_f := CASE WHEN r.orders_count <= (v_bands #>> '{frequency_counts,1}')::integer THEN 1
                WHEN r.orders_count <= (v_bands #>> '{frequency_counts,2}')::integer THEN 2
                WHEN r.orders_count <= (v_bands #>> '{frequency_counts,3}')::integer THEN 3
                WHEN r.orders_count <= (v_bands #>> '{frequency_counts,4}')::integer THEN 4
                ELSE 5 END;

    IF v_quintiles THEN
      v_m := r.quintil;
    ELSE
      v_m := CASE WHEN r.total_spent <= (v_bands #>> '{monetary_bands,1}')::numeric THEN 1
                  WHEN r.total_spent <= (v_bands #>> '{monetary_bands,2}')::numeric THEN 2
                  WHEN r.total_spent <= (v_bands #>> '{monetary_bands,3}')::numeric THEN 3
                  WHEN r.total_spent <= (v_bands #>> '{monetary_bands,4}')::numeric THEN 4
                  ELSE 5 END;
    END IF;

    v_segment := CASE
      WHEN v_r >= 4 AND v_f >= 4 AND v_m >= 4 THEN 'Campeões'
      WHEN v_r >= 3 AND v_f >= 3              THEN 'Leais'
      WHEN v_f = 1 AND v_r >= 4               THEN 'Novos'
      WHEN v_r >= 3 AND v_f <= 2              THEN 'Em potencial'
      WHEN v_r <= 2 AND v_f >= 3              THEN 'Em risco'
      WHEN v_r = 2                            THEN 'Hibernando'
      ELSE 'Perdidos'
    END;

    -- Só grava o que MUDOU: reexecução no mesmo dia devolve changed = 0.
    INSERT INTO public.talkx_contact_attributes AS t (
      contact_id, last_purchase_at, orders_count, total_spent, avg_ticket,
      rfm_recency_days, rfm_frequency, rfm_monetary, rfm_segment,
      purchases_synced_at, updated_at
    ) VALUES (
      r.contact_id, r.last_purchase_at, r.orders_count, r.total_spent, r.avg_ticket,
      r.recency_days, v_f, v_m, v_segment, now(), now()
    )
    ON CONFLICT (contact_id) DO UPDATE SET
      last_purchase_at    = EXCLUDED.last_purchase_at,
      orders_count        = EXCLUDED.orders_count,
      total_spent         = EXCLUDED.total_spent,
      avg_ticket          = EXCLUDED.avg_ticket,
      rfm_recency_days    = EXCLUDED.rfm_recency_days,
      rfm_frequency       = EXCLUDED.rfm_frequency,
      rfm_monetary        = EXCLUDED.rfm_monetary,
      rfm_segment         = EXCLUDED.rfm_segment,
      purchases_synced_at = EXCLUDED.purchases_synced_at,
      updated_at          = EXCLUDED.updated_at
    WHERE (
      t.last_purchase_at, t.orders_count, t.total_spent, t.avg_ticket,
      t.rfm_recency_days, t.rfm_frequency, t.rfm_monetary, t.rfm_segment
    ) IS DISTINCT FROM (
      EXCLUDED.last_purchase_at, EXCLUDED.orders_count, EXCLUDED.total_spent, EXCLUDED.avg_ticket,
      EXCLUDED.rfm_recency_days, EXCLUDED.rfm_frequency, EXCLUDED.rfm_monetary, EXCLUDED.rfm_segment
    );

    GET DIAGNOSTICS v_rows = ROW_COUNT;
    v_changed   := v_changed + v_rows;
    v_processed := v_processed + 1;
  END LOOP;

  RETURN jsonb_build_object(
    'processed',  v_processed,
    'changed',    v_changed,
    'buyers',     v_buyers,
    'quintiles',  v_quintiles,
    'ref_date',   v_ref_date
  );
END;
$fn$;

COMMENT ON FUNCTION public.talkx_recompute_purchase_metrics(integer) IS
  'X040: recalcula métricas de compra e RFM por contato a partir de contact_purchases (1x/dia; linha em talkx_data_jobs). Contato sem compra fica nulo.';

-- Função nova nasce com EXECUTE para PUBLIC por padrão: fecha e abre só para o job.
REVOKE ALL ON FUNCTION public.talkx_recompute_purchase_metrics(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.talkx_recompute_purchase_metrics(integer) FROM anon;
REVOKE ALL ON FUNCTION public.talkx_recompute_purchase_metrics(integer) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.talkx_recompute_purchase_metrics(integer) TO service_role;
