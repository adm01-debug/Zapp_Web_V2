-- refazer 1 (t_eb69dbd6) da migration 20261014101033_incoming_call_destinatarios_sem_responsavel
-- Rollback: recria record_incoming_call_event na versao de 20261014101033 (fan-out com teto de 25,
-- duplicate = evento-ja-visto OU notify-sem-criacao-com-alvo, presença via SELECT...INTO) e restaura
-- o ACL service_role-only. Nenhuma notificacao ja criada e apagada (nao ha DML inverso).
-- Rollback (SQL executável — a versao 20261014101033 na integra, na ordem):
-- create or replace function public.record_incoming_call_event(
--   p_contact_id uuid,
--   p_whatsapp_connection_id uuid,
--   p_status text,
--   p_is_video boolean,
--   p_provider_event_id text default null,
--   p_should_notify boolean default false,
--   p_direction text default null
-- )
-- returns table (call_id uuid, notification_id uuid, notification_created boolean, duplicate boolean)
-- language plpgsql
-- security definer
-- set search_path to 'public', 'pg_temp'
-- as $function$
-- DECLARE
--   v_agent_id uuid;
--   v_agent_user_id uuid;
--   v_agent_online boolean;
--   v_queue_id uuid;
--   v_target_user_ids uuid[];
--   v_target_user_id uuid;
--   v_max_destinatarios constant integer := 25;
--   v_contact_name text;
--   v_contact_phone text;
--   v_contact_connection_id uuid;
--   v_event_id text := nullif(btrim(p_provider_event_id), '');
--   v_call_id uuid;
--   v_persisted_status text;
--   v_notification_id uuid;
--   v_notification_candidate uuid;
--   v_notification_created boolean := false;
--   v_inserted boolean := false;
--   v_call_duplicate boolean := false;
--   v_row_count integer := 0;
--   v_existing_notification record;
-- BEGIN
--   IF p_status NOT IN ('ringing', 'answered', 'ended', 'missed', 'busy', 'failed') THEN
--     RAISE EXCEPTION 'invalid incoming call status' USING ERRCODE = '22023';
--   END IF;
--   IF v_event_id IS NOT NULL AND char_length(v_event_id) > 200 THEN
--     RAISE EXCEPTION 'provider event id exceeds 200 characters' USING ERRCODE = '22023';
--   END IF;
--   IF p_should_notify AND p_status <> 'ringing' THEN
--     RAISE EXCEPTION 'only ringing calls can create notifications' USING ERRCODE = '22023';
--   END IF;
-- 
--   SELECT c.assigned_to, c.name, c.phone, c.whatsapp_connection_id, c.queue_id
--     INTO v_agent_id, v_contact_name, v_contact_phone, v_contact_connection_id, v_queue_id
--   FROM public.contacts AS c
--   WHERE c.id = p_contact_id;
--   IF NOT FOUND THEN
--     RAISE EXCEPTION 'incoming call contact not found' USING ERRCODE = 'P0002';
--   END IF;
--   IF v_contact_connection_id IS DISTINCT FROM p_whatsapp_connection_id THEN
--     RAISE EXCEPTION 'incoming call connection does not match contact' USING ERRCODE = '23514';
--   END IF;
-- 
--   IF v_agent_id IS NOT NULL THEN
--     SELECT p.user_id INTO v_agent_user_id
--     FROM public.profiles AS p
--     WHERE p.id = v_agent_id;
--   END IF;
-- 
--   IF v_event_id IS NOT NULL THEN
--     SELECT EXISTS (
--       SELECT 1 FROM public.calls AS existing
--       WHERE existing.whatsapp_connection_id = p_whatsapp_connection_id
--         AND existing.provider_event_id = v_event_id
--     ) INTO v_call_duplicate;
-- 
--     INSERT INTO public.calls (
--       contact_id, whatsapp_connection_id, agent_id, direction, status,
--       started_at, answered_at, ended_at, notes, provider_event_id,
--       channel, provider_call_id, peer_number, peer_name
--     ) VALUES (
--       p_contact_id, p_whatsapp_connection_id, v_agent_id, coalesce(p_direction, 'inbound'), p_status,
--       now(),
--       CASE WHEN p_status = 'answered' THEN now() ELSE NULL END,
--       CASE WHEN p_status IN ('ended', 'missed', 'busy', 'failed') THEN now() ELSE NULL END,
--       CASE WHEN p_is_video THEN 'Chamada de vídeo' ELSE 'Chamada de voz' END,
--       v_event_id,
--       'whatsapp', v_event_id, v_contact_phone, v_contact_name
--     )
--     ON CONFLICT (whatsapp_connection_id, provider_event_id)
--       WHERE provider_event_id IS NOT NULL
--     DO UPDATE SET
--       contact_id = EXCLUDED.contact_id,
--       -- preserva a atribuição histórica: o primeiro agente visto fica
--       agent_id = COALESCE(public.calls.agent_id, EXCLUDED.agent_id),
--       status = CASE
--         WHEN public.calls.status IN ('ended', 'missed', 'busy', 'failed')
--           THEN public.calls.status
--         WHEN public.calls.status = 'answered' AND EXCLUDED.status = 'ringing'
--           THEN public.calls.status
--         ELSE EXCLUDED.status
--       END,
--       answered_at = COALESCE(public.calls.answered_at, EXCLUDED.answered_at),
--       ended_at = COALESCE(public.calls.ended_at, EXCLUDED.ended_at),
--       -- `notes` é metadado do provedor: o primeiro valor vence, nunca é reescrito
--       notes = COALESCE(public.calls.notes, EXCLUDED.notes),
--       channel = COALESCE(public.calls.channel, EXCLUDED.channel),
--       provider_call_id = COALESCE(public.calls.provider_call_id, EXCLUDED.provider_call_id),
--       peer_number = COALESCE(public.calls.peer_number, EXCLUDED.peer_number),
--       peer_name = COALESCE(public.calls.peer_name, EXCLUDED.peer_name),
--       talk_seconds = COALESCE(
--         public.calls.talk_seconds,
--         CASE
--           WHEN COALESCE(public.calls.ended_at, EXCLUDED.ended_at) IS NOT NULL
--            AND COALESCE(public.calls.answered_at, EXCLUDED.answered_at) IS NOT NULL
--           THEN GREATEST(0, EXTRACT(EPOCH FROM (
--                  COALESCE(public.calls.ended_at, EXCLUDED.ended_at)
--                  - COALESCE(public.calls.answered_at, EXCLUDED.answered_at)
--                ))::int)
--           ELSE NULL
--         END
--       )
--     RETURNING id, status INTO v_call_id, v_persisted_status;
--   ELSE
--     INSERT INTO public.calls (
--       contact_id, whatsapp_connection_id, agent_id, direction, status,
--       started_at, answered_at, ended_at, notes,
--       channel, peer_number, peer_name
--     ) VALUES (
--       p_contact_id, p_whatsapp_connection_id, v_agent_id, coalesce(p_direction, 'inbound'), p_status,
--       now(),
--       CASE WHEN p_status = 'answered' THEN now() ELSE NULL END,
--       CASE WHEN p_status IN ('ended', 'missed', 'busy', 'failed') THEN now() ELSE NULL END,
--       CASE WHEN p_is_video THEN 'Chamada de vídeo' ELSE 'Chamada de voz' END,
--       'whatsapp', v_contact_phone, v_contact_name
--     ) RETURNING id, status INTO v_call_id, v_persisted_status;
--   END IF;
-- 
--   IF p_should_notify AND v_persisted_status = 'ringing' THEN
--     -- 1) responsavel explicito ONLINE tem prioridade (comportamento de hoje)
--     IF v_agent_user_id IS NOT NULL THEN
--       SELECT (ap.status = 'online') INTO v_agent_online
--       FROM public.agent_presence AS ap
--       WHERE ap.user_id = v_agent_user_id;
--       IF v_agent_online IS TRUE THEN
--         v_target_user_ids := ARRAY[v_agent_user_id];
--       END IF;
--     END IF;
-- 
--     -- 2) sem responsavel (ou offline): membros ativos e ONLINE da fila do contato
--     IF v_target_user_ids IS NULL AND v_queue_id IS NOT NULL THEN
--       SELECT array_agg(DISTINCT p.user_id ORDER BY p.user_id) INTO v_target_user_ids
--       FROM public.queue_members AS qm
--       JOIN public.profiles AS p ON p.id = qm.profile_id
--       JOIN public.agent_presence AS ap ON ap.user_id = p.user_id AND ap.status = 'online'
--       WHERE qm.queue_id = v_queue_id
--         AND qm.is_active;
--     END IF;
-- 
--     -- 3) sem fila ou ninguem online na fila: supervisores/admins ONLINE
--     IF v_target_user_ids IS NULL THEN
--       SELECT array_agg(DISTINCT ur.user_id ORDER BY ur.user_id) INTO v_target_user_ids
--       FROM public.user_roles AS ur
--       JOIN public.agent_presence AS ap ON ap.user_id = ur.user_id AND ap.status = 'online'
--       WHERE ur.role IN ('admin', 'supervisor');
--     END IF;
-- 
--     IF v_target_user_ids IS NOT NULL THEN
--       -- Teto determinístico por chamada: a lista vem ordenada por user_id (a montagem
--       -- acima usa ORDER BY user_id), então o corte é estável. Evita fan-out sem limite
--       -- dentro de uma transação só (recusa real de 06/10).
--       IF array_length(v_target_user_ids, 1) > v_max_destinatarios THEN
--         v_target_user_ids := v_target_user_ids[1:v_max_destinatarios];
--       END IF;
-- 
--       FOREACH v_target_user_id IN ARRAY v_target_user_ids LOOP
--         v_notification_candidate := CASE
--           WHEN v_event_id IS NULL THEN gen_random_uuid()
--           ELSE md5(
--             'zapp:incoming-call:v1:' || p_whatsapp_connection_id::text || ':'
--             || v_event_id || ':' || v_target_user_id::text
--           )::uuid
--         END;
-- 
--         INSERT INTO public.notifications (id, user_id, type, title, message, metadata)
--         VALUES (
--           v_notification_candidate,
--           v_target_user_id,
--           'incoming_call',
--           CASE WHEN p_is_video THEN '📹 Chamada de vídeo recebida' ELSE '📞 Chamada de voz recebida' END,
--           COALESCE(NULLIF(v_contact_name, ''), v_contact_phone, 'Contato') || ' está ligando para você',
--           jsonb_strip_nulls(jsonb_build_object(
--             'contact_id', p_contact_id,
--             'contact_name', COALESCE(NULLIF(v_contact_name, ''), v_contact_phone, 'Contato'),
--             'phone', v_contact_phone,
--             'is_video', p_is_video,
--             'call_status', v_persisted_status,
--             'whatsapp_connection_id', p_whatsapp_connection_id,
--             'call_id', v_call_id,
--             'event_id', v_event_id
--           ))
--         )
--         ON CONFLICT (id) DO NOTHING
--         RETURNING id INTO v_notification_id;
-- 
--         GET DIAGNOSTICS v_row_count = ROW_COUNT;
--         v_inserted := v_row_count = 1;
--         -- ON CONFLICT DO NOTHING nao devolve linha: o id do candidato e o esperado
--         v_notification_id := v_notification_candidate;
-- 
--         IF v_inserted THEN
--           v_notification_created := true;
--         ELSE
--           SELECT n.user_id, n.type, n.metadata INTO v_existing_notification
--           FROM public.notifications AS n
--           WHERE n.id = v_notification_candidate;
--           IF NOT FOUND
--             OR v_existing_notification.user_id IS DISTINCT FROM v_target_user_id
--             OR v_existing_notification.type IS DISTINCT FROM 'incoming_call'
--             OR v_existing_notification.metadata->>'event_id' IS DISTINCT FROM v_event_id THEN
--             RAISE EXCEPTION 'incoming call notification identity conflict' USING ERRCODE = '23505';
--           END IF;
--         END IF;
--       END LOOP;
--     END IF;
--   END IF;
-- 
--   RETURN QUERY SELECT
--     v_call_id,
--     v_notification_id,
--     v_notification_created,
--     v_call_duplicate OR (
--       p_should_notify AND v_target_user_ids IS NOT NULL
--       AND v_event_id IS NOT NULL AND NOT v_notification_created
--     );
-- END;
-- $function$;
-- 
-- revoke all on function public.record_incoming_call_event(uuid, uuid, text, boolean, text, boolean, text)
--   from public, anon, authenticated;
-- grant execute on function public.record_incoming_call_event(uuid, uuid, text, boolean, text, boolean, text)
--   to service_role;
--
-- Refazer 1 (t_eb69dbd6): resolve ponto a ponto a recusa da versao 20261014101033.
--
-- Ponto 1 (responsavel sem linha em agent_presence): o passo 1 usava
-- SELECT...INTO + `IF v_agent_online IS TRUE` e caia na fila/supervisao por
-- acidente da semantica de NULL, sem teste cobrindo a rota. Agora o passo 1
-- exige a linha explicita `status = 'online'` (EXISTS); sem linha = nao
-- ONLINE = cai na fila/supervisao, de proposito (T10 prova a rota).
-- `agent_presence.user_id` e PRIMARY KEY: no maximo 1 linha por usuario.
--
-- Ponto 2 (duplicate nao provava nada sobre notificacao): antes,
-- `v_call_duplicate OR (...)` acusava duplicada em qualquer re-chamada apos o
-- primeiro evento visto (mesmo com should_notify = false) e acusava
-- nao-duplicada na chamada nova com status pos-ringing (onde nada de
-- notificacao acontece). Agora `duplicate = evento com id AND NOT criado
-- AND (pediu notificacao OU primeira vez que o evento e visto)` ("esta chamada
-- nao mudou nada no plano de notificacao"): reentrega com notify = true,
-- chamada nova que ja chega answered (notify=false pela validacao) = true,
-- re-chamada com should_notify = false = false, sem evento = false (sem chave
-- de deduplicacao). T6/T11/T12 provam os tres casos. O unico
-- chamador em producao (webhook evolution-webhook-handlers.ts) ignora o
-- retorno (le so `error`), entao a troca nao muda nenhum fluxo ao lado.
--
-- Ponto 3 (T9 sem escala): so a suite de teste muda (N=500 via generate_series,
-- teto de 25 mantido — decisao do cartao-pai, nao deste refazer).
--
-- Nada mais muda: assinatura, validacoes, a linha em `calls` (inclusive o
-- `agent_id` historico), o ON CONFLICT do evento, `talk_seconds`, os textos e
-- o metadata sao os mesmos. Sem DDL de tabela, sem DML, sem GRANT novo: o ACL
-- vigente (EXECUTE so para service_role) e reafirmado no fim, sem afrouxar nada.
--
create or replace function public.record_incoming_call_event(
  p_contact_id uuid,
  p_whatsapp_connection_id uuid,
  p_status text,
  p_is_video boolean,
  p_provider_event_id text default null,
  p_should_notify boolean default false,
  p_direction text default null
)
returns table (call_id uuid, notification_id uuid, notification_created boolean, duplicate boolean)
language plpgsql
security definer
set search_path to 'public', 'pg_temp'
as $function$
DECLARE
  v_agent_id uuid;
  v_agent_user_id uuid;
  v_queue_id uuid;
  v_target_user_ids uuid[];
  v_target_user_id uuid;
  v_max_destinatarios constant integer := 25;
  v_contact_name text;
  v_contact_phone text;
  v_contact_connection_id uuid;
  v_event_id text := nullif(btrim(p_provider_event_id), '');
  v_call_id uuid;
  v_persisted_status text;
  v_notification_id uuid;
  v_notification_candidate uuid;
  v_notification_created boolean := false;
  v_inserted boolean := false;
  v_call_duplicate boolean := false;
  v_row_count integer := 0;
  v_existing_notification record;
BEGIN
  IF p_status NOT IN ('ringing', 'answered', 'ended', 'missed', 'busy', 'failed') THEN
    RAISE EXCEPTION 'invalid incoming call status' USING ERRCODE = '22023';
  END IF;
  IF v_event_id IS NOT NULL AND char_length(v_event_id) > 200 THEN
    RAISE EXCEPTION 'provider event id exceeds 200 characters' USING ERRCODE = '22023';
  END IF;
  IF p_should_notify AND p_status <> 'ringing' THEN
    RAISE EXCEPTION 'only ringing calls can create notifications' USING ERRCODE = '22023';
  END IF;

  SELECT c.assigned_to, c.name, c.phone, c.whatsapp_connection_id, c.queue_id
    INTO v_agent_id, v_contact_name, v_contact_phone, v_contact_connection_id, v_queue_id
  FROM public.contacts AS c
  WHERE c.id = p_contact_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'incoming call contact not found' USING ERRCODE = 'P0002';
  END IF;
  IF v_contact_connection_id IS DISTINCT FROM p_whatsapp_connection_id THEN
    RAISE EXCEPTION 'incoming call connection does not match contact' USING ERRCODE = '23514';
  END IF;

  IF v_agent_id IS NOT NULL THEN
    SELECT p.user_id INTO v_agent_user_id
    FROM public.profiles AS p
    WHERE p.id = v_agent_id;
  END IF;

  IF v_event_id IS NOT NULL THEN
    SELECT EXISTS (
      SELECT 1 FROM public.calls AS existing
      WHERE existing.whatsapp_connection_id = p_whatsapp_connection_id
        AND existing.provider_event_id = v_event_id
    ) INTO v_call_duplicate;

    INSERT INTO public.calls (
      contact_id, whatsapp_connection_id, agent_id, direction, status,
      started_at, answered_at, ended_at, notes, provider_event_id,
      channel, provider_call_id, peer_number, peer_name
    ) VALUES (
      p_contact_id, p_whatsapp_connection_id, v_agent_id, coalesce(p_direction, 'inbound'), p_status,
      now(),
      CASE WHEN p_status = 'answered' THEN now() ELSE NULL END,
      CASE WHEN p_status IN ('ended', 'missed', 'busy', 'failed') THEN now() ELSE NULL END,
      CASE WHEN p_is_video THEN 'Chamada de vídeo' ELSE 'Chamada de voz' END,
      v_event_id,
      'whatsapp', v_event_id, v_contact_phone, v_contact_name
    )
    ON CONFLICT (whatsapp_connection_id, provider_event_id)
      WHERE provider_event_id IS NOT NULL
    DO UPDATE SET
      contact_id = EXCLUDED.contact_id,
      -- preserva a atribuição histórica: o primeiro agente visto fica
      agent_id = COALESCE(public.calls.agent_id, EXCLUDED.agent_id),
      status = CASE
        WHEN public.calls.status IN ('ended', 'missed', 'busy', 'failed')
          THEN public.calls.status
        WHEN public.calls.status = 'answered' AND EXCLUDED.status = 'ringing'
          THEN public.calls.status
        ELSE EXCLUDED.status
      END,
      answered_at = COALESCE(public.calls.answered_at, EXCLUDED.answered_at),
      ended_at = COALESCE(public.calls.ended_at, EXCLUDED.ended_at),
      -- `notes` é metadado do provedor: o primeiro valor vence, nunca é reescrito
      notes = COALESCE(public.calls.notes, EXCLUDED.notes),
      channel = COALESCE(public.calls.channel, EXCLUDED.channel),
      provider_call_id = COALESCE(public.calls.provider_call_id, EXCLUDED.provider_call_id),
      peer_number = COALESCE(public.calls.peer_number, EXCLUDED.peer_number),
      peer_name = COALESCE(public.calls.peer_name, EXCLUDED.peer_name),
      talk_seconds = COALESCE(
        public.calls.talk_seconds,
        CASE
          WHEN COALESCE(public.calls.ended_at, EXCLUDED.ended_at) IS NOT NULL
           AND COALESCE(public.calls.answered_at, EXCLUDED.answered_at) IS NOT NULL
          THEN GREATEST(0, EXTRACT(EPOCH FROM (
                 COALESCE(public.calls.ended_at, EXCLUDED.ended_at)
                 - COALESCE(public.calls.answered_at, EXCLUDED.answered_at)
               ))::int)
          ELSE NULL
        END
      )
    RETURNING id, status INTO v_call_id, v_persisted_status;
  ELSE
    INSERT INTO public.calls (
      contact_id, whatsapp_connection_id, agent_id, direction, status,
      started_at, answered_at, ended_at, notes,
      channel, peer_number, peer_name
    ) VALUES (
      p_contact_id, p_whatsapp_connection_id, v_agent_id, coalesce(p_direction, 'inbound'), p_status,
      now(),
      CASE WHEN p_status = 'answered' THEN now() ELSE NULL END,
      CASE WHEN p_status IN ('ended', 'missed', 'busy', 'failed') THEN now() ELSE NULL END,
      CASE WHEN p_is_video THEN 'Chamada de vídeo' ELSE 'Chamada de voz' END,
      'whatsapp', v_contact_phone, v_contact_name
    ) RETURNING id, status INTO v_call_id, v_persisted_status;
  END IF;

  IF p_should_notify AND v_persisted_status = 'ringing' THEN
    -- 1) responsavel explicito ONLINE tem prioridade (comportamento de hoje).
    -- So conta a linha explicita 'online' em agent_presence: sem linha (contato
    -- novo com dono que nunca sinalizou presenca) = nao ONLINE, cai na
    -- fila/supervisao (refazer 1, ponto 1; T10 prova a rota).
    IF v_agent_user_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM public.agent_presence AS ap
      WHERE ap.user_id = v_agent_user_id AND ap.status = 'online'
    ) THEN
      v_target_user_ids := ARRAY[v_agent_user_id];
    END IF;

    -- 2) sem responsavel (ou offline): membros ativos e ONLINE da fila do contato
    IF v_target_user_ids IS NULL AND v_queue_id IS NOT NULL THEN
      SELECT array_agg(DISTINCT p.user_id ORDER BY p.user_id) INTO v_target_user_ids
      FROM public.queue_members AS qm
      JOIN public.profiles AS p ON p.id = qm.profile_id
      JOIN public.agent_presence AS ap ON ap.user_id = p.user_id AND ap.status = 'online'
      WHERE qm.queue_id = v_queue_id
        AND qm.is_active;
    END IF;

    -- 3) sem fila ou ninguem online na fila: supervisores/admins ONLINE
    IF v_target_user_ids IS NULL THEN
      SELECT array_agg(DISTINCT ur.user_id ORDER BY ur.user_id) INTO v_target_user_ids
      FROM public.user_roles AS ur
      JOIN public.agent_presence AS ap ON ap.user_id = ur.user_id AND ap.status = 'online'
      WHERE ur.role IN ('admin', 'supervisor');
    END IF;

    IF v_target_user_ids IS NOT NULL THEN
      -- Teto determinístico por chamada: a lista vem ordenada por user_id (a montagem
      -- acima usa ORDER BY user_id), então o corte é estável. Evita fan-out sem limite
      -- dentro de uma transação só (recusa real de 06/10).
      IF array_length(v_target_user_ids, 1) > v_max_destinatarios THEN
        v_target_user_ids := v_target_user_ids[1:v_max_destinatarios];
      END IF;

      FOREACH v_target_user_id IN ARRAY v_target_user_ids LOOP
        v_notification_candidate := CASE
          WHEN v_event_id IS NULL THEN gen_random_uuid()
          ELSE md5(
            'zapp:incoming-call:v1:' || p_whatsapp_connection_id::text || ':'
            || v_event_id || ':' || v_target_user_id::text
          )::uuid
        END;

        INSERT INTO public.notifications (id, user_id, type, title, message, metadata)
        VALUES (
          v_notification_candidate,
          v_target_user_id,
          'incoming_call',
          CASE WHEN p_is_video THEN '📹 Chamada de vídeo recebida' ELSE '📞 Chamada de voz recebida' END,
          COALESCE(NULLIF(v_contact_name, ''), v_contact_phone, 'Contato') || ' está ligando para você',
          jsonb_strip_nulls(jsonb_build_object(
            'contact_id', p_contact_id,
            'contact_name', COALESCE(NULLIF(v_contact_name, ''), v_contact_phone, 'Contato'),
            'phone', v_contact_phone,
            'is_video', p_is_video,
            'call_status', v_persisted_status,
            'whatsapp_connection_id', p_whatsapp_connection_id,
            'call_id', v_call_id,
            'event_id', v_event_id
          ))
        )
        ON CONFLICT (id) DO NOTHING
        RETURNING id INTO v_notification_id;

        GET DIAGNOSTICS v_row_count = ROW_COUNT;
        v_inserted := v_row_count = 1;
        -- ON CONFLICT DO NOTHING nao devolve linha: o id do candidato e o esperado
        v_notification_id := v_notification_candidate;

        IF v_inserted THEN
          v_notification_created := true;
        ELSE
          SELECT n.user_id, n.type, n.metadata INTO v_existing_notification
          FROM public.notifications AS n
          WHERE n.id = v_notification_candidate;
          IF NOT FOUND
            OR v_existing_notification.user_id IS DISTINCT FROM v_target_user_id
            OR v_existing_notification.type IS DISTINCT FROM 'incoming_call'
            OR v_existing_notification.metadata->>'event_id' IS DISTINCT FROM v_event_id THEN
            RAISE EXCEPTION 'incoming call notification identity conflict' USING ERRCODE = '23505';
          END IF;
        END IF;
      END LOOP;
    END IF;
  END IF;

  RETURN QUERY SELECT
    v_call_id,
    v_notification_id,
    v_notification_created,
    -- duplicate = "esta chamada nao mudou nada no plano de notificacao": ha
    -- evento com id, nenhum destinatario novo foi criado E (pediu notificacao
    -- — reentrega, ou ninguem online — OU e a primeira vez que o evento e
    -- visto sem gerar notificacao, ex. chamada nova que ja chega answered).
    -- Sem pedido de notificacao numa re-chamada (ex. update answered com
    -- should_notify = false) nao ha deduplicacao a relatar = false; sem
    -- evento nao ha chave de deduplicacao = false (refazer 1, ponto 2;
    -- T6/T11/T12 provam os tres casos).
    v_event_id IS NOT NULL AND NOT v_notification_created
      AND (p_should_notify OR NOT v_call_duplicate);
END;
$function$;

revoke all on function public.record_incoming_call_event(uuid, uuid, text, boolean, text, boolean, text)
  from public, anon, authenticated;
grant execute on function public.record_incoming_call_event(uuid, uuid, text, boolean, text, boolean, text)
  to service_role;
