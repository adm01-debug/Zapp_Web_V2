#!/usr/bin/env node
// Monitor de uptime do front em /version.json — SLO "Front disponivel" (docs/runbooks/slo.md).
//
// Por que existe: o SLO de 99,9 % do front (43 min de error budget em 30 dias) nao tinha
// nenhuma medicao de FORA da infra. Os sinais que ja existiam (Vercel Analytics, Runtime
// Logs) so mostram o que chegou: um deploy que passa a servir HTML no lugar do build, ou
// *.vercel.app fora do ar, so aparecia quando alguem reclamava.
//
// O que ele prova, em uma frase: `GET <url>` respondeu HTTP 200, com content-type JSON e
// corpo `{"buildId":"..."}` nao vazio. Os tres itens sao cobrados de proposito:
//   - 200          -> o front esta no ar (nao 5xx, nao 000/timeout);
//   - JSON + buildId -> o BUILD esta publicado. O Vercel responde HTTP 200 com `index.html`
//     para qualquer caminho inexistente (fallback do SPA), entao "200 devolvendo HTML" e' o
//     sintoma exato de "sem build" — sem checar o content-type esse caso passaria como verde.
// `version.json` e' gerado no build (vite.config.ts:18-26) e consumido pelo proprio app para
// avisar "nova versao disponivel" (src/lib/deployment-update.ts:45-51): e' o sinal mais
// barato que existe para dizer "a producao esta servindo o bundle certo".
//
// Quem chama: .github/workflows/uptime-check.yml (runner do GitHub = de fora da nossa infra),
// de 10 em 10 min. Falhou -> abre/comenta a issue `[uptime]`; voltou -> fecha a issue.
//
// Uso:
//   node scripts/ci/uptime-check.mjs [--url <url>] [--tentativas N] [--timeout-ms N]
//                                    [--espera-ms N] [--relatorio-saida <arquivo>]
// Saida: `UPTIME_OK ...` (exit 0) ou `UPTIME_FALHA motivo="..."` (exit 1).
// `--relatorio-saida` grava o veredito em markdown (corpo da issue). Nenhum segredo e' lido
// nem impresso: a unica entrada e' uma URL publica.

import { writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

/** Alvo canonico do SLO — o mesmo texto de docs/runbooks/slo.md ("Front disponivel"). */
export const ALVO_PADRAO = "https://zapp-web-v2.vercel.app/version.json";
export const TIMEOUT_PADRAO_MS = 10_000;
export const TENTATIVAS_PADRAO = 2;
export const ESPERA_PADRAO_MS = 5_000;

const USO = `Uso: node scripts/ci/uptime-check.mjs [--url <url>] [--tentativas N] [--timeout-ms N]
                                    [--espera-ms N] [--relatorio-saida <arquivo>]`;

const COM_VALOR = new Map([
  ["--url", "url"],
  ["--tentativas", "tentativas"],
  ["--timeout-ms", "timeoutMs"],
  ["--espera-ms", "esperaMs"],
  ["--relatorio-saida", "relatorio"],
]);

const NUMERICOS = new Set(["tentativas", "timeoutMs", "esperaMs"]);

/** Le a linha de comando. Nao le ambiente nem arquivo: a entrada e' so o argv. */
export function lerArgumentos(argv) {
  const opcoes = {
    url: ALVO_PADRAO,
    tentativas: TENTATIVAS_PADRAO,
    timeoutMs: TIMEOUT_PADRAO_MS,
    esperaMs: ESPERA_PADRAO_MS,
    relatorio: "",
    ajuda: false,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "-h" || arg === "--help") {
      opcoes.ajuda = true;
      continue;
    }
    const destino = COM_VALOR.get(arg);
    if (!destino) throw new Error(`argumento desconhecido: ${arg}`);
    const valor = argv[i + 1];
    if (valor === undefined) throw new Error(`falta o valor de ${arg}`);
    i += 1;
    if (!NUMERICOS.has(destino)) {
      opcoes[destino] = valor;
      continue;
    }
    const numero = Number(valor);
    if (!Number.isFinite(numero) || numero < 0) {
      throw new Error(`${arg} precisa ser um numero >= 0 (veio "${valor}")`);
    }
    opcoes[destino] = numero;
  }
  if (opcoes.tentativas < 1) throw new Error("--tentativas precisa ser >= 1");
  if (opcoes.timeoutMs < 1) throw new Error("--timeout-ms precisa ser >= 1");
  return opcoes;
}

/** Contrato do artefato: objeto JSON com `buildId` nao vazio (vite.config.ts:23). */
export function validarVersionJson(texto) {
  let dados;
  try {
    dados = JSON.parse(texto);
  } catch {
    const amostra = String(texto ?? "").replace(/\s+/gu, " ").slice(0, 80);
    return { ok: false, motivo: `corpo nao e JSON valido (comeca com "${amostra}")` };
  }
  if (!dados || typeof dados !== "object" || Array.isArray(dados)) {
    return { ok: false, motivo: "JSON nao e um objeto" };
  }
  if (typeof dados.buildId !== "string" || dados.buildId.trim() === "") {
    return { ok: false, motivo: "campo buildId ausente ou vazio — o build nao publicou a versao" };
  }
  return { ok: true, buildId: dados.buildId };
}

function descreverErro(erro, timeoutMs) {
  if (erro?.name === "TimeoutError" || erro?.cause?.code === "UND_ERR_CONNECT_TIMEOUT") {
    return `sem resposta em ${timeoutMs} ms (timeout)`;
  }
  const codigo = erro?.cause?.code ?? erro?.code;
  if (codigo === "ENOTFOUND" || codigo === "EAI_AGAIN") return `DNS nao resolveu o alvo (${codigo})`;
  if (codigo === "ECONNREFUSED" || codigo === "ECONNRESET" || codigo === "ETIMEDOUT") {
    return `conexao recusada/resetada (${codigo})`;
  }
  if (codigo) return `falha de rede (${codigo})`;
  return `falha inesperada: ${erro?.message ?? String(erro)}`;
}

/**
 * Mede o alvo ate `tentativas` vezes. A segunda tentativa existe para nao transformar um
 * blip de rede do runner em alerta: so falha quando TODAS as tentativas falham.
 * `buscar`/`dormir` sao injetaveis para o teste rodar contra um servidor local, sem rede.
 */
export async function checarUptime({
  url,
  timeoutMs = TIMEOUT_PADRAO_MS,
  tentativas = 1,
  esperaMs = 0,
  buscar = globalThis.fetch,
  dormir = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
} = {}) {
  const eventos = [];
  for (let tentativa = 1; tentativa <= tentativas; tentativa += 1) {
    const inicio = Date.now();
    let status = null;
    try {
      const resposta = await buscar(url, {
        cache: "no-store",
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(timeoutMs),
      });
      status = resposta.status;
      const contentType = resposta.headers.get("content-type") ?? "";
      const tempoMs = Date.now() - inicio;
      if (status !== 200) {
        eventos.push({ tentativa, status, tempoMs, motivo: `HTTP ${status} (esperado 200)` });
      } else if (!/json/iu.test(contentType)) {
        eventos.push({
          tentativa,
          status,
          tempoMs,
          motivo: `HTTP 200 com content-type "${contentType || "(vazio)"}" — o /version.json nao esta sendo servido (fallback do SPA devolve HTML com 200)`,
        });
      } else {
        const validacao = validarVersionJson(await resposta.text());
        if (validacao.ok) {
          return { ok: true, url, tentativa, status, tempoMs, contentType, buildId: validacao.buildId, eventos };
        }
        eventos.push({ tentativa, status, tempoMs, motivo: validacao.motivo });
      }
    } catch (erro) {
      eventos.push({ tentativa, status, tempoMs: Date.now() - inicio, motivo: descreverErro(erro, timeoutMs) });
    }
    if (tentativa < tentativas) await dormir(esperaMs);
  }
  const motivo = eventos.map((evento) => `tentativa ${evento.tentativa}: ${evento.motivo}`).join("; ");
  return { ok: false, url, tentativas, motivo, eventos };
}

/** Veredito em markdown — usado como corpo da issue `[uptime]` e no Job Summary. */
export function relatorioMarkdown(resultado, { agora = new Date(), runUrl = "" } = {}) {
  const linhas = [
    `## Uptime do front — ${resultado.ok ? "OK" : "FALHA"}`,
    "",
    `- **Alvo:** \`${resultado.url}\``,
    `- **Medido em (UTC):** ${agora.toISOString()}`,
  ];
  if (resultado.ok) {
    linhas.push(`- **Resposta:** HTTP ${resultado.status} · ${resultado.tempoMs} ms · build \`${resultado.buildId}\``);
    if (resultado.tentativa > 1) linhas.push(`- **Tentativas ate passar:** ${resultado.tentativa}`);
  } else {
    linhas.push(
      `- **Motivo:** ${resultado.motivo}`,
      "",
      "| Tentativa | HTTP | Tempo | Motivo |",
      "|---|---|---|---|",
      ...resultado.eventos.map(
        (evento) => `| ${evento.tentativa} | ${evento.status ?? "—"} | ${evento.tempoMs} ms | ${evento.motivo} |`,
      ),
    );
  }
  if (runUrl) linhas.push("", `- **Run:** ${runUrl}`);
  linhas.push("", "SLO e procedimento: `docs/runbooks/slo.md`.");
  return linhas.join("\n");
}

async function principal(argv) {
  const opcoes = lerArgumentos(argv);
  if (opcoes.ajuda) {
    console.log(USO);
    return 0;
  }
  const resultado = await checarUptime(opcoes);
  if (resultado.ok) {
    console.log(
      `UPTIME_OK url=${resultado.url} status=${resultado.status} tempo_ms=${resultado.tempoMs}`
        + ` tentativa=${resultado.tentativa} build_id=${resultado.buildId}`,
    );
  } else {
    console.error(`UPTIME_FALHA url=${resultado.url} tentativas=${resultado.tentativas} motivo="${resultado.motivo}"`);
  }
  if (opcoes.relatorio) {
    const runUrl = process.env.GITHUB_SERVER_URL && process.env.GITHUB_REPOSITORY && process.env.GITHUB_RUN_ID
      ? `${process.env.GITHUB_SERVER_URL}/${process.env.GITHUB_REPOSITORY}/actions/runs/${process.env.GITHUB_RUN_ID}`
      : "";
    await writeFile(opcoes.relatorio, `${relatorioMarkdown(resultado, { runUrl })}\n`, "utf8");
  }
  return resultado.ok ? 0 : 1;
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? "").href) {
  principal(process.argv.slice(2))
    .then((codigo) => {
      process.exitCode = codigo;
    })
    .catch((erro) => {
      console.error(`UPTIME_FALHA motivo="erro inesperado: ${erro?.message ?? erro}"`);
      process.exitCode = 1;
    });
}
