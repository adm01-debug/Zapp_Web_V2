// Testes do verificador de uptime do front (SL-003 / docs/runbooks/slo.md, "Front disponivel").
//
// Por que isto e' teste e nao so' o script: o caso que motivou o verificador — HTTP 200 com
// HTML no lugar do build, que e' o fallback do SPA da Vercel — e' indistinguivel de um
// "200 OK" para quem olha so' o status. Um comentario no script nao impede a proxima edicao
// de aceitar `status === 200` sem checar content-type e buildId; este arquivo impede.
//
// Nenhum teste toca a rede de verdade: o alvo e' um servidor local que responde os cenarios
// (200 JSON, 200 HTML, 500, timeout, instavel). O registro no runbook e' conferido por leitura.

import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";

import {
  ALVO_PADRAO,
  checarUptime,
  lerArgumentos,
  relatorioMarkdown,
  validarVersionJson,
} from "./uptime-check.mjs";

const ROTAS = new Map(); // rota -> resposta fixa
const sockets = [];
let tentativasInstavel = 0;

const servidor = createServer((req, res) => {
  const rota = (req.url ?? "/").split("?")[0];
  if (rota === "/mudo") return; // nunca responde: cobre o timeout
  if (rota === "/instavel") {
    tentativasInstavel += 1;
    if (tentativasInstavel === 1) {
      res.writeHead(503, { "content-type": "text/plain" });
      res.end("indisponivel");
      return;
    }
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ buildId: "depois-do-retry" }));
    return;
  }
  const resposta = ROTAS.get(rota) ?? { status: 404, "content-type": "text/plain", corpo: "nao encontrado" };
  res.writeHead(resposta.status, { "content-type": resposta["content-type"] });
  res.end(resposta.corpo);
});
servidor.on("connection", (socket) => {
  sockets.push(socket);
});

await new Promise((resolve) => servidor.listen(0, "127.0.0.1", resolve));
const BASE = `http://127.0.0.1:${servidor.address().port}`;

ROTAS.set("/ok", { status: 200, "content-type": "application/json; charset=utf-8", corpo: JSON.stringify({ buildId: "abc123" }) });
ROTAS.set("/html", { status: 200, "content-type": "text/html; charset=utf-8", corpo: "<!doctype html><html><body>app</body></html>" });
ROTAS.set("/sem-build-id", { status: 200, "content-type": "application/json", corpo: JSON.stringify({}) });
ROTAS.set("/build-id-vazio", { status: 200, "content-type": "application/json", corpo: JSON.stringify({ buildId: "   " }) });
ROTAS.set("/texto-puro", { status: 200, "content-type": "text/plain", corpo: "oi" });
ROTAS.set("/erro-500", { status: 500, "content-type": "text/plain", corpo: "boom" });

test.after(() => {
  for (const socket of sockets) socket.destroy();
  return new Promise((resolve) => servidor.close(resolve));
});

// ── Comportamento do verificador ───────────────────────────────────────────────

test("200 com JSON e buildId: passa (o caso normal da producao)", async () => {
  const resultado = await checarUptime({ url: `${BASE}/ok`, timeoutMs: 2000 });
  assert.equal(resultado.ok, true);
  assert.equal(resultado.status, 200);
  assert.equal(resultado.buildId, "abc123");
});

test("200 com HTML: FALHA — e' o fallback do SPA, o caso que o verificador existe para pegar", async () => {
  const resultado = await checarUptime({ url: `${BASE}/html`, timeoutMs: 2000 });
  assert.equal(resultado.ok, false, "um 200 devolvendo HTML nao pode passar como front no ar");
  assert.match(resultado.motivo, /content-type/u);
  assert.match(resultado.motivo, /text\/html/u);
});

test("200 com JSON sem buildId: FALHA (build nao publicou a versao)", async () => {
  const semCampo = await checarUptime({ url: `${BASE}/sem-build-id`, timeoutMs: 2000 });
  assert.equal(semCampo.ok, false);
  assert.match(semCampo.motivo, /buildId/u);

  const vazio = await checarUptime({ url: `${BASE}/build-id-vazio`, timeoutMs: 2000 });
  assert.equal(vazio.ok, false, "buildId so' com espacos e' buildId vazio");
});

test("200 com texto puro: FALHA (content-type nao e' JSON)", async () => {
  const resultado = await checarUptime({ url: `${BASE}/texto-puro`, timeoutMs: 2000 });
  assert.equal(resultado.ok, false);
  assert.match(resultado.motivo, /content-type/u);
});

test("HTTP 500: FALHA citando o codigo", async () => {
  const resultado = await checarUptime({ url: `${BASE}/erro-500`, timeoutMs: 2000 });
  assert.equal(resultado.ok, false);
  assert.match(resultado.motivo, /HTTP 500/u);
});

test("sem resposta dentro do timeout: FALHA", async () => {
  const resultado = await checarUptime({ url: `${BASE}/mudo`, timeoutMs: 250 });
  assert.equal(resultado.ok, false);
  assert.match(resultado.motivo, /timeout/u);
});

test("a segunda tentativa salva um blip do runner", async () => {
  tentativasInstavel = 0;
  const resultado = await checarUptime({ url: `${BASE}/instavel`, tentativas: 2, esperaMs: 0, timeoutMs: 2000 });
  assert.equal(resultado.ok, true, "um 503 isolado nao pode virar alerta");
  assert.equal(resultado.tentativa, 2);
  assert.equal(resultado.buildId, "depois-do-retry");
  assert.equal(resultado.eventos.length, 1, "a tentativa que falhou fica registrada");
});

test("falha so' quando TODAS as tentativas falham", async () => {
  const resultado = await checarUptime({ url: `${BASE}/erro-500`, tentativas: 3, esperaMs: 0, timeoutMs: 2000 });
  assert.equal(resultado.ok, false);
  assert.equal(resultado.eventos.length, 3);
  assert.match(resultado.motivo, /tentativa 1: HTTP 500/u);
  assert.match(resultado.motivo, /tentativa 3: HTTP 500/u);
});

test("o relatorio de falha mostra alvo, motivo e cada tentativa", () => {
  const relatorio = relatorioMarkdown({
    ok: false,
    url: "https://exemplo.test/version.json",
    tentativas: 2,
    motivo: "tentativa 1: HTTP 503; tentativa 2: HTTP 503",
    eventos: [
      { tentativa: 1, status: 503, tempoMs: 12, motivo: "HTTP 503 (esperado 200)" },
      { tentativa: 2, status: 503, tempoMs: 15, motivo: "HTTP 503 (esperado 200)" },
    ],
  });
  assert.match(relatorio, /FALHA/u);
  assert.match(relatorio, /https:\/\/exemplo\.test\/version\.json/u);
  assert.match(relatorio, /\| 1 \| 503 \|/u);
  assert.match(relatorio, /\| 2 \| 503 \|/u);
});

test("validarVersionJson recusa HTML e aceita o contrato do build", () => {
  assert.equal(validarVersionJson("<html></html>").ok, false);
  assert.equal(validarVersionJson("[]").ok, false, "array nao e' o contrato do version.json");
  assert.equal(validarVersionJson('{"outro":"campo"}').ok, false);
  assert.deepEqual(validarVersionJson('{"buildId":"deadbeef"}'), { ok: true, buildId: "deadbeef" });
});

test("lerArgumentos: padrao e' o alvo do SLO e argumento desconhecido e' recusado", () => {
  assert.equal(lerArgumentos([]).url, ALVO_PADRAO);
  assert.equal(lerArgumentos([]).tentativas, 2);
  assert.throws(() => lerArgumentos(["--urll", "x"]), /argumento desconhecido/u);
  assert.throws(() => lerArgumentos(["--tentativas", "0"]), />= 1/u);
  assert.throws(() => lerArgumentos(["--timeout-ms", "abc"]), /numero/u);
});

// ── Registro no runbook (o alvo do codigo e o alvo do SLO nao podem divergir) ──

const slo = await readFile(new URL("../../docs/runbooks/slo.md", import.meta.url), "utf8");

test("o runbook do SLO cita o comando do verificador e o mesmo alvo do codigo", () => {
  assert.ok(
    slo.includes(ALVO_PADRAO),
    `docs/runbooks/slo.md nao cita ${ALVO_PADRAO} — o SLO e o verificador nao podem divergir`,
  );
  assert.match(slo, /scripts\/ci\/uptime-check\.mjs/u, "o runbook deve dizer QUAL comando faz a checagem");
});

test("o runbook declara que o agendamento com alerta ainda depende de acao externa", () => {
  // Enquanto o agendador com alerta nao existir, o runbook nao pode dar a entender que
  // existe: foi essa a lacuna que o inventario de 2026-10-07 registrou (passo 2 do SLO).
  assert.match(slo, /Ainda pendente/u, "o runbook deve marcar o que falta, sem parecer pronto");
  assert.doesNotMatch(slo, /existe hoje:\*\* monitor externo/u, "o texto antigo afirmava que nao existe monitor externo");
});
