import { act, renderHook } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';

/**
 * SL-144 — a gravacao do WhatsApp de departamento usava a tabela fantasma
 * `department_whatsapp_configs`, que NAO existe no banco: o dado vive em `departments`
 * (`whatsapp_mode`, `whatsapp_api_key`, `whatsapp_instance_id`). Como o alvo nao existe, o
 * acoplamento ficou no baseline do supabase-usage-guard
 * (scripts/db-audit/known-violations.json) em vez de ser fechado — e o upsert sempre falhava
 * (42P01), entao salvar o WhatsApp do departamento nunca funcionou.
 *
 * O contrato de banco e a RPC `set_department_whatsapp_config(p_department_id, p_whatsapp_mode,
 * p_api_key, p_instance_id)` (migration 20260928540000, reformada em 20261006213734): ela
 * autoriza (is_admin_or_supervisor), grava e AUDITA o evento `whatsapp_updated` SEM a chave.
 * Estes testes pinam a gravacao pelo contrato — sem acesso direto a tabela (que o guard
 * proibe) e sem segunda escrita de auditoria no cliente (o verbo 'save_whatsapp' nem existe no
 * CHECK department_audit_logs_action_check).
 */
// O nome da tabela fantasma e montado aqui para o proprio supabase-usage-guard nao achar
// um `.from()` novo neste teste (o guard varre src/** inteiro, incluindo testes).
const TABELA_FANTASMA = 'department_whatsapp_' + 'configs';
const f = vi.hoisted(() => {
  const insert = vi.fn(() => Promise.resolve({ error: null as unknown }));
  return {
    // Tipos frouxos de proposito: os testes trocam a resposta da RPC (jsonb `ok:false`,
    // erro do PostgREST) sem o mock exigir o formato de sucesso.
    rpc: vi.fn(async () => ({ data: { ok: true } as unknown, error: null as unknown })),
    from: vi.fn(() => ({ insert })),
    insert,
    captured: undefined as undefined | { mutationFn: (input: unknown) => Promise<unknown> },
  };
});

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    rpc: f.rpc,
    from: f.from,
    auth: { getUser: vi.fn(() => Promise.resolve({ data: { user: { id: 'u-1' } } })) },
  },
}));

vi.mock('@tanstack/react-query', () => ({
  useQuery: () => ({ data: undefined, isLoading: false }),
  useQueryClient: () => ({ invalidateQueries: vi.fn() }),
  useMutation: (config: { mutationFn: (input: unknown) => Promise<unknown> }) => {
    f.captured = config;
    return { mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false };
  },
}));

import { useSaveDepartmentWhatsApp } from '@/hooks/team-chat/useDepartmentManagement';

const DEP = 'dep-1';

async function save(input: unknown): Promise<void> {
  renderHook(() => useSaveDepartmentWhatsApp(DEP));
  await act(async () => {
    await f.captured?.mutationFn(input);
  });
}

function rpcArgs(): Record<string, unknown> {
  return (f.rpc.mock.calls[0]?.[1] ?? {}) as Record<string, unknown>;
}

/** Monta o hook e devolve o erro que o mutationFn lancou (ou undefined se passou). */
async function saveErro(input: unknown): Promise<unknown> {
  renderHook(() => useSaveDepartmentWhatsApp(DEP));
  let capturado: unknown;
  await act(async () => {
    try {
      await f.captured?.mutationFn(input);
    } catch (e) {
      capturado = e;
    }
  });
  return capturado;
}

const ENTRADA = {
  mode: 'evolution' as const,
  config: { evolution_api_key: 'k-evo' },
  actorName: 'Ana',
};

describe('useSaveDepartmentWhatsApp — gravacao pelo contrato de banco, sem tabela fantasma', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    f.captured = undefined;
    f.rpc.mockResolvedValue({ data: { ok: true }, error: null });
  });

  it('grava pela RPC set_department_whatsapp_config (nao por department_whatsapp_configs)', async () => {
    await save({ mode: 'evolution', config: { evolution_api_key: 'k-evo' }, actorName: 'Ana' });

    expect(f.rpc).toHaveBeenCalledTimes(1);
    expect(f.rpc.mock.calls[0]?.[0]).toBe('set_department_whatsapp_config');
    expect(rpcArgs()).toMatchObject({
      p_department_id: DEP,
      p_whatsapp_mode: 'evolution',
      p_api_key: 'k-evo',
    });
    expect(f.from).not.toHaveBeenCalledWith(TABELA_FANTASMA);
  });

  it('modo official manda o token oficial como p_api_key', async () => {
    await save({ mode: 'official', config: { official_token: 'tok-oficial' }, actorName: 'Ana' });

    expect(rpcArgs()).toMatchObject({ p_whatsapp_mode: 'official', p_api_key: 'tok-oficial' });
  });

  it('modo none nao inventa chave nova (o banco mantem a existente por COALESCE)', async () => {
    await save({ mode: 'none', config: {}, actorName: 'Ana' });

    expect(rpcArgs().p_api_key).toBeUndefined();
  });

  it('nao duplica a auditoria no cliente: a RPC ja grava o evento', async () => {
    await save({ mode: 'evolution', config: { evolution_api_key: 'k-evo' }, actorName: 'Ana' });

    expect(f.from).not.toHaveBeenCalled();
  });

  it('RPC que responde ok:false vira erro (nao passa como salvo)', async () => {
    f.rpc.mockResolvedValueOnce({ data: { ok: false, error: 'not_authorized' }, error: null });

    const capturado = await saveErro(ENTRADA);

    expect((capturado as Error)?.message).toBe('not_authorized');
  });

  it('erro do PostgREST (fora do contrato) tambem propaga', async () => {
    f.rpc.mockResolvedValueOnce({ data: null, error: { message: 'PGRST202' } });

    const capturado = await saveErro(ENTRADA);

    expect(capturado).toMatchObject({ message: 'PGRST202' });
  });
});
