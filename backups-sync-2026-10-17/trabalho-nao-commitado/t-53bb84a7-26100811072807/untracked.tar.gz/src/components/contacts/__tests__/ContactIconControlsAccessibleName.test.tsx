import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import type { ReactElement } from 'react';
import { baseContact, noop } from './contactDeleteFixtures';

/**
 * MC-015 — nome acessível em TODO controle de ícone das 6 visões do módulo
 * Contatos (Cards, Lista, Tabela, Pipeline, Mapa, Analytics).
 *
 * O defeito: os controles feitos só de ícone (Conversar, Editar e o menu
 * "Mais ações de {nome}") chegavam ao usuário de leitor de tela sem nome — o
 * gatilho do menu é um botão sem texto, sem `aria-label` e sem `title`. Quem
 * navega por voz ouve apenas "botão" e não sabe se conversa, edita ou abre o
 * menu. A varredura é feita sobre os controles REAIS que cada visão renderiza
 * (`button`, `role="button"` e `role="checkbox"`), e o teste falha listando os
 * que não têm nome acessível — o punho de arrastar do Pipeline entra na conta
 * porque o @hello-pangea/dnd o publica como `role="button"` (dist/dnd.cjs.js).
 *
 * Nenhuma rede: o cliente do Supabase é mockado (as visões só o usam em ações
 * que este teste não dispara) e o desenho do Mapa fica pendente de propósito.
 */

const h = vi.hoisted(() => ({ invoke: vi.fn(), loadMapbox: vi.fn(), reportClientError: vi.fn() }));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: { functions: { invoke: (...a: unknown[]) => h.invoke(...a) } },
}));
vi.mock('@/lib/errorReporter', () => ({ reportClientError: (...a: unknown[]) => h.reportClientError(...a) }));
vi.mock('@/lib/logger', () => ({ log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() } }));
vi.mock('@/lib/mapboxLoader', () => ({ loadMapbox: () => h.loadMapbox() }));

import { ContactCard } from '../ContactCard';
import { ContactListItem } from '../ContactListItem';
import { ContactGroupedList } from '../ContactGroupedList';
import { ContactsTable } from '../ContactsTable';
import { ContactKanbanView } from '../ContactKanbanView';
import { ContactMapView } from '../ContactMapView';
import { ContactAnalyticsDashboard } from '../ContactAnalyticsDashboard';
import { resetMapboxTokenForTests } from '@/lib/mapboxToken';

const CONTATO = baseContact({
  name: 'Ana Souza',
  surname: 'Souza',
  company: 'Acme',
  email: 'ana@acme.com',
  job_title: 'Diretora',
  tags: ['vip'],
  contact_type: 'cliente',
});

const itemProps = {
  contact: CONTATO,
  isSelected: false,
  onToggleSelect: noop,
  onOpenDetails: noop,
  onOpenChat: noop,
  onEdit: noop,
  onDelete: noop,
  index: 0,
};

/** Controles que o usuário alcança na visão renderizada. */
function controles(container: HTMLElement): HTMLElement[] {
  return [
    ...within(container).queryAllByRole('button', { hidden: true }),
    ...within(container).queryAllByRole('checkbox', { hidden: true }),
  ];
}

/** Nome acessível vazio = controle mudo para leitor de tela. Devolve o HTML deles. */
function semNomeAcessivel(container: HTMLElement): string[] {
  const mudos: string[] = [];
  for (const el of controles(container)) {
    try {
      expect(el).toHaveAccessibleName();
    } catch {
      mudos.push(el.outerHTML.replace(/\s+/g, ' ').slice(0, 160));
    }
  }
  return mudos;
}

function renderComQuery(ui: ReactElement) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(<QueryClientProvider client={client}>{ui}</QueryClientProvider>);
}

beforeEach(() => {
  h.invoke.mockReset();
  h.invoke.mockResolvedValue({ data: { token: 'pk.test' }, error: null });
  h.loadMapbox.mockReset();
  h.loadMapbox.mockReturnValue(new Promise(() => {}));
  h.reportClientError.mockReset();
  resetMapboxTokenForTests();
});

describe('MC-015 · nome acessível nos controles de ícone', () => {
  it('Cards (grade): Conversar, Editar e "Mais ações de Ana Souza" têm nome', () => {
    const { container } = render(<ContactCard {...itemProps} />);

    expect(semNomeAcessivel(container)).toEqual([]);
    expect(within(container).getByRole('button', { name: 'Conversar' })).toBeInTheDocument();
    expect(within(container).getByRole('button', { name: 'Editar' })).toBeInTheDocument();
    expect(within(container).getByRole('button', { name: 'Mais ações de Ana Souza' })).toBeInTheDocument();
    expect(within(container).getByRole('checkbox', { name: 'Selecionar Ana Souza' })).toBeInTheDocument();
  });

  it('Lista: Conversar, o menu de cada item e a seleção têm nome', () => {
    const { container } = render(<ContactListItem {...itemProps} />);

    expect(semNomeAcessivel(container)).toEqual([]);
    expect(within(container).getByRole('button', { name: 'Conversar' })).toBeInTheDocument();
    expect(within(container).getByRole('button', { name: 'Mais ações de Ana Souza' })).toBeInTheDocument();
    expect(within(container).getByRole('checkbox', { name: 'Selecionar Ana Souza' })).toBeInTheDocument();
  });

  it('Lista agrupada: cabeçalho do grupo e itens têm nome', () => {
    const { container } = render(
      <ContactGroupedList
        contacts={[CONTATO]}
        selectedIds={[]}
        onToggleSelect={noop}
        onOpenDetails={noop}
        onOpenChat={noop}
        onEdit={noop}
        onDelete={noop}
      />,
    );

    expect(semNomeAcessivel(container)).toEqual([]);
    expect(within(container).getByRole('button', { name: /Acme/ })).toBeInTheDocument();
    expect(within(container).getByRole('button', { name: 'Mais ações de Ana Souza' })).toBeInTheDocument();
  });

  it('Tabela: Conversar, o menu da linha e a seleção têm nome', () => {
    const { container } = render(
      <ContactsTable
        contacts={[CONTATO]}
        selectedIds={[]}
        onSelectIds={noop}
        onOpenDetails={noop}
        onOpenChat={noop}
        onEdit={noop}
        onDelete={noop}
        searchQuery=""
      />,
    );

    expect(semNomeAcessivel(container)).toEqual([]);
    expect(within(container).getByRole('button', { name: 'Conversar' })).toBeInTheDocument();
    expect(within(container).getByRole('button', { name: 'Mais ações de Ana Souza' })).toBeInTheDocument();
    expect(within(container).getByRole('checkbox', { name: 'Selecionar Ana Souza' })).toBeInTheDocument();
    expect(within(container).getByRole('checkbox', { name: 'Selecionar todos' })).toBeInTheDocument();
  });

  it('Pipeline: o punho de arrastar do cartão tem nome', () => {
    const { container } = renderComQuery(
      <ContactKanbanView contacts={[CONTATO]} onContactClick={noop} />,
    );

    expect(semNomeAcessivel(container)).toEqual([]);
    expect(within(container).getByRole('button', { name: 'Arrastar Ana Souza' })).toBeInTheDocument();
  });

  it('Mapa: nenhum controle sem nome', () => {
    const { container } = render(
      <ContactMapView
        contacts={[{ id: CONTATO.id, name: CONTATO.name, phone: CONTATO.phone, company: 'Acme' }]}
        onContactClick={noop}
      />,
    );

    expect(semNomeAcessivel(container)).toEqual([]);
  });

  it('Analytics: nenhum controle sem nome', () => {
    const { container } = render(<ContactAnalyticsDashboard contacts={[CONTATO]} />);

    expect(semNomeAcessivel(container)).toEqual([]);
  });
});
