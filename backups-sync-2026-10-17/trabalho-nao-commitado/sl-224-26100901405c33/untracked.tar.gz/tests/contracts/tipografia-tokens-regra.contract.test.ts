import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const CLAUDE = 'CLAUDE.md';
const GUARD = 'scripts/qa/medir-tipografia.cjs';

/**
 * Contrato do ESTADO DOCUMENTAL da regra de tipografia — item E100 (etapa 100)
 * do `docs/tipografia/PLANO_AUDITORIA_FONTES_100_ETAPAS_2026-09-24.md`:
 * "Atualizar o `CLAUDE.md` com a regra: tamanho e família só por token; guard
 * cobre CSS, JSX e pesos."
 *
 * O risco é a regra viver só no comando do guard: quem escreve tela nova lê o
 * CLAUDE.md, não o `medir-tipografia.cjs`, e volta a cravar `text-[13px]` ou
 * `fontFamily: 'Inter'`. Este contrato prende as duas metades — o CLAUDE.md
 * declara a regra, e o guard citado existe de verdade cobrindo as três camadas
 * (CSS puro, JSX/TSX e peso fora do eixo carregado). A segunda metade é o que
 * impede o documento de apontar para um guard que não faz o que ele promete.
 */
describe('E100: CLAUDE.md declara a regra de tipografia e o guard citado cobre CSS, JSX e pesos', () => {
  const claude = readFileSync(CLAUDE, 'utf8');
  const guard = readFileSync(GUARD, 'utf8');

  it('o CLAUDE.md declara: tamanho e família somente por token', () => {
    expect(
      claude,
      'o CLAUDE.md precisa declarar que tamanho e família saem só de token',
    ).toMatch(/tamanho e fam[íi]lia s[óo] por token/i);
  });

  it('o CLAUDE.md declara que o guard cobre CSS, JSX e pesos', () => {
    expect(
      claude,
      'a regra precisa dizer as três camadas que o guard cobre, na mesma frase',
    ).toMatch(/CSS[\s\S]{0,40}JSX[\s\S]{0,40}pesos/i);
  });

  it('o CLAUDE.md aponta o guard e o comando que prova a regra', () => {
    expect(claude, 'o CLAUDE.md precisa citar o caminho do guard').toContain(GUARD);
    expect(
      claude,
      'o CLAUDE.md precisa citar o comando de checagem do guard',
    ).toMatch(/medir-tipografia\.cjs --check/);
  });

  it('o guard citado cobre de fato CSS, JSX/TSX e peso (não é promessa vazia)', () => {
    // As três camadas fechadas no F8: CSS puro, inline em .tsx e peso fora do eixo.
    expect(guard, 'scanner de CSS puro').toMatch(/function scanCss\b/);
    expect(guard, 'scanner de JSX/TSX inline').toMatch(/function scanTsxInline\b/);
    expect(guard, 'scanner de peso órfão').toMatch(/function scanOrphanWeights\b/);
    // E as contagens entram no ratchet do --check (senão o scanner não reprova nada).
    for (const chave of [
      'cssMeiaMedida',
      'cssFontFamilyLiteral',
      'tsxFontSizeInline',
      'tsxFontFamilyLiteral',
      'pesoOrfao',
    ]) {
      expect(guard, `contagem ${chave} ausente no guard`).toContain(chave);
    }
  });
});
