import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';

vi.mock('@/hooks/ui/useTheme', () => ({
  useTheme: () => ({ theme: 'light', setTheme: vi.fn() }),
}));

vi.mock('@/hooks/ui/useReducedMotion', () => ({
  useReducedMotion: () => false,
}));

vi.mock('@/components/settings/theme/useThemePreset', () => ({
  useThemePreset: () => ({
    config: { preset: 'default', borderRadius: 8 },
    hasUnsavedChanges: false,
    updateConfig: vi.fn(),
    applyPreset: vi.fn(),
    handleSave: vi.fn(),
    handleReset: vi.fn(),
  }),
}));

vi.mock('@/lib/logger', () => ({
  log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() },
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: () => ({
      select: () => ({
        eq: () => ({
          order: () => Promise.resolve({ data: [], error: null }),
        }),
      }),
    }),
  },
}));

import { ThemeCustomizer } from '../ThemeCustomizer';

describe('a11y: hierarquia de títulos — SHELL-14 Aparência (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('Skins usa h1 como título de página, não h3', () => {
    const { container } = render(<ThemeCustomizer />);
    const h1 = container.querySelector('h1');
    expect(h1).toBeInTheDocument();
    expect(h1?.textContent).toContain('Skins');
  });
});