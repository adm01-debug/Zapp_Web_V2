import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';

vi.mock('framer-motion', () => ({
  motion: { div: ({ children, ...props }: any) => <div {...props}>{children}</div> },
  AnimatePresence: ({ children }: any) => <>{children}</>,
  useReducedMotion: () => false,
}));

vi.mock('@/components/ui/tooltip', () => ({
  TooltipProvider: ({ children }: any) => <>{children}</>,
  Tooltip: ({ children }: any) => <>{children}</>,
  TooltipTrigger: ({ children }: any) => <>{children}</>,
  TooltipContent: ({ children }: any) => <>{children}</>,
}));

import { PresetCard } from '../PresetCard';

const preset = {
  id: 'test-preset',
  name: 'Test Preset',
  description: 'This is a long description that should be fully visible and not truncated by the truncate class',
  emoji: '🎨',
  swatches: ['#ff0000', '#00ff00', '#0000ff'],
};

describe('a11y: descrição da skin não truncada — SHELL-16 (Y18-6)', () => {
  it('texto da descrição é visível integralmente (sem truncate cortando)', () => {
    const { container } = render(<PresetCard preset={preset} isActive={false} onSelect={vi.fn()} />);
    expect(container.querySelector('p')?.textContent).toContain(preset.description);
  });

  it('parágrafo da descrição não tem a classe truncate', () => {
    const { container } = render(<PresetCard preset={preset} isActive={false} onSelect={vi.fn()} />);
    const descParagraph = container.querySelector('p.text-2xs.italic');
    expect(descParagraph).not.toHaveClass('truncate');
  });
});