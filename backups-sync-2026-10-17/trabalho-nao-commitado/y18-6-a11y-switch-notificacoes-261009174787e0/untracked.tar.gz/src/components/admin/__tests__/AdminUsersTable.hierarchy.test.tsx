import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';

vi.mock('@/hooks/system/useUserRole', () => ({
  useUserRole: () => ({ hasRole: () => true }),
}));

vi.mock('@/lib/logger', () => ({
  log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() },
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: () => ({
      select: () => ({
        eq: () => ({
          order: () => Promise.resolve({ data: [], error: null }),
        }),
      }),
    }),
  },
}));

import { AdminUsersTable } from '../AdminUsersTable';
import type { UserWithRole } from '../useAdminData';

function makeUser(overrides: Partial<UserWithRole> = {}): UserWithRole {
  return {
    id: 'p1',
    user_id: 'u1',
    name: 'Ana Silva',
    email: 'ana@test.local',
    avatar_url: null,
    nickname: null,
    signature: null,
    role: 'agent',
    job_title: null,
    department: null,
    phone: null,
    access_level: 'basic',
    max_chats: null,
    can_download: false,
    is_active: true,
    created_at: '2026-10-01T00:00:00.000Z',
    ...overrides,
  };
}

describe('a11y: hierarquia de títulos — SHELL-14 Admin Usuários (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('título Usuários está dentro de h2, não diretamente como h3 do CardTitle', () => {
    render(
      <AdminUsersTable
        users={[makeUser()]}
        isAdmin
        onRoleChange={vi.fn()}
        onToggleActive={vi.fn()}
        onEditUser={vi.fn()}
      />,
    );
    const h2 = screen.getByRole('heading', { level: 2, name: 'Usuários' });
    expect(h2).toBeInTheDocument();
  });
});