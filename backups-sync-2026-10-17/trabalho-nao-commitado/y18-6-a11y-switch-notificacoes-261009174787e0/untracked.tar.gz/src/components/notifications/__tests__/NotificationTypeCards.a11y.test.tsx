import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';

vi.mock('@/hooks/system/useNotificationSettings', () => ({
  useNotificationSettings: () => ({
    settings: {
      soundEnabled: true,
      soundVolume: 70,
      browserNotifications: false,
      quietHoursEnabled: false,
      quietHoursStart: '22:00',
      quietHoursEnd: '08:00',
      sentimentAlertEnabled: true,
      sentimentAlertThreshold: 30,
      sentimentConsecutiveCount: 3,
      transcriptionNotificationEnabled: true,
      messageSoundType: 'chime',
      mentionSoundType: 'bell',
      slaSoundType: 'alert',
      goalSoundType: 'chime',
      transcriptionSoundType: 'soft',
    },
    updateSettings: vi.fn(),
    resetSettings: vi.fn(),
    isQuietHours: () => false,
    isLoading: false,
    isSaving: false,
  }),
}));

vi.mock('@/lib/logger', () => ({
  log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() },
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: () => ({
      select: () => ({
        eq: () => ({
          order: () => Promise.resolve({ data: [], error: null }),
        }),
      }),
    }),
  },
}));

import { SentimentAlertCard } from '../NotificationTypeCards';
import { QuietHoursCard } from '../NotificationTypeCards';

describe('a11y: Switch com nome acessível — SentimentAlertCard (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('Switch de alertas de sentimento tem aria-label ligado ao rótulo visível', () => {
    render(
      <SentimentAlertCard
        settings={{
          sentimentAlertEnabled: true,
          sentimentAlertThreshold: 30,
          sentimentConsecutiveCount: 3,
        } as any}
        updateSettings={vi.fn()}
      />,
    );
    expect(screen.getByRole('switch', { name: 'Alertas de sentimento' })).toBeInTheDocument();
  });
});

describe('a11y: Switch com nome acessível — QuietHoursCard (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('Switch de horário silencioso tem aria-label ligado ao rótulo visível', () => {
    render(
      <QuietHoursCard
        settings={{
          quietHoursEnabled: false,
          quietHoursStart: '22:00',
          quietHoursEnd: '08:00',
        } as any}
        updateSettings={vi.fn()}
        isQuietHours={() => false}
      />,
    );
    expect(screen.getByRole('switch', { name: 'Horário silencioso' })).toBeInTheDocument();
  });
});