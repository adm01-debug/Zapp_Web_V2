import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';

vi.mock('@/hooks/system/useNotificationSettings', () => ({
  useNotificationSettings: () => ({
    settings: {
      soundEnabled: true,
      soundVolume: 70,
      browserNotifications: false,
      quietHoursEnabled: false,
      quietHoursStart: '22:00',
      quietHoursEnd: '08:00',
      sentimentAlertEnabled: true,
      sentimentAlertThreshold: 30,
      sentimentConsecutiveCount: 3,
      transcriptionNotificationEnabled: true,
      messageSoundType: 'chime',
      mentionSoundType: 'bell',
      slaSoundType: 'alert',
      goalSoundType: 'chime',
      transcriptionSoundType: 'soft',
    },
    updateSettings: vi.fn(),
    resetSettings: vi.fn(),
    isQuietHours: () => false,
    isLoading: false,
    isSaving: false,
  }),
}));

vi.mock('@/hooks/system/usePushNotifications', () => ({
  usePushNotifications: () => ({
    isEnabled: false,
    isSupported: true,
    permission: 'default',
    isSubscribed: false,
    isLoading: false,
    toggleSubscription: vi.fn(),
    showNotification: vi.fn(),
  }),
}));

vi.mock('@/lib/logger', () => ({
  log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() },
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: () => ({
      select: () => ({
        eq: () => ({
          order: () => Promise.resolve({ data: [], error: null }),
        }),
      }),
    }),
  },
}));

import { NotificationSettingsPanel } from '../NotificationSettingsPanel';

describe('a11y: Switch com nome acessível (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('Switch de sons de notificação tem aria-label ligado ao rótulo visível', () => {
    render(<NotificationSettingsPanel />);
    expect(screen.getByRole('switch', { name: 'Sons de notificação' })).toBeInTheDocument();
  });

  it('Switch de notificações do navegador tem aria-label ligado ao rótulo visível', () => {
    render(<NotificationSettingsPanel />);
    expect(screen.getByRole('switch', { name: 'Notificações do navegador' })).toBeInTheDocument();
  });

  it('axe não acusa Switch sem nome (regra aria-toggle-field-name)', async () => {
    const { container } = render(<NotificationSettingsPanel />);
    const results = await axe(container, {
      rules: { 'color-contrast': { enabled: false } },
    });
    const semNome = results.violations.filter((v) =>
      ['aria-toggle-field-name', 'aria-command-name'].includes(v.id),
    );
    expect(semNome).toEqual([]);
  });
});