import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';

vi.mock('@/hooks/auth/useAuth', () => ({
  useAuth: () => ({ user: { id: 'u-1', email: 'test@test.local' } }),
}));

vi.mock('@/hooks/auth/useMFA', () => ({
  useMfaFactors: () => ({
    data: [],
    isLoading: false,
    isError: false,
  }),
}));

vi.mock('@/hooks/ui/useDeviceDetection', () => ({
  useDeviceDetection: () => ({
    devices: [],
    sessions: [],
    loading: false,
  }),
}));

vi.mock('@/hooks/system/useUserRole', () => ({
  useUserRole: () => ({ hasRole: () => false }),
}));

vi.mock('@/lib/logger', () => ({
  log: { error: vi.fn(), warn: vi.fn(), info: vi.fn(), debug: vi.fn() },
}));

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          order: vi.fn(() => Promise.resolve({ data: [], error: null })),
        })),
      })),
    })),
  },
}));

import { SecurityOverview } from '../SecurityOverview';

describe('a11y: hierarquia de títulos — SHELL-14 (Y18-6)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('Pontuação de Segurança usa h2, não h3 (não pula nível)', () => {
    render(<SecurityOverview />);
    const heading = screen.getByRole('heading', { name: 'Pontuação de Segurança' });
    expect(heading.tagName).toBe('H2');
  });
});