/**
 * SL-114 · E74 — alvo de toque dos rótulos de 9–10px que são clicáveis.
 *
 * ── O defeito medido (ponta de 08/10/2026) ─────────────────────────────────
 * Existe uma família de rótulos clicáveis de 9–10px que NÃO declara caixa
 * nenhuma (nem `h-*`, nem `min-h-*`, nem padding vertical): o alvo de toque é a
 * própria linha do texto — 13 px com `text-3xs` (10/13) e ~13,5 px com o
 * `text-[9px]`. Fica MUITO abaixo do mínimo da WCAG 2.5.8 (Target Size
 * Minimum, AA = 24×24 px CSS), e o erro de mira cai no vizinho (o botão de
 * categoria ao lado, no caso dos dois seletores).
 *
 * `git grep -nE 'text-\[9px\]|text-3xs' src --include=*.tsx | grep -E
 *  'onClick|cursor-pointer|<button|<label'` lista os caminhos desta família.
 * Os que declaram caixa (chips com `px-* py-*`, `h-5`, `h-6`, `h-7`) NÃO entram
 * aqui: são controles com chrome, com alvo próprio, e ficam para o item de
 * piso de tipografia (E76), que é decisão de negócio.
 *
 * ── A correção ─────────────────────────────────────────────────────────────
 * Cada rótulo da família ganha o piso de 24 px (`min-h-6`, 1.5rem) sem mexer no
 * texto: `inline-flex items-center min-h-6` nos `<button>` e `min-h-6` no
 * `<label>` que já era `flex`. É o mesmo idioma do E61 desta base
 * (`SuggestionList` usa `min-h-11` = 44 px para a lista de toque do celular);
 * aqui o piso é o mínimo AA, que é o que um rótulo de texto embutido suporta
 * sem estourar o layout denso do desktop.
 *
 * ── Por que o teste lê `className` ─────────────────────────────────────────
 * O jsdom não pinta CSS: altura calculada não existe para `getComputedStyle`
 * (mesma limitação documentada no CT-67/CT-68 e no E61). O que se prova aqui é
 * o CONTRATO que o browser usa para pintar o alvo — a utility de piso no
 * elemento REAL — e, junto com ela, que o rótulo continua agindo: clicar
 * "IA sugere" troca a categoria e o rótulo some, "Todos" chama o `selectAll`,
 * o rótulo do gráfico alterna o checkbox.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';

// Radix mede os alvos com `ResizeObserver`, ausente no jsdom (o setup global só
// faz polyfill de `matchMedia`). Mesmo polyfill dos testes de catálogo.
if (typeof window.ResizeObserver === 'undefined') {
  window.ResizeObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
  } as unknown as typeof ResizeObserver;
}
if (!Element.prototype.scrollIntoView) Element.prototype.scrollIntoView = () => {};
if (!Element.prototype.hasPointerCapture) {
  Element.prototype.hasPointerCapture = () => false;
  Element.prototype.releasePointerCapture = () => {};
}

const memes = vi.hoisted(() => ({ hook: vi.fn() }));
vi.mock('@/hooks/communication/useAudioMemes', async () => {
  const actual = await vi.importActual<typeof import('@/hooks/communication/useAudioMemes')>(
    '@/hooks/communication/useAudioMemes'
  );
  return { ...actual, useAudioMemes: (...args: unknown[]) => memes.hook(...args) };
});

const emojis = vi.hoisted(() => ({ hook: vi.fn() }));
vi.mock('@/hooks/integrations/useCustomEmojis', async () => {
  const actual = await vi.importActual<typeof import('@/hooks/integrations/useCustomEmojis')>(
    '@/hooks/integrations/useCustomEmojis'
  );
  return { ...actual, useCustomEmojis: (...args: unknown[]) => emojis.hook(...args) };
});

const university = vi.hoisted(() => ({ hook: vi.fn() }));
vi.mock('@/hooks/ui/useUniversityHelp', async () => {
  const actual = await vi.importActual<typeof import('@/hooks/ui/useUniversityHelp')>(
    '@/hooks/ui/useUniversityHelp'
  );
  return { ...actual, useUniversityHelp: (...args: unknown[]) => university.hook(...args) };
});

const aiStats = vi.hoisted(() => ({ hook: vi.fn() }));
vi.mock('@/hooks/analytics/useAIStats', () => ({
  useAIStats: (...args: unknown[]) => aiStats.hook(...args),
}));

// ── TalkXCampaignWizard ────────────────────────────────────────────────────
// O assistente de campanha não tem harness de render na suíte (nenhum teste o
// monta hoje): o que importa aqui é o rodapé, onde vivem os dois links de nova
// tentativa. Por isso os passos e o editor entram como dublês e só o rodapé é
// exercitado de verdade.
vi.mock('sonner', () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), warning: vi.fn() }),
}));
vi.mock('@/hooks/system/useNavigationHistory', () => ({ navigateToView: vi.fn() }));
vi.mock('@/hooks/crm/useContactCustomFields', () => ({ useContactCustomFields: () => ({ fields: [] }) }));
vi.mock('@/hooks/integrations/useTalkXSegments', () => ({
  RULE_FIELDS: [], RULE_OPS: [],
  useAudienceEstimate: () => ({ estimate: 0, loading: false, error: null }),
}));
vi.mock('@/components/talkx/TalkXContactSelector', () => ({ TalkXContactSelector: () => <div /> }));
vi.mock('@/components/talkx/TalkXMessageEditor', () => ({ TalkXMessageEditor: () => <div /> }));
vi.mock('@/components/talkx/TalkXWizardDelivery', () => ({
  TalkXWizardDelivery: () => <div />, TalkXWizardReview: () => <div />,
}));
vi.mock('@/components/talkx/talkxShared', () => ({
  IconTile: () => <div />, WhatsAppBubble: () => <div />, OBJECTIVES: [], VARIABLE_KEYS: [],
  fmtInt: (n: number) => String(n), fmtPct: (n: number) => `${n}%`, personalizePreview: () => '',
  RailCard: ({ children }: { children?: React.ReactNode }) => <div>{children}</div>,
  MetaRow: () => <div />, fmtDateTime: () => '', TalkXWhatsAppDisconnectedState: () => <div />,
}));

/** Estado do editor que o rodapé lê — só o que os links de retry usam. */
const edWizard: Record<string, unknown> = {
  step: 1, setStep: vi.fn(), canProceed: true,
  name: 'Campanha', setName: vi.fn(), description: '', setDescription: vi.fn(),
  objective: null, setObjective: vi.fn(),
  audienceSource: 'all', setAudienceSource: vi.fn(), segmentId: null, setSegmentId: vi.fn(),
  segments: [], selectedSegment: null, segmentEstimate: null,
  templateId: null, applyTemplate: vi.fn(), templates: [], selectedTemplate: null,
  messageTemplate: '', setMessageTemplate: vi.fn(),
  saving: false, saveDraft: vi.fn(), hasUnsavedChanges: () => false,
  autosaveStatus: 'offline', autosaveError: null, retryAutosave: vi.fn(),
  autosaveIsDirty: false, lastAutosave: null,
  contacts: [], filteredContacts: [], selectedContacts: [], companies: [], tags: [],
  owners: [], owner: null, connections: [], connectionId: null,
  audienceRules: { groups: [] }, audienceCount: 0,
  mediaUrl: '', mediaType: 'image', hasMedia: false, isScheduled: false, scheduledAt: null,
};
/** Qualquer campo que o rodapé não use cai num dublê inócuo. */
const ed = new Proxy(edWizard, {
  get: (alvo, prop) => (prop in alvo ? alvo[prop as string] : vi.fn()),
});
vi.mock('@/components/talkx/useCampaignEditor', () => ({
  useCampaignEditor: () => ed,
  VARIABLES: [], MESSAGE_TEMPLATES: [], MEDIA_TYPES: [],
}));

import { AudioMemePicker } from '@/components/inbox/AudioMemePicker';
import { CustomEmojiPicker } from '@/components/inbox/CustomEmojiPicker';
import { UniversityHelp } from '@/components/inbox/UniversityHelp';
import { AIStatsWidget } from '@/components/dashboard/AIStatsWidget';
import { TooltipProvider } from '@/components/ui/tooltip';
import { TalkXCampaignWizard } from '@/components/talkx/TalkXCampaignWizard';

/** O piso do alvo (WCAG 2.5.8 AA): `min-h-6` = 1.5rem = 24 px CSS. */
const PISO = 'min-h-6';

/**
 * Abre o popover pelo gatilho. O Radix escuta `pointerdown` (não `click`) e um
 * clique real de mouse dispara a sequência inteira — mesmo helper dos testes
 * vizinhos (`GroupsView.test.tsx`, `TalkXView.templates.test.tsx`).
 */
function abrirPopover(nomeDoGatilho: RegExp) {
  const gatilho = screen.getByRole('button', { name: nomeDoGatilho });
  fireEvent.pointerDown(gatilho, { button: 0, ctrlKey: false });
  fireEvent.pointerUp(gatilho);
  fireEvent.click(gatilho);
}

beforeEach(() => {
  cleanup();
  memes.hook.mockReset();
  emojis.hook.mockReset();
  university.hook.mockReset();
  aiStats.hook.mockReset();
});

describe('SL-114 — o rótulo "IA sugere" (9px) tem alvo de toque de 24px', () => {
  const pendingMeme = {
    file: new File(['x'], 'risada.mp3', { type: 'audio/mpeg' }),
    audioUrl: 'blob:audio',
    storagePath: 'memes/risada.mp3',
    duration: 3,
    aiCategory: 'risada',
    // Categoria diferente da sugerida: é assim que o rótulo aparece na tela.
    selectedCategory: 'outros',
    name: 'Risada',
  };

  beforeEach(() => {
    memes.hook.mockReturnValue({
      memes: [], loading: false, uploading: false, playingId: null,
      pendingUpload: pendingMeme, audioRef: { current: null }, fileInputRef: { current: null },
      handlePreview: vi.fn(), handleFileSelect: vi.fn(), handleConfirmUpload: vi.fn(),
      handleCancelUpload: vi.fn(), handleSend: vi.fn(), toggleFavorite: vi.fn(),
      handleCategoryChange: vi.fn(), handleDelete: vi.fn(), cleanup: vi.fn(),
    });
    emojis.hook.mockReturnValue({
      emojis: [], loading: false, uploading: false,
      // A categoria do emoji é a do catálogo de `emojiConstants` (não a de áudio).
      pendingUpload: {
        file: new File(['x'], 'riso.png', { type: 'image/png' }),
        imageUrl: 'blob:emoji', storagePath: 'emojis/riso.png',
        aiCategory: 'riso', selectedCategory: 'amor', name: 'Riso',
      },
      fileInputRef: { current: null },
      handleFileSelect: vi.fn(), handleConfirmUpload: vi.fn(), handleCancelUpload: vi.fn(),
      handleSend: vi.fn(), toggleFavorite: vi.fn(), handleCategoryChange: vi.fn(),
      handleDelete: vi.fn(), setPendingUpload: vi.fn(),
    });
  });

  it('AudioMemePicker — "IA sugere" carrega o piso e a ação continua funcionando', () => {
    render(
      <TooltipProvider>
        <AudioMemePicker onSendAudio={vi.fn()} />
      </TooltipProvider>
    );
    abrirPopover(/Áudio Memes/i);

    const rotulo = screen.getByRole('button', { name: /IA sugere: Risada/i });
    expect(rotulo.className).toContain(PISO);
    expect(rotulo.className).toContain('inline-flex');

    // Ação: aplicar a sugestão troca a categoria — e o rótulo some (não há mais
    // divergência entre a categoria escolhida e a sugerida).
    fireEvent.click(rotulo);
    expect(screen.queryByRole('button', { name: /IA sugere/i })).toBeNull();
    expect(screen.getByRole('button', { name: /Risada/i })).toBeTruthy();
  });

  it('CustomEmojiPicker — "IA sugere" carrega o piso e a ação continua funcionando', () => {
    render(
      <TooltipProvider>
        <CustomEmojiPicker onSendEmoji={vi.fn()} />
      </TooltipProvider>
    );
    abrirPopover(/Emojis Personalizados/i);
    // O pré-visualização do upload (onde vive o rótulo) só existe na aba custom.
    fireEvent.click(screen.getByRole('button', { name: /Customizados/i }));

    const rotulo = screen.getByRole('button', { name: /IA sugere: Riso/i });
    expect(rotulo.className).toContain(PISO);
    expect(rotulo.className).toContain('inline-flex');

    fireEvent.click(rotulo);
    expect(screen.queryByRole('button', { name: /IA sugere/i })).toBeNull();
  });
});

describe('SL-114 — rótulos de texto clicáveis de 10px (sem caixa) têm piso de 24px', () => {
  it('UniversityHelp — "Todos/Limpar" carrega o piso e chama o selectAll', () => {
    const selectAll = vi.fn();
    university.hook.mockReturnValue({
      selectedIds: new Set<string>(),
      loading: false,
      response: null,
      selectedTone: 'profissional',
      setSelectedTone: vi.fn(),
      error: null,
      filterMode: 'all',
      setFilterMode: vi.fn(),
      filteredMessages: [{ id: 'm1', content: 'oi', sender: 'client', timestamp: '10:00' }],
      periodFilter: {
        analysisPeriod: '7d',
        setAnalysisPeriod: vi.fn(),
        customDateFrom: undefined,
        customDateTo: undefined,
        setCustomDateFrom: vi.fn(),
        setCustomDateTo: vi.fn(),
        clearCustomDates: vi.fn(),
        filteredMessages: [{ id: 'm1' }],
      },
      toggleMessage: vi.fn(),
      selectAll,
      generateResponse: vi.fn(),
      handleRegenerate: vi.fn(),
      lastCallRef: { current: 0 },
    });

    render(<UniversityHelp contactId="c1" messages={[{ id: 'm1', content: 'oi', sender: 'client', timestamp: '10:00' }]} />);

    // O rótulo "Todos/Limpar" é o botão vizinho do contador (o outro "Todos" da
    // tela é a pílula de filtro). Ancorar pelo contador evita ambiguidade.
    const contador = screen.getByText(
      (_, el) => el?.className?.includes?.('tabular-nums') === true && el.textContent?.replace(/\s+/g, '') === '0/1'
    );
    const rotulo = contador.parentElement!.querySelector('button') as HTMLElement;
    expect(rotulo.textContent).toBe('Todos');
    expect(rotulo.className).toContain(PISO);
    expect(rotulo.className).toContain('inline-flex');

    fireEvent.click(rotulo);
    expect(selectAll).toHaveBeenCalledTimes(1);
  });

  it('AIStatsWidget — o rótulo do sentimento carrega o piso e alterna o checkbox', () => {
    aiStats.hook.mockReturnValue({
      data: {
        totalAnalyses: 5,
        avgSentimentScore: 0.8,
        positiveSentiment: 3,
        negativeSentiment: 1,
        neutralSentiment: 1,
        transcriptionsCount: 2,
        activeAlerts: [],
        sentimentTrend: [{ date: '08/10', score: 0.8, positive: 3, negative: 1, neutral: 1 }],
        trends: {
          analyses: { direction: 'up', change: 5, percentage: 5 },
          sentiment: { direction: 'up', change: 5, percentage: 5 },
          negative: { direction: 'up', change: 5, percentage: 5 },
          transcriptions: { direction: 'up', change: 5, percentage: 5 },
        },
      },
      isLoading: false,
    });

    render(<AIStatsWidget />);

    const rotulo = screen.getByText('Positivo').closest('label') as HTMLElement;
    expect(rotulo).not.toBeNull();
    expect(rotulo.className).toContain(PISO);

    // Ação: o rótulo clicável alterna o checkbox que ele descreve.
    const checkbox = rotulo.querySelector('[role="checkbox"]') as HTMLElement;
    const antes = checkbox.getAttribute('data-state');
    fireEvent.click(rotulo);
    expect(checkbox.getAttribute('data-state')).not.toBe(antes);
  });
});

describe('SL-114 — links de retry do assistente de campanha (Talk X) têm piso de 24px', () => {
  beforeEach(() => {
    edWizard.retryAutosave = vi.fn();
    edWizard.autosaveStatus = 'offline';
    edWizard.autosaveError = null;
  });

  it('offline — o link carrega o piso e chama o retryAutosave', () => {
    render(<TalkXCampaignWizard campaign={null} onClose={vi.fn()} />);

    const link = screen.getByRole('button', { name: /Sem conexão — tentar novamente/i });
    expect(link.className).toContain(PISO);
    expect(link.className).toContain('inline-flex');

    fireEvent.click(link);
    expect(edWizard.retryAutosave).toHaveBeenCalledTimes(1);
  });

  it('erro de autosave — o link carrega o piso, mantém o truncate e chama o retryAutosave', () => {
    edWizard.autosaveStatus = 'error';
    edWizard.autosaveError = 'falha ao salvar';
    render(<TalkXCampaignWizard campaign={null} onClose={vi.fn()} />);

    const link = screen.getByRole('button', { name: /Não salvo — tentar novamente/i });
    expect(link.className).toContain(PISO);
    // `truncate` continua no elemento: o texto longo do erro não vaza do rodapé.
    expect(link.className).toContain('truncate');

    fireEvent.click(link);
    expect(edWizard.retryAutosave).toHaveBeenCalledTimes(1);
  });
});
