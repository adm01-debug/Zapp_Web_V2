import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { CallKpiCard } from '../CallKpiCard';

const mockUseReducedMotion = vi.fn();

vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...rest }: { children?: unknown }) => (
      <div data-testid="motion-div" {...rest}>{children as never}</div>
    ),
  },
  AnimatePresence: ({ children }: { children?: unknown }) => <>{children as never}</>,
  useReducedMotion: () => mockUseReducedMotion(),
}));

describe('CallKpiCard (T75)', () => {
  beforeEach(() => {
    mockUseReducedMotion.mockReturnValue(false);
  });

  it('fade de entrada com duracao 150ms quando useReducedMotion eh false', () => {
    render(<CallKpiCard rotulo="Total" valor="12" />);
    const motionDiv = screen.getByTestId('motion-div');
    expect(motionDiv).toBeInTheDocument();
    // Com useReducedMotion=false, o componente aplica initial/opacity=0 e transition duration 0.15
    expect(motionDiv).toHaveAttribute('initial');
    expect(motionDiv).toHaveAttribute('animate');
  });

  it('fade eh desabilitado quando useReducedMotion retorna true', () => {
    mockUseReducedMotion.mockReturnValue(true);
    render(<CallKpiCard rotulo="Total" valor="12" />);
    const motionDiv = screen.getByTestId('motion-div');
    expect(motionDiv).toBeInTheDocument();
    // Com useReducedMotion=true, initial/animate/transition sao undefined (sem animacao)
    expect(motionDiv).not.toHaveAttribute('initial');
    expect(motionDiv).not.toHaveAttribute('animate');
  });
});