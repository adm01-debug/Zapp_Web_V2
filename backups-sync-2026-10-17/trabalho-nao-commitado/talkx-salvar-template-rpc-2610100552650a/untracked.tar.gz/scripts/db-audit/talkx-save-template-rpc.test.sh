#!/usr/bin/env bash
set -Eeuo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
migration="${TALKX_SAVE_TEMPLATE_MIGRATION:-$repo_root/supabase/migrations/20261010000000_talkx_template_save_with_note.sql}"

fail() { printf '[FALHA] %s\n' "$1" >&2; exit 1; }
ok() { printf '[OK] %s\n' "$1"; }

[[ -f "$migration" ]] || fail "migration nao encontrada: $migration"

cid="zapp-v2-n173-debug"
docker exec "$cid" pg_isready -U postgres >/dev/null 2>&1 || fail "Container $cid nao esta rodando"

psql_bootstrap() { docker exec -i "$cid" psql -X -q -v ON_ERROR_STOP=1 -U postgres -d postgres "$@"; }
psql_auth() { docker exec -i "$cid" psql -X -q -v ON_ERROR_STOP=1 -U postgres -d postgres -c "SET LOCAL request.jwt.claim.role = 'authenticated'; SET LOCAL request.jwt.claim.sub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; $1" || true; }
psql_auth_val() { docker exec -i "$cid" psql -X -q -t -v ON_ERROR_STOP=1 -U postgres -d postgres -c "SET LOCAL request.jwt.claim.role = 'authenticated'; SET LOCAL request.jwt.claim.sub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; $1" | sed '/^$/d' | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'; }

# Monta schema ANTERIOR a esta migration (sem note, sem save_talkx_template).
psql_bootstrap >/dev/null <<'PRESQL'
SET client_min_messages TO warning;
DROP POLICY IF EXISTS authenticated_access ON public.talkx_templates;
DROP POLICY IF EXISTS authenticated_access ON public.talkx_template_versions;
DROP FUNCTION IF EXISTS public.save_talkx_template() CASCADE;
DROP FUNCTION IF EXISTS public.restore_talkx_template_version() CASCADE;
DROP FUNCTION IF EXISTS public.list_talkx_template_versions() CASCADE;
DROP FUNCTION IF EXISTS public.update_talkx_template_with_snapshot() CASCADE;
DROP FUNCTION IF EXISTS public.get_profile_id_for_user(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.is_admin_or_supervisor(uuid) CASCADE;
ALTER TABLE IF EXISTS public.talkx_template_versions DROP COLUMN IF EXISTS note;
DROP TABLE IF EXISTS public.talkx_template_versions CASCADE;
DROP TABLE IF EXISTS public.talkx_template_variants CASCADE;
DROP TABLE IF EXISTS public.talkx_templates CASCADE;
DROP TABLE IF EXISTS public.user_roles CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP SCHEMA IF EXISTS auth CASCADE;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN NOSUPERUSER;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    CREATE ROLE anon NOLOGIN NOSUPERUSER;
  END IF;
END; $$;
CREATE SCHEMA auth;
CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('request.jwt.claim.sub', true), '')::uuid; $$;
CREATE OR REPLACE FUNCTION auth.role() RETURNS text LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('request.jwt.claim.role', true), '')::text; $$;
CREATE TABLE public.profiles (id uuid PRIMARY KEY, user_id uuid UNIQUE, email text);
CREATE TABLE public.user_roles (user_id uuid PRIMARY KEY, role text NOT NULL);
CREATE OR REPLACE FUNCTION public.get_profile_id_for_user(_user_id uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM public.profiles WHERE user_id = _user_id LIMIT 1;
$$;
CREATE OR REPLACE FUNCTION public.is_admin_or_supervisor(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin', 'supervisor'));
$$;
CREATE TABLE public.talkx_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, description text, category text NOT NULL, content text NOT NULL,
  media_url text, media_type text, tags text[] NOT NULL DEFAULT '{}',
  custom_variables text[] NOT NULL DEFAULT '{}', status text NOT NULL DEFAULT 'draft',
  created_by uuid REFERENCES public.profiles(id), updated_at timestamptz NOT NULL DEFAULT statement_timestamp()
);
CREATE TABLE public.talkx_template_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid NOT NULL REFERENCES public.talkx_templates(id) ON DELETE CASCADE,
  label text NOT NULL, content text NOT NULL, media_url text, media_type text,
  is_control boolean NOT NULL DEFAULT false, weight integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT statement_timestamp()
);
CREATE TABLE public.talkx_template_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid NOT NULL REFERENCES public.talkx_templates(id) ON DELETE CASCADE,
  version_number integer NOT NULL, name text NOT NULL, description text,
  content text NOT NULL, category text NOT NULL, status text NOT NULL,
  media_url text, media_type text, tags text[] NOT NULL DEFAULT '{}',
  custom_variables text[] NOT NULL DEFAULT '{}',
  saved_by uuid REFERENCES public.profiles(id), created_at timestamptz NOT NULL DEFAULT statement_timestamp()
);
ALTER TABLE public.talkx_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated_access" ON public.talkx_templates FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "authenticated_access" ON public.talkx_template_versions FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "authenticated_access" ON public.talkx_template_variants FOR ALL TO authenticated USING (true) WITH CHECK (true);
GRANT authenticated, anon TO postgres;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.talkx_templates TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.talkx_template_variants TO authenticated;
GRANT SELECT, INSERT ON public.profiles TO authenticated;
GRANT SELECT, INSERT ON public.user_roles TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_profile_id_for_user(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin_or_supervisor(uuid) TO authenticated;
GRANT SELECT ON public.talkx_template_versions TO authenticated;
PRESQL
ok "pre.sql aplicado (schema ANTERIOR a esta migration)"

# Perfil e template de teste.
psql_auth "INSERT INTO public.profiles (id, user_id, email) VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'test@test.com');" >/dev/null
psql_auth "INSERT INTO public.talkx_templates (id, name, category, content, status, created_by, updated_at)
VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'T1', 'cat', 'conteudo', 'draft',
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2026-01-01T00:00:00Z');" >/dev/null

# Aplica a migration real.
psql_bootstrap >/dev/null < "$migration"
ok "migration aplicada"

# Prova 1: save_talkx_template existe.
has_func="$(psql_bootstrap -Atqc "SELECT count(*) FROM pg_proc WHERE proname = 'save_talkx_template';")"
[[ "$has_func" == "1" ]] || fail "save_talkx_template nao existe"
ok "save_talkx_template existe"

# Prova 2: restore_talkx_template_version existe.
has_restore="$(psql_bootstrap -Atqc "SELECT count(*) FROM pg_proc WHERE proname = 'restore_talkx_template_version';")"
[[ "$has_restore" == "1" ]] || fail "restore_talkx_template_version nao existe"
ok "restore_talkx_template_version existe"

# Prova 3: list_talkx_template_versions existe.
has_list="$(psql_bootstrap -Atqc "SELECT count(*) FROM pg_proc WHERE proname = 'list_talkx_template_versions';")"
[[ "$has_list" == "1" ]] || fail "list_talkx_template_versions nao existe"
ok "list_talkx_template_versions existe"

# Prova 4: note column existe em talkx_template_versions.
has_note="$(psql_bootstrap -Atqc "SELECT count(*) FROM information_schema.columns WHERE table_name='talkx_template_versions' AND column_name='note';")"
[[ "$has_note" == "1" ]] || fail "coluna note nao existe"
ok "coluna note existe em talkx_template_versions"

# Prova 5: save_talkx_template funciona como authenticated e grava nota + version_number.
result="$(psql_auth "SELECT public.save_talkx_template(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '2026-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo novo\",\"status\":\"draft\"}',
  'nota de teste'
);")"
printf '%s\n' "$result" | grep -q "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa" || fail "save_talkx_template nao retornou template_id"
printf '%s\n' "$result" | grep -qE "\,[0-9]+\)$" || fail "version_number esperado 1, obtido: $result"
ok "save_talkx_template retorna template_id e version_number=1"

# Prova 6: note foi gravada na versao criada.
note_val="$(psql_auth "SELECT note FROM public.talkx_template_versions WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';" | awk 'NR==3{gsub(/^[ \t]+/,""); gsub(/[ \t]+$/,""); print; exit}')"
[[ "$note_val" == "nota de teste" ]] || fail "note esperada 'nota de teste', obtida '$note_val'"
ok "note gravada corretamente na versao"

# Prova 7: template vivo foi atualizado.
live_name="$(psql_auth_val "SELECT name FROM public.talkx_templates WHERE id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';")"
[[ "$live_name" == "T1" ]] || fail "nome do template vivo esperado 'T1', obtido '$live_name'"
ok "template vivo atualizado"

# Prova 8: status nao mudou (continua draft).
live_status="$(psql_auth_val "SELECT status FROM public.talkx_templates WHERE id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';")"
[[ "$live_status" == "draft" ]] || fail "status esperado 'draft', obtido '$live_status'"
ok "status nao alterado pela RPC (continua draft)"

# Prova 9: version_number incrementou para 2 na segunda chamada (content mudou).
result2="$(psql_auth "SELECT public.save_talkx_template(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '2026-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo v2\",\"status\":\"approved\"}',
  'segunda nota'
);")"
printf '%s\n' "$result2" | grep -qE "\,[0-9]+\)$" || fail "version_number esperado 2, obtido: $result2"
ok "version_number incrementado para 2"

# Prova 10: mudar so tags nao gera versao (content, midia, interactive e custom_variables nao mudaram).
result_tags="$(psql_auth "SELECT public.save_talkx_template(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '2026-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo v2\",\"tags\":[\"tag1\",\"tag2\"]}',
  'só tags'
);")"
# A segunda chamada com content igual ao vivo nao deveria criar versao nova
# mas como content ja mudou na prova 9, agora content é o mesmo.
# Vamos verificar: a count de versoes deve ser 2 (nao 3).
version_count="$(psql_auth_val "SELECT count(*) FROM public.talkx_template_versions WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';")"
[[ "$version_count" == "2" ]] || fail "mudar só tags nao deve gerar versao (count=$version_count, esperado 2)"
ok "mudar só tags nao gera versao"

# Prova 11: 51 mudancas de content → count(*)=50 (limite de 50 versoes).
for i in $(seq 1 51); do
  psql_auth "SELECT public.save_talkx_template(
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    '2026-01-01T00:00:00Z'::timestamptz,
    '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo iteracao $i\"}',
    'iteracao $i'
  )" >/dev/null
done
version_count_51="$(psql_auth_val "SELECT count(*) FROM public.talkx_template_versions WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';")"
[[ "$version_count_51" == "50" ]] || fail "51 mudancas deveriam resultar em 50 versoes (obtido=$version_count_51)"
ok "51 mudancas de content → count(*)=50"

# Prova 12: restore_talkx_template_version aplica a versao como save novo.
# Primeiro, pega o id da versao 1.
v1_id="$(psql_auth_val "SELECT id FROM public.talkx_template_versions WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' AND version_number=1;")"
restore_result="$(psql_auth "SELECT public.restore_talkx_template_version(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '$v1_id',
  '2026-01-01T00:00:00Z'::timestamptz
);")"
printf '%s\n' "$restore_result" | grep -qE "2$" || fail "restore deveria criar versao 2, obtido: $restore_result"
ok "restore_talkx_template_version cria versao com conteudo restaurado"

# Prova 13: restore gera nota "Restaurado de v1".
restore_note="$(psql_auth_val "SELECT note FROM public.talkx_template_versions WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' ORDER BY version_number DESC LIMIT 1;")"
[[ "$restore_note" == "Restaurado de v1" ]] || fail "nota de restore esperada 'Restaurado de v1', obtida '$restore_note'"
ok "restore gera nota Restaurado de vN"

# Prova 14: p_expected_updated_at antigo → talkx_template_stale_version.
stale_result="$(psql_auth "SELECT public.save_talkx_template(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '2025-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo qualquer\"}',
  'teste stale'
);" || true)"
printf '%s\n' "$stale_result" | grep -q "talkx_template_stale_version" || fail "expected stale_version error, got: $stale_result"
ok "p_expected_updated_at antigo → talkx_template_stale_version"

# Prova 15: agente que nao é autor → talkx_template_not_authorized.
# Cria um segundo perfil e template.
psql_auth "INSERT INTO public.profiles (id, user_id, email) VALUES ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'other@test.com');" >/dev/null
psql_auth "INSERT INTO public.talkx_templates (id, name, category, content, status, created_by, updated_at)
VALUES ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'T2', 'cat', 'conteudo T2', 'draft',
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2026-01-01T00:00:00Z');" >/dev/null

# Tenta salvar como o mesmo usuario autenticado (que nao é o dono)
auth_result="$(psql_auth "SELECT public.save_talkx_template(
  'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
  '2026-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T2\",\"category\":\"cat\",\"content\":\"conteudo T2 alterado\"}',
  'teste auth'
);" 2>&1 || true)"
printf '%s\n' "$auth_result" | grep -q "talkx_template_not_authorized" || fail "expected not_authorized error, got: $auth_result"
ok "agente que nao é autor → talkx_template_not_authorized"

# Prova 16: template com controle → conteudo do controle igual ao novo texto-base.
# Simula is_control adicionando a coluna e uma variante de controle.
psql_bootstrap >/dev/null <<'SETUP_CONTROL'
ALTER TABLE public.talkx_template_variants ADD COLUMN IF NOT EXISTS is_control boolean DEFAULT false;
INSERT INTO public.talkx_template_variants (template_id, label, content, media_url, is_control, weight)
VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'A', 'conteudo original', NULL, true, 100);
SETUP_CONTROL
ok "setup de variante is_control feito"

# Agora salva com novo conteudo
psql_auth "SELECT public.save_talkx_template(
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  '2026-01-01T00:00:00Z'::timestamptz,
  '{\"name\":\"T1\",\"category\":\"cat\",\"content\":\"conteudo novo base\"}',
  'teste controle'
)" >/dev/null

# Verifica que a variante de controle agora tem o mesmo conteudo
control_content="$(psql_auth_val "SELECT content FROM public.talkx_template_variants WHERE template_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' AND is_control=true;")"
[[ "$control_content" == "conteudo novo base" ]] || fail "conteudo do controle esperado 'conteudo novo base', obtido '$control_content'"
ok "template com controle → conteudo do controle igual ao novo texto-base"

# Prova 17: update_talkx_template_with_snapshot continua existindo.
has_wrapper="$(psql_bootstrap -Atqc "SELECT count(*) FROM pg_proc WHERE proname = 'update_talkx_template_with_snapshot';")"
[[ "$has_wrapper" == "1" ]] || fail "update_talkx_template_with_snapshot nao existe"
ok "update_talkx_template_with_snapshot continua existindo"

# Prova 18: rollback remove a funcao e a coluna.
rollback_ok="$(psql_bootstrap -Atqc "
  DO \$\$ BEGIN
    EXECUTE 'DROP FUNCTION IF EXISTS public.save_talkx_template(uuid, timestamptz, jsonb, text)';
    EXECUTE 'DROP FUNCTION IF EXISTS public.restore_talkx_template_version(uuid, uuid, timestamptz)';
    EXECUTE 'DROP FUNCTION IF EXISTS public.list_talkx_template_versions(uuid, integer, timestamptz)';
    EXECUTE 'DROP FUNCTION IF EXISTS public.update_talkx_template_with_snapshot(uuid, timestamptz, text, text, text, text, text, text, text[], text, text[])';
    EXECUTE 'ALTER TABLE public.talkx_template_versions DROP COLUMN IF EXISTS note';
  EXCEPTION WHEN OTHERS THEN RAISE NOTICE 'rollback falhou: %', SQLERRM;
  END; \$\$;
  SELECT count(*) FROM pg_proc WHERE proname IN ('save_talkx_template', 'restore_talkx_template_version', 'list_talkx_template_versions', 'update_talkx_template_with_snapshot');
")"
[[ "$rollback_ok" == "0" ]] || fail "rollback nao removeu funcoes (count=$rollback_ok)"
note_after="$(psql_bootstrap -Atqc "SELECT count(*) FROM information_schema.columns WHERE table_name='talkx_template_versions' AND column_name='note';")"
[[ "$note_after" == "0" ]] || fail "rollback nao removeu coluna note (count=$note_after)"
ok "rollback remove funcoes save_talkx_template, restore_talkx_template_version, list_talkx_template_versions, update_talkx_template_with_snapshot e coluna note"

# Restaura a migration no banco (estado limpo para proximo teste).
psql_bootstrap >/dev/null < "$migration"
ok "estado original restaurado (migration re-aplicada)"

printf '\n'
ok 'talkx_save_template_rpc: GREEN confirmado — funcoes save_talkx_template, restore_talkx_template_version, list_talkx_template_versions e update_talkx_template_with_snapshot existem, note column existe, nota e version_number gravados, status nao alterado, snapshot condicional, limite de 50 versoes, restore funciona, stale_version e not_authorized erram, controle sincroniza, rollback funciona.'