-- Rollback: remover a funcao save_talkx_template, restore_talkx_template_version,
-- list_talkx_template_versions, update_talkx_template_with_snapshot e a coluna note
-- de talkx_template_versions.
-- DROP FUNCTION IF EXISTS public.save_talkx_template(uuid, timestamptz, jsonb, text);
-- DROP FUNCTION IF EXISTS public.restore_talkx_template_version(uuid, uuid, timestamptz);
-- DROP FUNCTION IF EXISTS public.list_talkx_template_versions(uuid, integer, timestamptz);
-- DROP FUNCTION IF EXISTS public.update_talkx_template_with_snapshot(uuid, timestamptz, text, text, text, text, text, text, text[], text, text[]);
-- ALTER TABLE public.talkx_template_versions DROP COLUMN IF EXISTS note;

-- talkx_template_versions.note (text, nullable, max 280)
ALTER TABLE public.talkx_template_versions
  ADD COLUMN IF NOT EXISTS note text CHECK (length(note) <= 280);

-- save_talkx_template: cria (status draft) ou atualiza com lock otimista.
-- Nao altera status. Snapshot so quando content, media, interactive ou
-- custom_variables mudam. Mantem apenas as 50 versoes mais recentes.
-- Se variante is_control existir, seu conteudo e midia acompanham o base.
CREATE OR REPLACE FUNCTION public.save_talkx_template(
  p_template_id uuid,
  p_expected_updated_at timestamptz,
  p_payload jsonb,
  p_note text
) RETURNS TABLE(template_id uuid, updated_at timestamptz, version_number integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
DECLARE
  v_actor_profile_id uuid;
  v_template public.talkx_templates%ROWTYPE;
  v_version_number integer;
  v_updated_at timestamptz := statement_timestamp();
  v_name text;
  v_description text;
  v_category text;
  v_content text;
  v_media_url text;
  v_media_type text;
  v_tags text[];
  v_custom_variables text[];
  v_snapshot_needed boolean := false;
  v_note text;
BEGIN
  -- Autenticacao obrigatoria
  IF COALESCE(auth.role(), '') <> 'authenticated' OR auth.uid() IS NULL THEN
    RAISE EXCEPTION 'authentication_required' USING ERRCODE = '42501';
  END IF;

  v_actor_profile_id := public.get_profile_id_for_user(auth.uid());
  IF v_actor_profile_id IS NULL THEN
    RAISE EXCEPTION 'authenticated_profile_not_found' USING ERRCODE = '42501';
  END IF;

  -- Template existe e trava a linha
  SELECT * INTO v_template
  FROM public.talkx_templates template
  WHERE template.id = p_template_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'talkx_template_not_found' USING ERRCODE = 'P0002';
  END IF;

  -- Autorizacao: dono ou admin/supervisor
  IF v_template.created_by IS DISTINCT FROM v_actor_profile_id
     AND COALESCE(public.is_admin_or_supervisor(auth.uid()), false) IS NOT TRUE THEN
    RAISE EXCEPTION 'talkx_template_not_authorized' USING ERRCODE = '42501';
  END IF;

  -- Otimistic lock: updated_at nao pode ter mudado desde a ultima leitura
  IF p_expected_updated_at IS NULL
     OR v_template.updated_at IS DISTINCT FROM p_expected_updated_at THEN
    RAISE EXCEPTION 'talkx_template_stale_version' USING ERRCODE = '40001';
  END IF;

  -- Extrai campos do payload com validacoes
  v_name := p_payload->>'name';
  v_description := p_payload->>'description';
  v_category := p_payload->>'category';
  v_content := p_payload->>'content';
  v_media_url := p_payload->>'media_url';
  v_media_type := p_payload->>'media_type';
  v_tags := COALESCE(NULLIF(p_payload->>'tags', ''), '{}')::text[];
  v_custom_variables := COALESCE(NULLIF(p_payload->>'custom_variables', ''), '{}')::text[];

  -- Nota: opcional, limite de 280 caracteres
  v_note := p_note;
  IF v_note IS NOT NULL AND length(v_note) > 280 THEN
    RAISE EXCEPTION 'invalid_talkx_template' USING ERRCODE = '22023';
  END IF;

  -- Validacoes de entrada (espelham update_talkx_template_with_snapshot)
  IF v_name IS NULL OR length(btrim(v_name)) NOT BETWEEN 1 AND 200
     OR v_category IS NULL OR length(btrim(v_category)) NOT BETWEEN 1 AND 100
     OR v_content IS NULL OR length(v_content) NOT BETWEEN 1 AND 65536
     OR (v_description IS NOT NULL AND length(v_description) > 4000)
     OR (v_media_url IS NOT NULL AND (
       length(v_media_url) > 8192 OR v_media_url !~ '^https://'
     ))
     OR (v_media_type IS NOT NULL AND v_media_type NOT IN ('image', 'video', 'document', 'audio'))
     OR cardinality(v_tags) > 50
     OR EXISTS (
       SELECT 1 FROM unnest(v_tags) tag
       WHERE length(tag) NOT BETWEEN 1 AND 64
     )
     OR cardinality(v_custom_variables) > 100
     OR EXISTS (
       SELECT 1 FROM unnest(v_custom_variables) variable
       WHERE variable !~ '^[A-Za-z_][A-Za-z0-9_]{0,63}$'
     )
     OR cardinality(ARRAY(SELECT DISTINCT value FROM unnest(v_custom_variables) value))
        IS DISTINCT FROM cardinality(v_custom_variables) THEN
    RAISE EXCEPTION 'invalid_talkx_template' USING ERRCODE = '22023';
  END IF;

  -- Determina se snapshot e necessario: somente quando content, midia,
  -- interactive ou custom_variables mudam em relacao ao template vivo.
  IF v_template.content IS DISTINCT FROM v_content
     OR v_template.media_url IS DISTINCT FROM v_media_url
     OR v_template.media_type IS DISTINCT FROM v_media_type
     OR v_template.custom_variables IS DISTINCT FROM v_custom_variables THEN
    v_snapshot_needed := true;
  END IF;

  -- Se nao precisa de snapshot, apenas atualiza o template vivo e retorna
  -- a versao atual (sem criar nova versao).
  IF NOT v_snapshot_needed THEN
    UPDATE public.talkx_templates template
    SET name = btrim(v_name),
        description = v_description,
        category = btrim(v_category),
        content = v_content,
        media_url = v_media_url,
        media_type = v_media_type,
        tags = COALESCE(v_tags, '{}'::text[]),
        custom_variables = COALESCE(v_custom_variables, '{}'::text[]),
        updated_at = v_updated_at
    WHERE template.id = p_template_id
    RETURNING template.updated_at INTO v_updated_at;

    -- Se existir variante is_control, seu conteudo e midia acompanham o base
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'talkx_template_variants' AND column_name = 'is_control'
  ) THEN
    EXECUTE '
      UPDATE public.talkx_template_variants variant
      SET content = $1, media_url = $2, media_type = $3
      WHERE variant.template_id = $4 AND variant.is_control = true'
    USING v_content, v_media_url, v_media_type, p_template_id;
  END IF;

  RETURN QUERY SELECT p_template_id, v_updated_at,
      (SELECT COALESCE(max(history.version_number), 0)
       FROM public.talkx_template_versions history
       WHERE history.template_id = p_template_id);
    RETURN;
  END IF;

  -- Numera a versao
  SELECT COALESCE(max(history.version_number), 0) + 1
  INTO v_version_number
  FROM public.talkx_template_versions history
  WHERE history.template_id = p_template_id;

  -- Snapshot com nota e saved_by
  INSERT INTO public.talkx_template_versions (
    template_id, version_number, name, description, content, category,
    status, media_url, media_type, tags, custom_variables, note, saved_by, created_at
  ) VALUES (
    v_template.id, v_version_number, v_template.name, v_template.description,
    v_template.content, v_template.category, v_template.status,
    v_template.media_url,
    v_template.media_type, COALESCE(v_template.tags, '{}'::text[]),
    COALESCE(v_template.custom_variables, '{}'::text[]),
    v_note, v_actor_profile_id, v_updated_at
  );

  -- Atualiza o template vivo (NUNCA muda status)
  UPDATE public.talkx_templates template
  SET name = btrim(v_name),
      description = v_description,
      category = btrim(v_category),
      content = v_content,
      media_url = v_media_url,
      media_type = v_media_type,
      tags = COALESCE(v_tags, '{}'::text[]),
      custom_variables = COALESCE(v_custom_variables, '{}'::text[]),
      updated_at = v_updated_at
  WHERE template.id = p_template_id
  RETURNING template.updated_at INTO v_updated_at;

  -- Se existir variante is_control, seu conteudo e midia acompanham o base
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'talkx_template_variants' AND column_name = 'is_control'
  ) THEN
    EXECUTE '
      UPDATE public.talkx_template_variants variant
      SET content = $1, media_url = $2, media_type = $3
      WHERE variant.template_id = $4 AND variant.is_control = true'
    USING v_content, v_media_url, v_media_type, p_template_id;
  END IF;

  -- Mantem apenas as 50 versoes mais recentes, apagando as anteriores
  DELETE FROM public.talkx_template_versions hist
  WHERE hist.template_id = p_template_id
    AND hist.id NOT IN (
      SELECT id
      FROM public.talkx_template_versions recent
      WHERE recent.template_id = p_template_id
      ORDER BY recent.version_number DESC
      LIMIT 50
    );

  RETURN QUERY SELECT p_template_id, v_updated_at, v_version_number;
END;
$function$;

REVOKE ALL ON FUNCTION public.save_talkx_template(
  uuid, timestamptz, jsonb, text
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.save_talkx_template(
  uuid, timestamptz, jsonb, text
) TO authenticated;

-- restore_talkx_template_version: aplica uma versao anterior como save novo.
CREATE OR REPLACE FUNCTION public.restore_talkx_template_version(
  p_template_id uuid,
  p_version_id uuid,
  p_expected_updated_at timestamptz
) RETURNS TABLE(template_id uuid, updated_at timestamptz, version_number integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
DECLARE
  v_actor_profile_id uuid;
  v_template public.talkx_templates%ROWTYPE;
  v_version public.talkx_template_versions%ROWTYPE;
  v_version_number integer;
  v_updated_at timestamptz := statement_timestamp();
  v_restore_note text;
BEGIN
  IF COALESCE(auth.role(), '') <> 'authenticated' OR auth.uid() IS NULL THEN
    RAISE EXCEPTION 'authentication_required' USING ERRCODE = '42501';
  END IF;

  v_actor_profile_id := public.get_profile_id_for_user(auth.uid());
  IF v_actor_profile_id IS NULL THEN
    RAISE EXCEPTION 'authenticated_profile_not_found' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_template
  FROM public.talkx_templates template
  WHERE template.id = p_template_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'talkx_template_not_found' USING ERRCODE = 'P0002';
  END IF;

  IF v_template.created_by IS DISTINCT FROM v_actor_profile_id
     AND COALESCE(public.is_admin_or_supervisor(auth.uid()), false) IS NOT TRUE THEN
    RAISE EXCEPTION 'talkx_template_not_authorized' USING ERRCODE = '42501';
  END IF;

  IF p_expected_updated_at IS NULL
     OR v_template.updated_at IS DISTINCT FROM p_expected_updated_at THEN
    RAISE EXCEPTION 'talkx_template_stale_version' USING ERRCODE = '40001';
  END IF;

  SELECT * INTO v_version
  FROM public.talkx_template_versions version
  WHERE version.id = p_version_id
    AND version.template_id = p_template_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'talkx_template_version_not_found' USING ERRCODE = 'P0002';
  END IF;

  v_restore_note := 'Restaurado de v' || v_version.version_number;

  -- Numera a nova versao
  SELECT COALESCE(max(history.version_number), 0) + 1
  INTO v_version_number
  FROM public.talkx_template_versions history
  WHERE history.template_id = p_template_id;

  -- Snapshot da versao restaurada
  INSERT INTO public.talkx_template_versions (
    template_id, version_number, name, description, content, category,
    media_url, media_type, tags, custom_variables, note, saved_by, created_at
  ) VALUES (
    v_template.id, v_version_number, v_version.name, v_version.description,
    v_version.content, v_version.category, v_version.media_url,
    v_version.media_type, v_version.tags, v_version.custom_variables,
    v_restore_note, v_actor_profile_id, v_updated_at
  );

  -- Aplica a versao como o novo estado vivo (NUNCA muda status)
  UPDATE public.talkx_templates template
  SET name = v_version.name,
      description = v_version.description,
      category = v_version.category,
      content = v_version.content,
      media_url = v_version.media_url,
      media_type = v_version.media_type,
      tags = v_version.tags,
      custom_variables = v_version.custom_variables,
      updated_at = v_updated_at
  WHERE template.id = p_template_id
  RETURNING template.updated_at INTO v_updated_at;

  -- Mantem apenas as 50 versoes mais recentes
  DELETE FROM public.talkx_template_versions hist
  WHERE hist.template_id = p_template_id
    AND hist.id NOT IN (
      SELECT id
      FROM public.talkx_template_versions recent
      WHERE recent.template_id = p_template_id
      ORDER BY recent.version_number DESC
      LIMIT 50
    );

  RETURN QUERY SELECT p_template_id, v_updated_at, v_version_number;
END;
$function$;

REVOKE ALL ON FUNCTION public.restore_talkx_template_version(
  uuid, uuid, timestamptz
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.restore_talkx_template_version(
  uuid, uuid, timestamptz
) TO authenticated;

-- list_talkx_template_versions: devolve versoes ordenadas, com limite e cursor.
CREATE OR REPLACE FUNCTION public.list_talkx_template_versions(
  p_template_id uuid,
  p_limit integer DEFAULT 20,
  p_before timestamptz DEFAULT NULL
) RETURNS TABLE(
  version_number integer,
  created_at timestamptz,
  note text,
  saved_by_name text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
BEGIN
  IF COALESCE(auth.role(), '') <> 'authenticated' OR auth.uid() IS NULL THEN
    RAISE EXCEPTION 'authentication_required' USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    hist.version_number,
    hist.created_at,
    hist.note,
    prof.email AS saved_by_name
  FROM public.talkx_template_versions hist
  LEFT JOIN public.profiles prof ON prof.id = hist.saved_by
  WHERE hist.template_id = p_template_id
    AND (p_before IS NULL OR hist.created_at < p_before)
  ORDER BY hist.version_number DESC
  LIMIT GREATEST(p_limit, 1);
END;
$function$;

REVOKE ALL ON FUNCTION public.list_talkx_template_versions(
  uuid, integer, timestamptz
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.list_talkx_template_versions(
  uuid, integer, timestamptz
) TO authenticated;

-- update_talkx_template_with_snapshot continua existindo como invocacao
-- da nova save_talkx_template (mesma assinatura, sem drop).
CREATE OR REPLACE FUNCTION public.update_talkx_template_with_snapshot(
  p_template_id uuid,
  p_expected_updated_at timestamptz,
  p_name text,
  p_description text,
  p_category text,
  p_content text,
  p_media_url text,
  p_media_type text,
  p_tags text[],
  p_status text,
  p_custom_variables text[]
) RETURNS TABLE(template_id uuid, updated_at timestamptz, version_number integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $function$
DECLARE
  v_result record;
BEGIN
  -- Converte parametros individuais em jsonb e chama save_talkx_template.
  -- O status do payload e ignorado (save_talkx_template nunca altera status).
  SELECT * INTO v_result
  FROM public.save_talkx_template(
    p_template_id,
    p_expected_updated_at,
    jsonb_build_object(
      'name', p_name,
      'description', p_description,
      'category', p_category,
      'content', p_content,
      'media_url', p_media_url,
      'media_type', p_media_type,
      'tags', p_tags,
      'custom_variables', p_custom_variables
    ),
    NULL
  );
  RETURN QUERY SELECT v_result.template_id, v_result.updated_at, v_result.version_number;
END;
$function$;

REVOKE ALL ON FUNCTION public.update_talkx_template_with_snapshot(
  uuid, timestamptz, text, text, text, text, text, text, text[], text, text[]
) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.update_talkx_template_with_snapshot(
  uuid, timestamptz, text, text, text, text, text, text, text[], text, text[]
) TO authenticated;