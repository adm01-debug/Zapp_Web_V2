#!/usr/bin/env node
// Guarda de drift da documentação do Talk X (X197 · V96).
//
// O X197 manda "acrescentar ao CI um verificador que falha se um documento de
// `docs/talkx/` citar arquivo de código que não existe" — a documentação do módulo
// nasceu misturada com história e plano e chegou a apontar para componentes que
// nunca existiram (auditoria de 29/09: `TalkXSegmentBuilder.tsx`,
// `TalkXCampaignPaused.tsx`, `TalkXCampaignReport.tsx`) e para arquivos apagados
// (`src/lib/talkxExport.ts`). Quem abrir a doc para operar o módulo é mandado para
// um caminho que não existe.
//
// Escopo desta guarda = as páginas de ESTADO ATUAL do módulo, que afirmam onde as
// coisas estão hoje: `README.md`, `ARQUITETURA.md` e `OPERACAO.md`.
// Fora do escopo, com motivo declarado:
//   · `CHANGELOG_TALKX.md` — é um log datado; registra o estado de cada data (o
//     arquivo pode ter sido renomeado depois) e não afirma o presente.
//   · `PARIDADE.md` — abre com "SUBSTITUÍDO pelo V4 / DESATUALIZADO" e é regenerado
//     a partir do placar por outra parte do X197 (depende de X002/X196).
//   · `PLANO_*`, `HANDOFF_*`, `AUDITORIA_*` e `v4/` — plano e história: citam de
//     propósito arquivos que ainda serão criados.
//
// Regra: uma referência a arquivo de código (`*.ts/tsx/mjs/js/sql/sh`, com crase) nas
// páginas cobertas tem de resolver para um arquivo real — SALVO quando a própria linha
// declara a ausência (apagado/removido/não existe/substituído). Documentar que um
// arquivo não existe é legítimo; afirmar que ele existe não é.
//
// Os dois lados da regra são provados por fixtures em string; o teste lê os três
// documentos REAIS e era RED antes da correção (OPERACAO.md mandava editar
// `talkxShared.tsx`, que não existe; ARQUITETURA.md apontava três componentes
// fantasmas nas telas 03, 13 e 14), ficando GREEN com ela.

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

/** Páginas de estado atual do módulo, cobertas pela guarda. */
export const DOCS_COBERTOS = [
  'docs/talkx/README.md',
  'docs/talkx/ARQUITETURA.md',
  'docs/talkx/OPERACAO.md',
];

/** Extensões que caracterizam referência a arquivo de CÓDIGO. */
const EXTENSOES = /\.(?:tsx?|mjs|js|sql|sh)$/;

// A própria linha marca o arquivo como ausente/renomeado/apagado: é documentar a
// ausência, não afirmar a presença.
const DECLARA_AUSENCIA =
  /(n[ãa]o existem?|n[ãa]o existe|apagad[oa]s?|removid[oa]s?|deletad[oa]s?|extint[oa]s?|substitu[íi]d[oa]s?|renomead[oa]s?|nunca existiu|deixou de existir)/i;

// Índice de basenames do repositório: parte das citações vem só pelo nome
// (`talkxShared.ts`), sem caminho.
function indexarBasenames() {
  const nomes = new Set();
  const raizes = ['src', 'supabase', 'scripts', 'docs', 'e2e', 'tests', 'qa', '.github', 'infrastructure'];
  const pilha = raizes.map((r) => path.join(RAIZ, r)).filter((p) => fs.existsSync(p));
  while (pilha.length > 0) {
    const atual = pilha.pop();
    for (const entrada of fs.readdirSync(atual, { withFileTypes: true })) {
      if (entrada.isDirectory()) {
        if (!['node_modules', '.git', 'dist', 'coverage'].includes(entrada.name)) {
          pilha.push(path.join(atual, entrada.name));
        }
      } else {
        nomes.add(entrada.name);
      }
    }
  }
  return nomes;
}

export function basenames() {
  return indexarBasenames();
}

/**
 * Referências a arquivo de código em um markdown que NÃO resolvem para arquivo real
 * e não estão declaradas como ausentes no próprio bloco. Lista vazia = a página só
 * aponta para o que existe.
 *
 * O bloco de contexto para a declaração de ausência é o parágrafo: uma citação
 * (`>`), que quebra em várias linhas, vale pelo conjunto — o aviso "não existem" do
 * banner do ARQUITETURA.md cai na linha seguinte à lista de arquivos. Linhas de
 * tabela são avaliadas UMA A UMA: célula que diz "apagado" não pode escusar as
 * outras linhas da mesma tabela.
 */
export function referenciasQuebradas(markdown, indice = indexarBasenames()) {
  const quebradas = [];
  const linhas = String(markdown).split('\n');

  // Contexto de ausência por linha: o bloco de citação contíguo, ou a própria linha.
  const contextos = linhas.map(() => null);
  for (let i = 0; i < linhas.length; i += 1) {
    if (!/^\s*>/.test(linhas[i])) {
      contextos[i] = linhas[i];
      continue;
    }
    let fim = i;
    while (fim + 1 < linhas.length && /^\s*>/.test(linhas[fim + 1])) fim += 1;
    const bloco = linhas.slice(i, fim + 1).join(' ');
    for (let j = i; j <= fim; j += 1) contextos[j] = bloco;
    i = fim;
  }

  for (const [i, linha] of linhas.entries()) {
    const tokens = [...linha.matchAll(/`([^`]+)`/g)].map((m) => m[1]);
    for (const token of tokens) {
      if (!/^[\w./-]+$/.test(token) || !EXTENSOES.test(token)) continue;
      if (DECLARA_AUSENCIA.test(contextos[i])) continue;
      const existe = token.includes('/')
        ? fs.existsSync(path.join(RAIZ, token)) || fs.existsSync(path.join(RAIZ, 'docs/talkx', token))
        : indice.has(token);
      if (!existe) quebradas.push({ linha: i + 1, token });
    }
  }
  return quebradas;
}

const INDICE = indexarBasenames();

test('as páginas de estado atual do módulo não citam arquivo de código inexistente', () => {
  let referencias = 0;
  const problemas = [];
  for (const doc of DOCS_COBERTOS) {
    const md = fs.readFileSync(path.join(RAIZ, doc), 'utf8');
    referencias += [...md.matchAll(/`[\w./-]+\.(?:tsx?|mjs|js|sql|sh)`/g)].length;
    for (const q of referenciasQuebradas(md, INDICE)) {
      problemas.push(`${doc}:${q.linha} cita \`${q.token}\`, que não existe`);
    }
  }
  assert.ok(referencias > 0, 'nenhuma referência de arquivo encontrada — o teste perdeu o alvo');
  assert.deepEqual(problemas, [], problemas.join('\n'));
});

test('a regra acusa referência a arquivo apagado e poupa referência existente', () => {
  // Negativo: `src/lib/talkxExport.ts` foi apagado (auditoria de 29/09, E29) e a
  // linha o apresenta como existente → tem de acusar.
  const comFantasma = [
    '| E29 | Botão exportar CSV | ✅ | `src/lib/talkxExport.ts` — `exportCampaignsCsv` |',
  ].join('\n');
  assert.deepEqual(referenciasQuebradas(comFantasma, INDICE), [{ linha: 1, token: 'src/lib/talkxExport.ts' }]);

  // Positivo: arquivo real (caminho e basename) não acusa.
  const comReal = '1. Adicionar o valor a `TEMPLATE_CATEGORIES` em `src/components/talkx/talkxShared.ts`.\n2. Ver `talkxShared.ts`.';
  assert.deepEqual(referenciasQuebradas(comReal, INDICE), []);

  // A mesma referência fantasma, declarada como apagada no bloco de citação, é
  // documentação legítima.
  const declarandoAusencia =
    '> E29 (`src/lib/talkxExport.ts` apagado) e os três componentes citados\n> abaixo **não existem**.';
  assert.deepEqual(referenciasQuebradas(declarandoAusencia, INDICE), []);

  // A ausência declarada numa CÉLULA de tabela não escusa as outras linhas da mesma
  // tabela: só o bloco de citação carrega a declaração para as linhas vizinhas.
  const tabelaMista = [
    '| Arquivo | Estado |',
    '| `src/lib/talkxExport.ts` | apagado |',
    '| `TalkXCampaignReport.tsx` | componente do relatório |',
  ].join('\n');
  assert.deepEqual(referenciasQuebradas(tabelaMista, INDICE), [
    { linha: 3, token: 'TalkXCampaignReport.tsx' },
  ]);
});

test('ARQUITETURA.md aponta os componentes reais nas telas 03, 13 e 14', () => {
  const md = fs.readFileSync(path.join(RAIZ, 'docs/talkx/ARQUITETURA.md'), 'utf8');

  // Âncora no código: é o roteamento por status do TalkXView (E72) que define quem
  // abre cada tela.
  const view = fs.readFileSync(path.join(RAIZ, 'src/components/talkx/TalkXView.tsx'), 'utf8');
  assert.match(view, /c\.status === 'sending' \|\| c\.status === 'paused'/, 'roteamento de `sending`/`paused` mudou');
  assert.match(view, /openRunning\(c\)/, 'roteamento por status não abre mais o TalkXCampaignRunning');
  assert.match(view, /openMonitor\(c\)/, 'roteamento por status não abre mais o Monitor');

  const linhas = md.split('\n').filter((l) => l.startsWith('|'));
  const linhasDe = (tela) => linhas.filter((l) => new RegExp(`^\\|\\s*${tela}\\s`).test(l));
  assert.match(linhasDe('03')[0] ?? '', /`TalkXSegments\.tsx`/, 'tela 03 (Segmentos criar) não aponta o construtor inline');
  assert.match(linhasDe('13')[0] ?? '', /`TalkXCampaignRunning\.tsx`/, 'tela 13 (Pausada/retomada) não aponta o TalkXCampaignRunning');
  assert.match(linhasDe('14')[0] ?? '', /`TalkXLiveMonitor\.tsx`/, 'tela 14 (Relatório concluída) não aponta o Monitor');

  // Os três arquivos que nunca existiram só podem aparecer na nota de correção
  // (bloco de citação) que os declara ausentes — nunca numa linha de tabela.
  for (const fantasma of ['TalkXSegmentBuilder.tsx', 'TalkXCampaignPaused.tsx', 'TalkXCampaignReport.tsx']) {
    const emTabela = linhas.filter((l) => l.includes(`\`${fantasma}\``));
    assert.deepEqual(emTabela, [], `a tabela de telas voltou a citar \`${fantasma}\``);
    assert.match(md, new RegExp(`\`${fantasma.replace('.', '\\.')}\``), `a nota de correção perdeu \`${fantasma}\``);
  }
});
