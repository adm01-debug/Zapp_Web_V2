/**
 * Y17-2 — A11Y-CATALOGO_FILAS_SLA-01 (War Room e alertas de sentimento) —
 * botões só de ícone sem nome acessível.
 *
 * A auditoria de 07/10/2026 mediu (axe, `button-name`): os 3 botões de ícone do
 * cabeçalho do `WarRoomDashboard` estão dentro de `<Tooltip>`, mas o
 * `TooltipContent` NÃO é nome acessível — só aparece no hover; e o botão de
 * recarregar do `SentimentAlertsDashboard` é um `RefreshCw` sem texto.
 *
 * O `WarRoomDashboard` e o `SentimentAlertsDashboard` REAIS são renderizados
 * (só os hooks de dados/fonte são mockados) e o nome é cobrado pelo
 * `getByRole('button', { name })` — sem o `aria-label` o seletor não acha.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, cleanup } from '@testing-library/react';
import { axe } from 'vitest-axe';
import { TooltipProvider } from '@/components/ui/tooltip';

vi.mock('@/hooks/business/useWarRoomData', () => ({
  useWarRoomData: () => ({ agents: [], queues: [] }),
  useWarRoomMetrics: () => ({
    totalWaiting: 2, totalBreaches: 0, totalWarnings: 1,
    onlineAgents: 1, totalResolved: 5, avgSatisfaction: 4.5,
  }),
}));
vi.mock('@/hooks/business/useWarRoomAlerts', () => ({
  useWarRoomAlerts: () => ({ alerts: [], dismissAlert: vi.fn() }),
}));
vi.mock('@/hooks/system/useNotificationSettings', () => ({
  useNotificationSettings: () => ({ settings: { soundEnabled: true }, updateSettings: vi.fn() }),
}));
vi.mock('@/components/inbox/AgentReassignmentPanel', () => ({ AgentReassignmentPanel: () => null }));

vi.mock('@/components/dashboard/useSentimentData', async () => {
  const actual = await vi.importActual<typeof import('@/components/dashboard/useSentimentData')>(
    '@/components/dashboard/useSentimentData'
  );
  return {
    ...actual,
    useSentimentData: () => ({
      alerts: [], analyses: [], agents: [], loading: false, dailyData: [], agentData: [],
      stats: {
        totalAnalyses: 0, negativeAnalyses: 0, positiveAnalyses: 0, neutralAnalyses: 0,
        avgSentiment: null, totalAlerts: 0, criticalAlerts: 0, emailsSent: 0,
        uniqueContacts: 0, negativeRate: 0,
      },
      fetchData: vi.fn(),
    }),
  };
});

import { WarRoomDashboard } from '../WarRoomDashboard';
import { SentimentAlertsDashboard } from '../SentimentAlertsDashboard';

/** Só a regra do achado 01 — nada de regra de página. */
const axeBotaoSemNome = (target: Element) =>
  axe(target, { runOnly: { type: 'rule', values: ['button-name'] } });

beforeEach(() => cleanup());

describe('Y17-2 — botões só de ícone recebem nome acessível', () => {
  it('WarRoomDashboard: os 3 botões do cabeçalho têm o nome do tooltip e nenhum fica sem nome', async () => {
    const { container } = render(
      <TooltipProvider>
        <WarRoomDashboard />
      </TooltipProvider>
    );

    expect(screen.getByRole('button', { name: 'Som de alertas' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Auto-atualização' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Tela cheia' })).toBeInTheDocument();
    expect((await axeBotaoSemNome(container)).violations).toEqual([]);
  });

  it('SentimentAlertsDashboard: o botão de atualizar tem nome', async () => {
    const { container } = render(<SentimentAlertsDashboard />);

    expect(screen.getByRole('button', { name: 'Atualizar alertas de sentimento' })).toBeInTheDocument();

    // A varredura segue no contêiner inteiro, sem desabilitar regra. Dos nós sem
    // nome, o único que sobra é PRÉ-EXISTENTE e fora do escopo deste cartão: o
    // gatilho do `Select` de período (radix `combobox`, sem valor escolhido)
    // do próprio componente — mesmo padrão do achado 01 na tela de Catálogo.
    // Não é o botão só de ícone deste cartão e o conserto é de outro item.
    // Fica à vista: quando for corrigido, o teste acusa.
    const semNome = (await axeBotaoSemNome(container)).violations.flatMap(v => v.nodes);
    expect(semNome.filter(n => !n.html.includes('role="combobox"'))).toEqual([]);
  });
});
