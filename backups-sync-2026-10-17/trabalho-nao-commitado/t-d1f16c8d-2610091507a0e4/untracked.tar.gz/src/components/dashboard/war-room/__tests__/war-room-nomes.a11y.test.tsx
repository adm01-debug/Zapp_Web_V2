/**
 * Y17-2 — A11Y-CATALOGO_FILAS_SLA-02 (War Room) — barras sem nome, e
 * A11Y-CATALOGO_FILAS_SLA-01 (War Room) — botão de dispensar só de ícone.
 *
 * A auditoria de 07/10/2026 mediu em `/?view=warroom`: (a) as barras
 * `role="progressbar"` de `WarRoomAgentCard` e `WarRoomQueueRow` sem
 * `aria-progressbar-name`; (b) o botão de dispensar alerta de
 * `WarRoomAlertRow` sem nome (`button-name`). O teste renderiza os três
 * componentes REAIS e cobra o nome acessível.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { axe } from 'vitest-axe';
import type { WarRoomAgent, WarRoomAlert, WarRoomQueue } from '@/hooks/business/useWarRoomData';
import { WarRoomAgentCard } from '../WarRoomAgentCard';
import { WarRoomQueueRow } from '../WarRoomQueueRow';
import { WarRoomAlertRow } from '../WarRoomAlertRow';

const agente: WarRoomAgent = {
  id: 'a1', name: 'Ana Souza', status: 'online',
  activeChats: 3, maxChats: 5, avgResponseTime: 12, resolvedToday: 7, satisfaction: 4.5,
};

const fila: WarRoomQueue = {
  id: 'q1', name: 'Comercial', color: '#8b5cf6',
  waiting: 4, avgWaitTime: 2.5, slaBreaches: 0, slaWarnings: 1, inProgress: 6,
};

const alerta: WarRoomAlert = {
  id: 'x1', type: 'critical', title: 'SLA violado', message: 'Fila Comercial acima do prazo',
  timestamp: new Date('2026-10-09T12:00:00-03:00'), isNew: true,
};

/** Só as regras dos achados deste cartão — nada de regra de página. */
const axeDosAchados = (target: Element) =>
  axe(target, { runOnly: { type: 'rule', values: ['aria-progressbar-name', 'button-name'] } });

describe('Y17-2 — War Room: barras e botão de dispensar com nome acessível', () => {
  it('WarRoomAgentCard: a barra anuncia de quem é a utilização', async () => {
    const { container } = render(<WarRoomAgentCard agent={agente} onClick={vi.fn()} />);

    expect(
      screen.getByRole('progressbar', { name: 'Utilização de atendimentos de Ana Souza' })
    ).toBeInTheDocument();
    expect((await axeDosAchados(container)).violations).toEqual([]);
  });

  it('WarRoomQueueRow: a barra anuncia de qual fila é a utilização', async () => {
    const { container } = render(<WarRoomQueueRow queue={fila} onClick={vi.fn()} />);

    expect(screen.getByRole('progressbar', { name: 'Utilização da fila Comercial' })).toBeInTheDocument();
    expect((await axeDosAchados(container)).violations).toEqual([]);
  });

  it('WarRoomAlertRow: o botão de dispensar tem nome e continua disparando o handler', async () => {
    const onDismiss = vi.fn();
    const { container } = render(<WarRoomAlertRow alert={alerta} onDismiss={onDismiss} />);

    const botao = screen.getByRole('button', { name: 'Dispensar alerta' });
    fireEvent.click(botao);
    expect(onDismiss).toHaveBeenCalledTimes(1);
    expect((await axeDosAchados(container)).violations).toEqual([]);
  });
});
