/**
 * Y17-2 — A11Y-CATALOGO_FILAS_SLA-02 (SLA) — barras de progresso sem nome.
 *
 * A auditoria de 07/10/2026 mediu no Chromium real (axe) o achado 02 em `/sla`:
 * cada `<div role="progressbar">` do `Progress` do Radix fica sem
 * `aria-label`/`aria-labelledby` (`aria-progressbar-name`, impacto `serious`).
 * Eram 3 sítios no grupo de SLA: `SLAMetricCards` (taxa geral),
 * `SLAAgentTable` (uma barra por agente) e `SLADashboard` (primeira resposta).
 *
 * O teste renderiza os componentes REAIS e cobra o nome acessível pelo
 * `getByRole('progressbar', { name })` — antes da correção o seletor não acha
 * nada (nome vazio) e o `axe` acusa `aria-progressbar-name`; depois, verde.
 * Os dados vêm do hook mockado (a barra é do componente, não do hook).
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, cleanup } from '@testing-library/react';
import { axe } from 'vitest-axe';
import { MemoryRouter } from 'react-router-dom';
import { Progress } from '@/components/ui/progress';
import type { SLADashboardData } from '@/hooks/sla/useSLAMetrics';

vi.mock('@/hooks/sla/useSLAMetrics', () => ({ useSLAMetrics: vi.fn() }));
vi.mock('@/hooks/sla/useSLAHistory', () => ({
  useSLAHistory: () => ({ data: null, loading: false }),
}));
// Os managers de configuração abrem na aba "global" (default do Tabs) e falam
// com o banco; não são o alvo aqui — só o corpo de métricas é.
vi.mock('@/components/settings/SLAConfigurationManager', () => ({
  SLAConfigurationManager: () => null,
}));
vi.mock('@/components/settings/SLARulesManager', () => ({ SLARulesManager: () => null }));

import { useSLAMetrics } from '@/hooks/sla/useSLAMetrics';
import { SLAMetricCards } from '../SLAMetricCards';
import { SLAAgentTable } from '../SLAAgentTable';
import { SLADashboard } from '../SLADashboard';

const metric = (rate: number) => ({ total: 10, onTime: 9, breached: 1, pending: 0, rate });

const DADOS: SLADashboardData = {
  overall: { firstResponse: metric(90), totalConversations: 20, hasSample: true, overallRate: 90 },
  byAgent: [
    { agentId: 'a1', agentName: 'Ana Souza', firstResponse: metric(80), overallRate: 80 },
    { agentId: 'a2', agentName: 'Bruno Lima', firstResponse: metric(100), overallRate: 100 },
  ],
};

/** Só a regra do achado 02 — o resto da página não é escopo deste cartão. */
const axeSemNomeNaBarra = (target: Element) =>
  axe(target, { runOnly: { type: 'rule', values: ['aria-progressbar-name'] } });

beforeEach(() => {
  cleanup();
  vi.mocked(useSLAMetrics)
    .mockReset()
    .mockReturnValue({ data: DADOS, loading: false } as ReturnType<typeof useSLAMetrics>);
});

describe('Y17-2 — barras de progresso do SLA têm nome acessível', () => {
  it('SLAMetricCards: a barra da taxa geral anuncia o que mede', async () => {
    const { container } = render(
      <SLAMetricCards data={DADOS.overall} periodLabel="Hoje" sparkOverall={[]} sparkFR={[]} sparkConversations={[]} />
    );

    expect(screen.getByRole('progressbar', { name: 'Taxa de SLA geral' })).toBeInTheDocument();
    expect((await axeSemNomeNaBarra(container)).violations).toEqual([]);
  });

  it('SLAAgentTable: uma barra nomeada por agente', async () => {
    const { container } = render(<SLAAgentTable agents={DADOS.byAgent} />);

    expect(screen.getByRole('progressbar', { name: 'Cumprimento do SLA de Ana Souza' })).toBeInTheDocument();
    expect(screen.getByRole('progressbar', { name: 'Cumprimento do SLA de Bruno Lima' })).toBeInTheDocument();
    expect(screen.getAllByRole('progressbar')).toHaveLength(2);
    expect((await axeSemNomeNaBarra(container)).violations).toEqual([]);
  });

  it('SLADashboard: a barra de primeira resposta anuncia o que mede (e nenhuma fica sem nome)', async () => {
    const { container } = render(
      <MemoryRouter>
        <SLADashboard />
      </MemoryRouter>
    );

    expect(screen.getByRole('progressbar', { name: 'Cumprimento do SLA de primeira resposta' })).toBeInTheDocument();
    const barras = screen.getAllByRole('progressbar');
    expect(barras.length).toBeGreaterThan(0);
    for (const barra of barras) expect(barra).toHaveAccessibleName();
    expect((await axeSemNomeNaBarra(container)).violations).toEqual([]);
  });
});

/**
 * Controle vermelho-antes: uma barra sem `aria-label` é exatamente o defeito
 * medido pela auditoria. Sem ele, os testes acima passariam por acidente (um
 * `getByRole` que não cobra o nome) — este caso prova que o seletor e a regra
 * do axe pegam o defeito.
 */
describe('Y17-2 — controle: a barra sem nome é pega', () => {
  it('um Progress sem aria-label não tem nome e viola aria-progressbar-name', async () => {
    const { container } = render(<Progress value={50} />);

    expect(screen.getByRole('progressbar')).not.toHaveAccessibleName();
    expect((await axeSemNomeNaBarra(container)).violations.map(v => v.id)).toContain('aria-progressbar-name');
    expect(() => screen.getByRole('progressbar', { name: 'Taxa de SLA geral' })).toThrow();
  });
});
