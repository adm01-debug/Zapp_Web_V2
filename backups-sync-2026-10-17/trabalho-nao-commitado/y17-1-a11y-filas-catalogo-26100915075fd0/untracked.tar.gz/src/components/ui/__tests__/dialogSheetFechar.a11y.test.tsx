/**
 * Y17-1 — botão de fechar dos diálogos/painéis anunciava "Close" (inglês) num
 * app todo em pt-BR (auditoria de 07/10, achado A11Y-CATALOGO_FILAS_SLA-14,
 * medido em "Nova Fila" e "Metas e Alertas"). O defeito é do componente GLOBAL
 * (`src/components/ui/dialog.tsx` e `src/components/ui/sheet.tsx`).
 *
 * A prova monta o `DialogContent`/`SheetContent` REAIS e consulta o nome
 * acessível que o leitor de tela anuncia. Antes da correção ambos os
 * `getByRole('button', { name: 'Fechar' })` falham (o nome era "Close").
 */
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet';

describe('Y17-1 — botão de fechar em pt-BR (achado 14)', () => {
  it('DialogContent: o X de fechar tem nome acessível "Fechar"', () => {
    render(
      <Dialog open>
        <DialogContent>
          <DialogTitle>Nova Fila</DialogTitle>
        </DialogContent>
      </Dialog>,
    );

    expect(screen.getByRole('button', { name: 'Fechar' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Close' })).toBeNull();
  });

  it('SheetContent: o X de fechar tem nome acessível "Fechar"', () => {
    render(
      <Sheet open>
        <SheetContent>
          <SheetTitle>Detalhes do produto</SheetTitle>
        </SheetContent>
      </Sheet>,
    );

    expect(screen.getByRole('button', { name: 'Fechar' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Close' })).toBeNull();
  });
});
