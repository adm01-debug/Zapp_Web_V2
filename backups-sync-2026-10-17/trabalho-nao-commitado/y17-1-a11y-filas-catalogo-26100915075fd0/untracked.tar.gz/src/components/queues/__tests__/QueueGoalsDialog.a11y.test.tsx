/**
 * Y17-1 (A11Y-CATALOGO_FILAS_SLA-09) — os campos do diálogo "Metas e Alertas"
 * não tinham rótulo programático: os `<Label>` do `QueueGoalsDialog` não tinham
 * `htmlFor`/`id` e os 4 `Slider` (role="slider") não tinham nome
 * (`axe: label [critical]` + `aria-input-field-name [serious]`, medidos em
 * `/?view=queues` → card → "Metas e Alertas").
 *
 * A prova monta o diálogo REAL (só o `useQueueGoals`, que fala com o banco, é
 * substituído por um stub) e consulta cada campo pelo NOME acessível do rótulo
 * visível. Antes da correção nenhum dos `getByRole(..., { name })` acha o campo.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';

vi.mock('@/hooks/business/useQueueGoals', () => ({
  useQueueGoals: () => ({
    goals: {},
    saveGoal: vi.fn().mockResolvedValue(true),
    getDefaultGoal: () => ({
      max_waiting_contacts: 10,
      max_avg_wait_minutes: 15,
      min_assignment_rate: 80,
      max_messages_pending: 50,
      alerts_enabled: true,
    }),
  }),
}));

import { QueueGoalsDialog } from '@/components/queues/QueueGoalsDialog';

/** Cada campo do diálogo: rótulo visível = nome acessível, e o valor padrão. */
const CAMPOS = [
  { rotulo: 'Máximo de Contatos Aguardando', valor: 10 },
  { rotulo: 'Tempo Máximo de Espera (minutos)', valor: 15 },
  { rotulo: 'Taxa Mínima de Atribuição (%)', valor: 80 },
  { rotulo: 'Máximo de Mensagens Pendentes', valor: 50 },
];

function renderDialog() {
  return render(
    <QueueGoalsDialog
      open
      onOpenChange={vi.fn()}
      queueId="q1"
      queueName="Suporte"
      queueColor="#3B82F6"
    />,
  );
}

describe('Y17-1 — rótulo programático nos campos de "Metas e Alertas" (achado 09)', () => {
  it('cada campo de número é anunciado pelo rótulo visível (Label htmlFor + id)', () => {
    renderDialog();
    for (const { rotulo, valor } of CAMPOS) {
      const campo = screen.getByRole('spinbutton', { name: rotulo });
      expect(campo).toBeInTheDocument();
      expect(campo).toHaveValue(valor);
    }
  });

  it('cada Slider tem nome acessível no thumb (role="slider")', () => {
    renderDialog();
    const sliders = screen.getAllByRole('slider');
    expect(sliders).toHaveLength(CAMPOS.length);
    for (const { rotulo } of CAMPOS) {
      expect(screen.getByRole('slider', { name: rotulo })).toBeInTheDocument();
    }
  });

  it('o interruptor de alertas também tem nome acessível', () => {
    renderDialog();
    expect(screen.getByRole('switch', { name: 'Alertas Ativados' })).toBeInTheDocument();
  });

  it('o axe não acusa mais campo sem rótulo/nome no diálogo', async () => {
    renderDialog();
    const results = await axe(document.body);
    const ids = results.violations.map((v) => v.id);
    expect(ids.filter((id) => id === 'label' || id === 'aria-input-field-name')).toEqual([]);
    expect({
      ...results,
      violations: results.violations.filter((v) => v.impact === 'critical' || v.impact === 'serious'),
    }).toHaveNoViolations();
  });
});
