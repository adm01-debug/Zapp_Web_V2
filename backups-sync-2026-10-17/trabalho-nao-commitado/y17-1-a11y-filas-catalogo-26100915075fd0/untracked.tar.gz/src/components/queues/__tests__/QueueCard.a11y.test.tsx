/**
 * Y17-1 (A11Y-CATALOGO_FILAS_SLA-01) — botões só de ícone do card da fila sem
 * nome acessível. A auditoria (`docs/audits/AUDITORIA_A11Y_MOBILE_CATALOGO_FILAS_SLA_2026-10-07.md`,
 * achado 01; `axe: button-name [critical]`) mediu no Chromium real o `+`
 * (`QueueCard.tsx:85`) sem `aria-label`; o `X` de remover atendente
 * (`QueueCard.tsx:76`) é o MESMO defeito no mesmo arquivo (só não foi medido
 * porque aparece com `opacity-0` até o hover/foco).
 *
 * A prova usa o `QueueCard` REAL (com o `useNavigate` real, sob `MemoryRouter`)
 * e consulta pelo NOME acessível — exatamente o que o leitor de tela anuncia.
 * Antes da correção os dois `getByRole(..., { name })` não acham nada.
 */
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe } from 'vitest-axe';
import { MemoryRouter } from 'react-router-dom';
import { QueueCard } from '@/components/queues/QueueCard';
import type { QueueWithMembers } from '@/hooks/business/useQueues';

// Mesmos polyfills dos testes de fila vizinhos (Radix mede o trigger do menu).
if (!Element.prototype.scrollIntoView) Element.prototype.scrollIntoView = () => {};
if (!Element.prototype.hasPointerCapture) Element.prototype.hasPointerCapture = () => false;
if (!Element.prototype.releasePointerCapture) Element.prototype.releasePointerCapture = () => {};

const queue = {
  id: 'q1',
  name: 'Suporte',
  description: 'Atendimento geral',
  color: '#3B82F6',
  is_active: true,
  max_wait_time_minutes: 30,
  priority: 1,
  created_at: '',
  updated_at: '',
  waiting_count: 3,
  members: [
    {
      id: 'm1',
      queue_id: 'q1',
      profile_id: 'p1',
      is_active: true,
      created_at: '',
      profile: { id: 'p1', name: 'Ana', avatar_url: null, is_active: true },
    },
  ],
} as unknown as QueueWithMembers;

function renderCard() {
  return render(
    <MemoryRouter>
      <QueueCard
        queue={queue}
        alertCount={0}
        onAddMember={vi.fn()}
        onRemoveMember={vi.fn()}
        onSetGoals={vi.fn()}
        onEdit={vi.fn()}
        onDelete={vi.fn()}
      />
    </MemoryRouter>,
  );
}

describe('Y17-1 — nome acessível nos botões só de ícone do card da fila (achado 01)', () => {
  it('o botão "+" diz o que faz e em qual fila', () => {
    renderCard();
    expect(screen.getByRole('button', { name: 'Adicionar atendente à fila Suporte' })).toBeInTheDocument();
  });

  it('o botão de remover atendente diz quem sai e de qual fila', () => {
    renderCard();
    expect(screen.getByRole('button', { name: 'Remover Ana da fila Suporte' })).toBeInTheDocument();
  });

  it('o card da fila não tem violação séria de axe (button-name zerado)', async () => {
    const { container } = renderCard();
    const results = await axe(container);
    expect(results.violations.filter((v) => v.id === 'button-name')).toEqual([]);
    expect(results).toHaveNoViolations();
  });
});
