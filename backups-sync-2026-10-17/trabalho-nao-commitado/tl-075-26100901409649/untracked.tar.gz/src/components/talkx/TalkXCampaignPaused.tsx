// TalkXCampaignPaused.tsx — X156: Tela 13 "Campanha Pausada" (mock 13).
//
// A campanha pausada deixa de ser mostrada como "Campanha em Andamento":
// esta tela diz QUEM pausou (ator do último evento `paused`), POR QUÊ (motivo
// digitado ou a pausa do próprio sistema) e QUANDO (`paused_at`), e oferece as
// duas saídas — Retomar campanha e Encerrar campanha.
//
// Ator e motivo vêm do último evento gravado pelo servidor
// (`talkx_campaign_events`), nunca do navegador. `pause_reason` classifica a
// pausa: os motivos que o motor grava (`send_window`, `business_hours`,
// `connection_lost`, `daily_limit` — ver `talkx-resume-policy`) são pausas
// automáticas, em que não há pessoa responsável a exibir.
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, ArrowLeft, Clock, Pause, Play, Square, Zap } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { useTalkX, type TalkXCampaign } from '@/hooks/integrations/useTalkX';
import { useTalkXEvents } from '@/hooks/integrations/useTalkXEvents';
import { useUserRole } from '@/hooks/system/useUserRole';
import { IconTile, MetaRow, RailCard, TalkXEmptyState, TalkXQueryBoundary, TalkXSkeletonRows, fmtDateTime, fmtInt } from './talkxShared';

/** Motivos de pausa gravados pelo motor: a campanha volta sozinha. */
const AUTO_PAUSE_LABEL: Record<string, string> = {
  send_window: 'fora do horário de envio',
  business_hours: 'fora do horário comercial',
  connection_lost: 'conexão do WhatsApp caiu',
  daily_limit: 'limite diário atingido',
};

/** Como uma pausa automática termina — sem prometer hora que o motor não deu. */
const AUTO_PAUSE_HINT: Record<string, string> = {
  send_window: 'A campanha volta sozinha quando a janela de envio reabrir.',
  business_hours: 'A campanha volta sozinha na próxima janela de horário comercial.',
  connection_lost: 'A campanha volta sozinha quando a conexão do WhatsApp for restabelecida.',
  daily_limit: 'A campanha volta sozinha quando a cota diária da linha liberar.',
};

const DEFAULT_TIMEZONE = 'America/Sao_Paulo';

/** Minutos desde a meia-noite no fuso da campanha (mesma leitura do servidor). */
function minutesInTimezone(timeZone: string, now: Date): number | null {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).formatToParts(now);
    const hour = Number(parts.find((part) => part.type === 'hour')?.value);
    const minute = Number(parts.find((part) => part.type === 'minute')?.value);
    return Number.isInteger(hour) && Number.isInteger(minute) ? hour * 60 + minute : null;
  } catch {
    return null;
  }
}

/**
 * Espelha SÓ a checagem de janela de envio do servidor (`talkx-window.ts`) para
 * avisar em português antes de retomar. A recusa crua do servidor é
 * `outside_send_window`; o operador lia o código, não a explicação.
 * Devolve `null` quando não há impedimento para avisar.
 */
function talkxSendWindowNotice(campaign: TalkXCampaign, now = new Date()): string | null {
  const start = campaign.send_window_start?.slice(0, 5);
  const end = campaign.send_window_end?.slice(0, 5);
  if (!start || !end) return null;

  const [startHour, startMinute] = start.split(':').map(Number);
  const [endHour, endMinute] = end.split(':').map(Number);
  if (![startHour, startMinute, endHour, endMinute].every(Number.isInteger)) return null;

  const minutes = minutesInTimezone(campaign.schedule_timezone || DEFAULT_TIMEZONE, now);
  if (minutes === null) return null;

  const insideWindow = minutes >= startHour * 60 + startMinute && minutes < endHour * 60 + endMinute;
  return insideWindow ? null : `Fora do horário de envio — a campanha volta sozinha às ${start}.`;
}

interface Props {
  campaignId: string; // P1: recebe ID e deriva da consulta -- nunca stale
  onBack: () => void;
  /** Chamado quando a campanha deixa de estar pausada (retomada/encerrada). */
  onStatusChange?: (campaign: TalkXCampaign) => void;
}

export function TalkXCampaignPaused({ campaignId, onBack, onStatusChange }: Props) {
  const {
    campaigns, isLoading, isFetching, isError, error, refetchCampaigns,
    startCampaign, cancelCampaign,
  } = useTalkX();
  const { events } = useTalkXEvents(campaignId);
  const { isAdmin, isSupervisor } = useUserRole();
  // Admin/supervisor administram a conta; os demais veem a pausa em leitura.
  const canManage = isAdmin || isSupervisor;

  const campaign = campaigns.find((candidate) => candidate.id === campaignId) ?? null;

  const [resumeOpen, setResumeOpen] = useState(false);
  const [resuming, setResuming] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
  const [endReason, setEndReason] = useState('');
  const [ending, setEnding] = useState(false);

  // Transição em UM efeito: quando a campanha sai de `paused` (retomada aqui,
  // na lista ou pelo motor), o contêiner decide o próximo destino. Sem isso a
  // tela ficaria presa mostrando uma campanha que já voltou a enviar.
  useEffect(() => {
    if (campaign && campaign.status !== 'paused') onStatusChange?.(campaign);
  }, [campaign, onStatusChange]);

  // A consulta já vem ordenada por created_at desc: o primeiro é o último evento.
  const lastPause = useMemo(() => events.find((event) => event.event_type === 'paused') ?? null, [events]);

  const pauseReasonCode = (campaign?.pause_reason ?? '').trim();
  const autoLabel = AUTO_PAUSE_LABEL[pauseReasonCode] ?? null;
  const actorName = lastPause?.actor?.name?.trim() || null;
  const typedReason = (lastPause?.message ?? '').trim();
  // Pausa automática não tem pessoa: o autor do evento é o próprio motor.
  const subtitle = autoLabel
    ? `pausada automaticamente: ${autoLabel}`
    : actorName
      ? `pausada manualmente por ${actorName}`
      : 'pausada manualmente';
  const bannerText = autoLabel
    ? AUTO_PAUSE_HINT[pauseReasonCode] ?? 'A campanha volta sozinha quando a condição passar.'
    : typedReason || 'Pausa manual sem motivo informado.';
  const pending = campaign
    ? Math.max(0, campaign.total_recipients - campaign.sent_count - campaign.failed_count - (campaign.outcome_unknown_count ?? 0))
    : 0;
  const windowNotice = campaign ? talkxSendWindowNotice(campaign) : null;

  const handleResume = useCallback(async () => {
    setResuming(true);
    try {
      const started = await startCampaign(campaignId);
      // Recusa operacional (janela fechada, limite do dia, conexão caída) mantém
      // o modal aberto com o impedimento à vista; o hook já avisa o motivo.
      if (started) setResumeOpen(false);
    } finally {
      setResuming(false);
    }
  }, [campaignId, startCampaign]);

  const handleEnd = useCallback(async () => {
    setEnding(true);
    try {
      await cancelCampaign(campaignId, endReason.trim() || undefined);
      setEndOpen(false);
      onBack();
    } catch {
      toast.error('Erro ao encerrar a campanha.');
    } finally {
      setEnding(false);
    }
  }, [campaignId, cancelCampaign, endReason, onBack]);

  return (
    <TalkXQueryBoundary
      query={{ isLoading, isFetching, isError, error }}
      entity="a campanha pausada"
      onRetry={() => { void refetchCampaigns(); }}
      skeleton={<TalkXSkeletonRows rows={3} variant="cards" />}
      isEmpty={!campaign}
      empty={(
        <TalkXEmptyState
          title="Campanha pausada não encontrada"
          description="Ela pode ter sido retomada ou encerrada. Volte para a lista de campanhas e abra novamente."
        />
      )}
    >
      {campaign && (
        <div className="min-h-full bg-background p-3 md:p-4 lg:p-6 space-y-4">
          {/* Breadcrumb */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="h-9 px-3 rounded-lg border border-border/70 bg-input/40 flex items-center gap-1.5 text-xs font-medium text-foreground-secondary hover:bg-muted/50"
            >
              <ArrowLeft className="w-4 h-4" />Voltar às campanhas
            </button>
            <span className="text-2xs text-muted-foreground hidden sm:inline">
              Campanhas / <span className="text-foreground">{campaign.name}</span> / <span className="text-foreground">Talk X</span>
            </span>
          </div>

          {/* Cabeçalho */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <IconTile icon={Pause} color="amber" size={40} />
              <div className="min-w-0">
                <h1 className="text-lg font-bold text-foreground leading-tight truncate">
                  Campanha Pausada • {campaign.name}
                </h1>
                <p className="text-xs text-foreground-secondary">{subtitle}</p>
              </div>
            </div>
            {canManage && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setResumeOpen(true)}
                  className="h-9 px-4 rounded-lg bg-primary text-white text-xs font-semibold flex items-center gap-2 hover:bg-primary/90"
                >
                  <Play className="w-4 h-4" />Retomar campanha
                </button>
                <button
                  type="button"
                  onClick={() => setEndOpen(true)}
                  className="h-9 px-4 rounded-lg border border-destructive/40 bg-destructive/10 text-destructive text-xs font-semibold flex items-center gap-2 hover:bg-destructive/20"
                >
                  <Square className="w-4 h-4" />Encerrar campanha
                </button>
              </div>
            )}
          </div>

          {/* Banner âmbar: motivo, consequência, autor e hora */}
          <div className="rounded-xl border border-warning/40 bg-warning/10 px-4 py-3 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
            <div className="min-w-0">
              <p className="text-[13px] font-semibold text-warning">
                {autoLabel ? `Pausada automaticamente: ${autoLabel}` : 'Pausada manualmente'}
              </p>
              <p className="text-xs text-foreground mt-0.5 break-words">{bannerText}</p>
              <p className="text-2xs text-muted-foreground mt-1">
                Nenhum novo contato será processado até que a campanha seja retomada.
              </p>
              <p className="text-2xs text-muted-foreground mt-0.5">
                {autoLabel ? 'Pausa do sistema' : actorName ? `Por ${actorName}` : 'Autor não registrado'}
                {campaign.paused_at ? ` · ${fmtDateTime(campaign.paused_at)}` : ''}
              </p>
            </div>
          </div>

          {/* Cartões do cabeçalho */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <RailCard title="Pausada em" icon={Clock} color="amber">
              <p className="text-[13px] text-foreground">
                {campaign.paused_at ? fmtDateTime(campaign.paused_at) : '—'}
              </p>
            </RailCard>
            <RailCard title="Tipo de campanha" icon={Zap}>
              <div className="space-y-0.5">
                <MetaRow label="Módulo" value="Talk X" />
                <MetaRow label="Destinatários" value={`${fmtInt(campaign.total_recipients)} contatos`} />
              </div>
            </RailCard>
          </div>

          {/* Modal: Retomar campanha? */}
          <AlertDialog open={resumeOpen} onOpenChange={setResumeOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Retomar campanha?</AlertDialogTitle>
                <AlertDialogDescription>
                  A campanha <strong className="text-foreground">{campaign.name}</strong> volta a enviar de onde parou.
                  Os contatos que já receberam não são reenviados.
                </AlertDialogDescription>
              </AlertDialogHeader>
              {windowNotice && (
                <p role="alert" className="rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-foreground">
                  {windowNotice}
                </p>
              )}
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleResume}
                  disabled={resuming}
                  className="bg-primary text-white hover:bg-primary/90"
                >
                  {resuming ? 'Retomando…' : 'Retomar'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Modal: Encerrar campanha? */}
          <AlertDialog open={endOpen} onOpenChange={setEndOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Encerrar campanha?</AlertDialogTitle>
                <AlertDialogDescription>
                  Esta ação é irreversível.{' '}
                  <strong className="text-foreground">{fmtInt(pending)}</strong> contatos que ainda não receberam
                  deixam de receber a mensagem.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <textarea
                className="w-full min-h-[64px] rounded-md border border-border bg-background px-3 py-2 text-sm"
                placeholder="Motivo do encerramento"
                value={endReason}
                onChange={(e) => setEndReason(e.target.value)}
              />
              <AlertDialogFooter>
                <AlertDialogCancel>Voltar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleEnd}
                  disabled={ending}
                  className="bg-destructive text-white hover:bg-destructive/90"
                >
                  {ending ? 'Encerrando…' : 'Confirmar encerramento'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      )}
    </TalkXQueryBoundary>
  );
}
