import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';

/**
 * X156 — Tela 13 "Campanha Pausada" (`TalkXCampaignPaused.tsx`).
 *
 * Prova o que o cartão TL-075 entrega: cabeçalho com quem/o porquê da pausa,
 * banner âmbar com o motivo, o aviso da janela de envio em português no modal
 * de retomar (antes o operador só via o código cru `outside_send_window`) e o
 * encerramento, que diz quantos contatos deixam de receber antes de cancelar.
 *
 * Ator e motivo vêm do último evento `paused`; a classificação
 * (manual x automática) vem de `pause_reason`, que o servidor grava
 * (`talkx-resume-policy`): `send_window`, `business_hours`, `connection_lost`
 * e `daily_limit` são pausas do próprio sistema.
 */

type QueryState = {
  campaigns: Array<Record<string, unknown>>;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  isFetching: boolean;
};

const h = vi.hoisted(() => ({
  state: {
    campaigns: [] as Array<Record<string, unknown>>,
    isLoading: false,
    isError: false,
    error: null as Error | null,
    isFetching: false,
  } as QueryState,
  events: [] as Array<Record<string, unknown>>,
  canManage: true,
  startCampaign: vi.fn(),
  cancelCampaign: vi.fn(),
  refetchCampaigns: vi.fn(),
  onBack: vi.fn(),
  onStatusChange: vi.fn(),
}));

vi.mock('@/hooks/integrations/useTalkX', () => ({
  useTalkX: () => ({
    campaigns: h.state.campaigns,
    isLoading: h.state.isLoading,
    isError: h.state.isError,
    error: h.state.error,
    isFetching: h.state.isFetching,
    refetchCampaigns: h.refetchCampaigns,
    startCampaign: h.startCampaign,
    cancelCampaign: h.cancelCampaign,
    pauseCampaign: vi.fn(),
  }),
}));

vi.mock('@/hooks/integrations/useTalkXEvents', () => ({
  useTalkXEvents: () => ({
    events: h.events,
    isLoading: false,
    isError: false,
    error: null,
    logEvent: vi.fn(),
    refetch: vi.fn(),
  }),
}));

vi.mock('@/hooks/system/useUserRole', () => ({
  useUserRole: () => ({ isAdmin: h.canManage, isSupervisor: false, isSpecialAgent: false }),
}));

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() },
}));

import { TalkXCampaignPaused } from '../TalkXCampaignPaused';

const PAUSED_CAMPAIGN = {
  id: 'camp-pausada-1',
  name: 'Promoção de Outubro',
  message_template: 'Olá {{nome}}, chegou a promoção!',
  variables_config: [],
  typing_delay_min: 1500,
  typing_delay_max: 4000,
  send_interval_min: 8000,
  send_interval_max: 20000,
  status: 'paused',
  total_recipients: 2500,
  sent_count: 1680,
  failed_count: 20,
  delivered_count: 1600,
  outcome_unknown_count: 0,
  whatsapp_connection_id: 'conn-1',
  created_by: 'user-1',
  started_at: '2026-10-08T12:00:00.000Z',
  completed_at: null,
  created_at: '2026-10-08T11:00:00.000Z',
  updated_at: '2026-10-08T12:30:00.000Z',
  media_url: null,
  media_type: null,
  scheduled_at: null,
  schedule_timezone: 'America/Sao_Paulo',
  send_window_start: null,
  send_window_end: null,
  business_hours_only: false,
  speed_profile: 'moderate',
  paused_at: '2026-10-08T12:30:00.000Z',
  pause_reason: 'Revisar o texto antes de continuar',
  revision: 3,
};

const PAUSE_EVENT = {
  id: 'evt-pausa-1',
  campaign_id: 'camp-pausada-1',
  event_type: 'paused',
  message: 'Revisar o texto antes de continuar',
  actor_id: 'user-9',
  entity_type: null,
  entity_id: null,
  created_at: '2026-10-08T12:30:00.000Z',
  actor: { name: 'Admin 01' },
};

function setCampaign(over: Partial<typeof PAUSED_CAMPAIGN> = {}) {
  h.state = { campaigns: [{ ...PAUSED_CAMPAIGN, ...over }], isLoading: false, isError: false, error: null, isFetching: false };
}

function view() {
  return (
    <TalkXCampaignPaused
      campaignId="camp-pausada-1"
      onBack={h.onBack}
      onStatusChange={h.onStatusChange}
    />
  );
}

describe('TalkXCampaignPaused — tela 13 (X156)', () => {
  beforeEach(() => {
    h.state = { campaigns: [], isLoading: false, isError: false, error: null, isFetching: false };
    h.events = [PAUSE_EVENT];
    h.canManage = true;
    h.startCampaign.mockReset();
    h.cancelCampaign.mockReset();
    h.refetchCampaigns.mockReset();
    h.onBack.mockReset();
    h.onStatusChange.mockReset();
  });

  it('mostra no cabeçalho e no banner quem pausou e o motivo digitado', () => {
    setCampaign();
    const { container } = render(view());

    expect(container.textContent).toContain('Campanha Pausada');
    expect(screen.getByText(/pausada manualmente por Admin 01/)).toBeTruthy();
    expect(screen.getAllByText(/Revisar o texto antes de continuar/).length).toBeGreaterThan(0);
    expect(screen.getByText(/Nenhum novo contato será processado/)).toBeTruthy();
  });

  it('pausa automática (connection_lost) diz "pausada automaticamente" e não mostra nome de pessoa', () => {
    h.events = [
      { ...PAUSE_EVENT, message: 'connection_lost' },
      PAUSE_EVENT,
    ];
    setCampaign({ pause_reason: 'connection_lost' });
    render(view());

    expect(screen.getByText(/pausada automaticamente: conexão do WhatsApp caiu/)).toBeTruthy();
    expect(screen.queryByText(/Admin 01/)).toBeNull();
    expect(screen.queryByText(/pausada manualmente/)).toBeNull();
  });

  it('janela de envio fechada: o modal de retomar explica em português, sem o código cru', () => {
    // 00:00–00:00 é janela vazia: o servidor sempre recusa com outside_send_window.
    setCampaign({ send_window_start: '00:00', send_window_end: '00:00', schedule_timezone: 'UTC' });
    render(view());

    fireEvent.click(screen.getByRole('button', { name: /Retomar campanha/ }));

    expect(screen.getByText(/Fora do horário de envio/)).toBeTruthy();
    expect(screen.getByText(/00:00/)).toBeTruthy();
    expect(screen.queryByText(/outside_send_window/)).toBeNull();
  });

  it('o modal de retomar cita a campanha pelo nome', () => {
    setCampaign();
    render(view());

    fireEvent.click(screen.getByRole('button', { name: /Retomar campanha/ }));

    const dialog = screen.getByRole('alertdialog');
    expect(dialog.textContent).toContain('Promoção de Outubro');
  });

  it('retomar confirma pelo hook e leva para fora da tela quando o envio aceita', async () => {
    setCampaign();
    h.startCampaign.mockResolvedValue(true);
    render(view());

    fireEvent.click(screen.getByRole('button', { name: /Retomar campanha/ }));
    fireEvent.click(screen.getByRole('button', { name: /^Retomar$/ }));

    await waitFor(() => expect(h.startCampaign).toHaveBeenCalledWith('camp-pausada-1'));
    await waitFor(() => expect(screen.queryByRole('alertdialog')).toBeNull());
  });

  it('encerrar diz quantos contatos deixam de receber e cancela com o motivo', async () => {
    setCampaign(); // 2500 - 1680 - 20 = 800 pendentes
    h.cancelCampaign.mockResolvedValue(undefined);
    render(view());

    fireEvent.click(screen.getByRole('button', { name: /Encerrar campanha/ }));
    expect(screen.getByText(/800/)).toBeTruthy();

    fireEvent.change(screen.getByPlaceholderText(/Motivo do encerramento/), { target: { value: 'Erro no texto' } });
    fireEvent.click(screen.getByRole('button', { name: /Confirmar encerramento/ }));

    await waitFor(() => expect(h.cancelCampaign).toHaveBeenCalledWith('camp-pausada-1', 'Erro no texto'));
  });

  it('esconde as ações de quem não administra a conta', () => {
    h.canManage = false;
    setCampaign();
    render(view());

    expect(screen.queryByRole('button', { name: /Retomar campanha/ })).toBeNull();
    expect(screen.queryByRole('button', { name: /Encerrar campanha/ })).toBeNull();
    // o painel de pausa continua visível (somente leitura)
    expect(screen.getByText(/Nenhum novo contato será processado/)).toBeTruthy();
  });
});
