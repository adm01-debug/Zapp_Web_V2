# t_2fd6ed9f - caso NEGATIVO: drift novo continua falhando (evidencia completa em texto)

## relato.md

Especialista: complexo (verificacao independente; sem skill de area propria aqui — abri verificar-antes-de-declarar-pronto, analisar-prova-dos-testes e conferir-entrega-do-devin)

VEREDITO: CONFIRMADO — o ajuste do `zapp-verify` NAO afrouxou a regra para drift NOVO. Num fixture
sintetico onde a migration do cartao introduz diferenca que nao existe no retrato canonico nem em
versao ja aplicada, o script ajustado devolve o MESMO veredito do de hoje: FALHOU no passo
`banco_local`, exit 1, com a diferenca ATRIBUIDA ao cartao (nomeada na mensagem). O ajuste so muda o
veredito quando a diferenca e' pre-existente (ja no retrato) — e so nesse caso.

O que medi (4 cenarios x 2 scripts, `saida/RESUMO.txt` e `saida/CLASSIFICACAO.txt`):

| cenario | HOJE (instalado 70c0b223) | NOVO (artefato c95e371a) | debitadas HOJE -> NOVO |
|---|---|---|---|
| neg: so drift do cartao | rc=1 FALHOU | rc=1 FALHOU (mensagem IDENTICA) | 4/6 -> 4/6 |
| ctrl: so drift pre-existente | rc=1 FALHOU | rc=0 AVISO (`VERIFY: VERDE`, "2 diferenca(s) NAO debitada(s)") | 2/2 -> 0/2 |
| misto: drift novo + pre-existente | rc=1 FALHOU (cita 6) | rc=1 FALHOU (cita SO as 4 do cartao) | 6/8 -> 4/8 |
| neg-sem-pendente (caminho estrito) | rc=1 FALHOU | rc=1 FALHOU | passo direto, igual |

Mensagem do cenario `neg` (identica nos dois): `diferenca nao explicada por migration pendente:
columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)`.
No `misto`, o NOVO cita `columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey;
rls|cartao_novo (+1)` e NAO cita as 2 linhas canonicas -> a atribuicao e' exatamente do cartao.

Como o fixture sustenta isso (`saida/PROVA-FIXTURE.txt`, contagem de ocorrencias): `cartao_novo`,
`cartao_dinamico`, `coluna_gerada`, `cartao_novo_pkey`, `service_role` = 0 no retrato canonico e 0
nas migrations JA APLICADAS; `cartao_novo` = 5 na unica migration PENDENTE; os nomes montados em
runtime (`cartao_dinamico`/`coluna_gerada`) = 0 em todo texto de migration. Logo ha DOIS tipos de
drift novo cobertos: (i) objeto citado pela pendente pelo dono (index auto-nomeado `cartao_novo_pkey`,
`rls`, grant) e (ii) objeto que a pendente NAO cita (nome montado por `execute format`) — nenhum dos
dois recebe a prova de drift antigo, e os dois seguem debitados.

Controle (pedido no passo 4): o `ctrl` mostra que o mesmo arranjo SABE ficar verde — 1 linha
"diferentes" (`functions|f:fn_antiga()`) e 1 "so producao" (`columns|clientes.antiga`), ambas com
chave no retrato canonico, viram drift (NAO debitadas) e o script sai 0/AVISO. Ou seja: falha
legitima x ruido se distinguem pela presenca da chave no retrato, nao por sorte do fixture.

Escopo respeitado: nenhum byte do `zapp-verify` foi escrito (instalado segue 70c0b223..., mtime
2026-10-05 08:26:15, `cmp` identico a `ENTREGA/zapp-verify.original`; artefato segue c95e371a...);
nenhum arquivo de aplicacao tocado — so o que criei em `.tmp/evidencias-negativo/`. Sem docker, sem
banco, sem rede, sem producao; o comparador de estrutura e' o codigo REAL extraido do `zapp-db-local`
(sha256 77546fc4..., igual ao que a tarefa-irma t_debaf8a8 mediu).

Limites honestos: (1) os colaboradores externos do portao (`zapp-db-guard`, `node`, `bun`,
`zapp-db-ler`, `zapp-db-local`) sao dublês — o `check` chama o comparador real, mas nao ha conjunto no
ar; a versao com conjunto VIVO e' a da t_debaf8a8 (mesmo veredito: FALHOU nos dois). (2) O fixture e'
sintetico de proposito (pedido do cartao); nao substitui o caso real. (3) Achado cosmetico de fora do
escopo, registrado em comentario no cartao pai: no ramo de AVISO o `DRIFT_N` engole as linhas
`drift: ...` do `MOTIVO` e a mensagem sai quebrada em duas linhas (o rc nao muda). (4) `rls|cartao_novo`
so e' debitada porque `explicada()` nao tem ramo para `rls` (item aberto t_1e66e3ee); aqui isso produz
o resultado desejado, mas por omissao, nao por prova.

Prova: `.tmp/evidencias-negativo/` com `FLUXO.md` (como reproduzir), `fixture/` (retrato, 2 migrations,
3 manifestos locais, 2 ledgers, comparador real), `stubs/`, `confere-fixture.sh`, `rodar.sh`,
`conta-classes.py`, `home/` (HOME de ensaio por rodada) e `saida/` (RESUMO.txt, CLASSIFICACAO.txt,
PROVA-FIXTURE.txt, motor-*.out/.err/.rc, diferencas-*.txt, banco_local-*.log, explicador-HOJE.py,
explicador-NOVO.py). Anexado ao cartao.

## FLUXO.md (como reproduzir)

# t_2fd6ed9f — caso negativo: drift NOVO continua falhando (como reproduzir)

Pasta: `/home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo`
(o `.tmp/evidencias-negativo/` do cartao; o workspace `scratch` do dispatcher e um caminho Windows que
nao existe no WSL, entao o espelho fica aqui, igual ao que as tarefas-irmas fizeram)

## O que o fixture afirma (e o que ele NAO usa)

A "copia" `fixture/copia` tem retrato canonico sintetico, uma migration JA APLICADA (base) e uma
migration PENDENTE do cartao. A migration pendente cria:
  - `public.cartao_novo` (literal) e a coluna `payload`;
  - por SQL dinamico (`execute format('... %I ...', 'cartao_' || 'dinamico', 'coluna_' || 'gerada')`)
    uma tabela/coluna cujos NOMES nao aparecem literalmente no texto de nenhuma migration.
Logo ha dois tipos de drift NOVO, nenhum deles no retrato e nenhum em versao ja aplicada:
  (i)  objeto citado pela pendente pelo nome da TABELA (`indexes|cartao_novo.cartao_novo_pkey`,
       `rls|cartao_novo`, grant) -> o ajuste continua debitando ao cartao;
  (ii) objeto cujo nome a pendente NAO cita (montado em runtime) -> nao ha prova de drift antigo
       -> continua debitado.
`saida/PROVA-FIXTURE.txt` prova, por contagem de ocorrencias, que esses nomes nao existem no retrato
nem nas migrations aplicadas (0 em ambos) e so a pendente cita `cartao_novo`.

O comparador de estrutura e o CODIGO REAL, extraido verbatim do heredoc do `zapp-db-local`
(`fixture/comparador-real.py`, sha256 77546fc4...), rodado sobre dois manifestos sinteticos.
O `zapp-db-guard`/`node`/`bun`/`zapp-db-ler`/`zapp-db-local check` sao dublês em `stubs/` (o `check`
chama o comparador real). Nenhum contato com docker, banco, rede ou producao.

## Cenarios

| cenario | diferenca de estrutura | esperado |
|---|---|---|
| `neg` | so o drift NOVO do cartao (6 linhas) | FALHAR nos dois scripts |
| `ctrl` | so drift PRE-EXISTENTE (ja no retrato: 1 "diferentes" + 1 "so producao") | HOJE falha / NOVO avisa |
| `misto` | drift novo + pre-existente (8 linhas) | FALHAR citando SO as linhas do cartao |
| `neg-sem-pendente` | drift novo e ledger sem nenhuma pendente | caminho estrito intacto: FALHAR nos dois |

## Como reproduzir (tudo dentro desta pasta)

    bash confere-fixture.sh          # prova que o fixture e' o que diz ser  -> saida/PROVA-FIXTURE.txt
    bash rodar.sh                    # 4 cenarios x 2 scripts (HOJE/NOVO)   -> saida/RESUMO.txt
    python3 conta-classes.py         # classificacao linha a linha         -> saida/CLASSIFICACAO.txt

`saida/` guarda, por cenario e por script: stdout/stderr (`motor-*.out/.err`), rc (`motor-*.rc`),
o `check-diferencas.txt` usado (`diferencas-*.txt`) e o log do passo (`banco_local-*.log`).
`home/<cenario>-<HOJE|NOVO>/` e o HOME de ensaio (estado do zapp-verify) de cada rodada.

## saida/RESUMO.txt


== 1. veredito por cenario (rc do script inteiro) ==
CENARIO            HOJE   NOVO   passo banco_local (NOVO)
neg                1      1      FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; ind
ctrl               1      0      AVISO   banco_local     0s  ESTRUTURA: 2 diferença(s) em relação ao retrato da produção — migration(s) pendente(s
misto              1      1      FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; ind
neg-sem-pendente   1      1      FALHOU  banco_local     0s  (ver /home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo

== 2. linhas de diferenca (comparador REAL, por cenario) ==
-- neg (rc=1)
columns|cartao_dinamico.coluna_gerada
columns|cartao_novo.id
columns|cartao_novo.payload
indexes|cartao_novo.cartao_novo_pkey
rls|cartao_novo
relation_grants|r:public.cartao_novo|service_role|SELECT|grantor=postgres
-- ctrl (rc=1)
columns|clientes.antiga
functions|f:fn_antiga()
-- misto (rc=1)
columns|clientes.antiga
columns|cartao_dinamico.coluna_gerada
columns|cartao_novo.id
columns|cartao_novo.payload
indexes|cartao_novo.cartao_novo_pkey
rls|cartao_novo
relation_grants|r:public.cartao_novo|service_role|SELECT|grantor=postgres
functions|f:fn_antiga()

== 3. mensagem do passo banco_local ==
-- neg HOJE:
     FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)
     VERIFY: VERMELHO em banco_local (0s)
-- neg NOVO:
     FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)
     VERIFY: VERMELHO em banco_local (0s)
-- ctrl HOJE:
     FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|clientes.antiga; functions|f:fn_antiga()
     VERIFY: VERMELHO em banco_local (0s)
-- ctrl NOVO:
     AVISO   banco_local     0s  ESTRUTURA: 2 diferença(s) em relação ao retrato da produção — migration(s) pendente(s): 20261007095739_cartao_drift_novo.sql; 2
     drift: functions|f:fn_antiga() diferença(s) NÃO debitada(s) ao cartão (já no retrato canônico e não citadas por nenhuma pendente: columns|clientes.antiga;functions|f:fn_antiga()) (ver /home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo/home/ctrl-NOVO/.local/state/zapp-verify/807d6e50c211/banco_local.log)
     VERIFY: VERDE (0s) — registros em /home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo/home/ctrl-NOVO/.local/state/zapp-verify/807d6e50c211
-- misto HOJE:
     FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|clientes.antiga; columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey (+3)
     VERIFY: VERMELHO em banco_local (0s)
-- misto NOVO:
     FALHOU  banco_local     0s  diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)
     VERIFY: VERMELHO em banco_local (0s)
-- neg-sem-pendente HOJE:
     FALHOU  banco_local     0s  (ver /home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo/home/neg-sem-pendente-HOJE/.local/state/zapp-verify/807d6e50c211/banco_local.log)
     VERIFY: VERMELHO em banco_local (1s)
-- neg-sem-pendente NOVO:
     FALHOU  banco_local     0s  (ver /home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo/home/neg-sem-pendente-NOVO/.local/state/zapp-verify/807d6e50c211/banco_local.log)
     VERIFY: VERMELHO em banco_local (1s)

## saida/CLASSIFICACAO.txt

== cenario neg (local-neg.json) ==================================================================
   linha de diferenca                                             HOJE                     NOVO
   columns|cartao_dinamico.coluna_gerada                          SEM (debitada ao cartao) SEM (debitada ao cartao)
   columns|cartao_novo.id                                         explicada pela pendente  explicada pela pendente
   columns|cartao_novo.payload                                    explicada pela pendente  explicada pela pendente
   indexes|cartao_novo.cartao_novo_pkey                           SEM (debitada ao cartao) SEM (debitada ao cartao)
   relation_grants|r:public.cartao_novo|service_role|SELECT|grant SEM (debitada ao cartao) SEM (debitada ao cartao)
   rls|cartao_novo                                                SEM (debitada ao cartao) SEM (debitada ao cartao)
   -> debitadas ao cartao: HOJE 4 de 6 | NOVO 4 de 6
   -> rc do explicador (= veredito do passo banco_local): HOJE 1 | NOVO 1
   -> stdout HOJE : diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)
   -> stdout NOVO : diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)

== cenario ctrl (local-ctrl.json) ==================================================================
   linha de diferenca                                             HOJE                     NOVO
   columns|clientes.antiga                                        SEM (debitada ao cartao) drift (NAO debitada)
   functions|f:fn_antiga()                                        SEM (debitada ao cartao) drift (NAO debitada)
   -> debitadas ao cartao: HOJE 2 de 2 | NOVO 0 de 2
   -> rc do explicador (= veredito do passo banco_local): HOJE 1 | NOVO 0
   -> stdout HOJE : diferença não explicada por migration pendente: columns|clientes.antiga; functions|f:fn_antiga()
   -> stdout NOVO : ok|drift=2 | drift: columns|clientes.antiga | drift: functions|f:fn_antiga()

== cenario misto (local-misto.json) ==================================================================
   linha de diferenca                                             HOJE                     NOVO
   columns|cartao_dinamico.coluna_gerada                          SEM (debitada ao cartao) SEM (debitada ao cartao)
   columns|cartao_novo.id                                         explicada pela pendente  explicada pela pendente
   columns|cartao_novo.payload                                    explicada pela pendente  explicada pela pendente
   columns|clientes.antiga                                        SEM (debitada ao cartao) drift (NAO debitada)
   functions|f:fn_antiga()                                        SEM (debitada ao cartao) drift (NAO debitada)
   indexes|cartao_novo.cartao_novo_pkey                           SEM (debitada ao cartao) SEM (debitada ao cartao)
   relation_grants|r:public.cartao_novo|service_role|SELECT|grant SEM (debitada ao cartao) SEM (debitada ao cartao)
   rls|cartao_novo                                                SEM (debitada ao cartao) SEM (debitada ao cartao)
   -> debitadas ao cartao: HOJE 6 de 8 | NOVO 4 de 8
   -> rc do explicador (= veredito do passo banco_local): HOJE 1 | NOVO 1
   -> stdout HOJE : diferença não explicada por migration pendente: columns|clientes.antiga; columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey (+3)
   -> stdout NOVO : diferença não explicada por migration pendente: columns|cartao_dinamico.coluna_gerada; indexes|cartao_novo.cartao_novo_pkey; rls|cartao_novo (+1)


## saida/PROVA-FIXTURE.txt

== (a) nomes no RETRATO canonico (/home/joaquim_ataides/hermes-workspaces/Zapp_Web_V2/.tmp-t_2fd6ed9f/evidencias-negativo/fixture/copia/supabase/schema-manifest.json) ==
   cartao_novo       ocorrencias=0
   cartao_dinamico   ocorrencias=0
   coluna_gerada     ocorrencias=0
   cartao_novo_pkey  ocorrencias=0
   coluna_injetada   ocorrencias=0
   service_role      ocorrencias=0

== (b) nomes nas migrations JA APLICADAS (tudo menos a pendente) ==
   arquivos: 20261001120000_base_clientes.sql 
   cartao_novo       ocorrencias=0
   cartao_dinamico   ocorrencias=0
   coluna_gerada     ocorrencias=0
   cartao_novo_pkey  ocorrencias=0
   coluna_injetada   ocorrencias=0
   service_role      ocorrencias=0

== (c) nomes na migration PENDENTE (20261007095739_cartao_drift_novo.sql) ==
   cartao_novo       ocorrencias=5
   cartao_dinamico   ocorrencias=0
   coluna_gerada     ocorrencias=0
   cartao_novo_pkey  ocorrencias=0
   coluna_injetada   ocorrencias=0
   service_role      ocorrencias=0
   (a tabela cartao_novo e literal; os outros nomes sao montados por concatenacao em runtime)

== (d) ledger do fixture decide o que e pendente ==
   20261001120000_base_clientes.sql               aplicada
   20261007095739_cartao_drift_novo.sql           PENDENTE

## fixture/copia/supabase/migrations/20261007095739_cartao_drift_novo.sql

-- Rollback: drop table if exists public.cartao_novo;
-- Migration PENDENTE do cartao (fixture). Cria a tabela do cartao e, por SQL dinamico, uma
-- tabela/coluna cujos NOMES sao montados em tempo de execucao: nenhum deles aparece literalmente
-- neste texto. E o drift novo que NAO existe no retrato canonico nem em versao ja aplicada.
create table if not exists public.cartao_novo (
  id uuid primary key default gen_random_uuid(),
  payload jsonb not null default '{}'::jsonb
);
alter table public.cartao_novo enable row level security;
grant select on public.cartao_novo to authenticated;
do $do$
declare
  t text := 'cartao_' || 'dinamico';
  c text := 'coluna_' || 'gerada';
begin
  execute format('create table if not exists public.%I (%I text)', t, c);
end
$do$;
do $do$
begin
  execute format('alter table %I add column %I text', 'cartao_novo', 'coluna_' || 'injetada');
end
$do$;

## fixture/copia/supabase/schema-manifest.json

{
  "columns": {
    "clientes.id": "c-id",
    "clientes.nome": "c-nome",
    "clientes.antiga": "c-antiga"
  },
  "indexes": {
    "clientes.clientes_pkey": "i-pkey"
  },
  "rls": {
    "clientes": "rls-clientes"
  },
  "relation_grants": {
    "r:public.clientes|authenticated|SELECT|grantor=postgres": "g-sel"
  },
  "functions": {
    "f:fn_antiga()": "f-h5"
  }
}

## stubs/zapp-db-local (dubl? do banco local: chama o comparador REAL)

#!/bin/sh
# dublê do banco local. 'travas' passa; 'check' roda o COMPARADOR REAL (extraído do próprio
# zapp-db-local, sha256 77546fc4...) sobre os manifestos sintéticos do fixture e devolve o código
# de saída dele (1 = há diferença não aceita). Nada de docker, banco ou rede.
case "${1:-}" in
  travas) exit 0 ;;
  check)
    W="$2"; NOME="$3"
    ST="$HOME/.local/share/zapp-local/stacks/$NOME/estado"
    exec python3 "${FIXTURE_COMPARADOR:?FIXTURE_COMPARADOR nao definido}" \
        "${FIXTURE_LOCAL_MANIFEST:?FIXTURE_LOCAL_MANIFEST nao definido}" \
        "$W/supabase/schema-manifest.json" "$ST/check-diferencas.txt" ""
    ;;
  *) exit 0 ;;
esac
